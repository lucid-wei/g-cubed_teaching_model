import os
import logging
from posixpath import isabs
import pandas as pd
from datetime import datetime
from gcubed.base import Base
from gcubed.model_configuration import ModelConfiguration
from gcubed.model import Model
from gcubed.linear_model import LinearModel
from gcubed.state_space_form import StateSpaceForm
from gcubed.stable_manifold import StableManifold
from gcubed.projections.baseline_projections import BaselineProjections
from gcubed.projections.simulation_experiment import SimulationExperiment
from gcubed.projections.simulation_layer import SimulationLayer

class Runner(Base):

    def __init__(self, working_directory:str, configuration_file: str, experiment_design_file: str = None):
        """
        Arguments:
        
        working_directory: The directory where the results and logs are to be stored.

        configuration_file: The location of the configuration file, as an absolute path or relative to the 
        specified working directory.

        experiment_design_file: The optional location of the experiment design CSV file, as a relative path directory
        to the experiment design file from the simulations folder within the model folder (the model folder contains
        the configuration file).

        TODO: add customisation/configuration parameter getting and setting to support better control of the run.
        """

        if not os.path.isdir(working_directory):
            raise Exception(f"{working_directory} is not a directory.")
        
        if not os.access(working_directory, os.W_OK):
            raise Exception(f"You need write access to {working_directory} but that permission has not been granted to you.")

        # For timestamping output.
        self.timestamp: str = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

        # Set up directory where results will be stored
        self.results_directory: str = os.path.join(working_directory, f"results_{self.timestamp}")
        if not os.path.exists(self.results_directory):
            os.mkdir(self.results_directory)
        if not os.path.isdir(self.results_directory):
            raise Exception(f"Results are to be stored in the directory {self.results_directory} but it is a file, not a directory.")

        # Configure up the logging system
        log_file: str = os.path.join(self.results_directory, "run.log")
        fh = logging.FileHandler(log_file, mode='w')
        logging.basicConfig(level=logging.DEBUG,
                            format='%(asctime)s %(levelname)s %(message)s',
                            handlers=[
                                fh,
                                logging.StreamHandler()
                            ])

        logging.info(f"Saving results and logs to {self.results_directory}.")

        # Get the absolute path to the model configuration file.
        if os.path.isabs(configuration_file):
            self.filename:str = configuration_file
        else:
            self.filename: str = os.path.join(working_directory, configuration_file)
        if not os.path.isfile(self.filename):
            raise Exception(f"There is no model configuration file at {self.filename}.")
        logging.info(f"The model configuration will be loaded from {self.filename}.")



        # Save the experiment design file for later use.
        self.experiment_design_file = experiment_design_file

    def run(self):
        """
        Do the actual work of running the model and generating results.
        """
        
        # Load the model
        model_configuration: ModelConfiguration = ModelConfiguration(configuration_file=self.filename)
        model: Model = Model(model_configuration)

        # Get the model solution
        linear_model: LinearModel = LinearModel(model=model)
        state_space_form: StateSpaceForm = StateSpaceForm(linear_model=linear_model)
        stable_manifold: StableManifold = StableManifold(state_space_form=state_space_form)

        # Generate the baseline projections
        baseline_projections: BaselineProjections = BaselineProjections(stable_manifold=stable_manifold)

        # Generate the CSV file containing baseline projections
        baseline_projections.graphable_projections.to_csv(f"{self.results_directory}/baseline_projections.csv")

        logging.info(f"Baseline projections have been saved to a CSV file in {self.results_directory}")

        if self.experiment_design_file is not None:

            # Run the simulation experiment
            experiment = SimulationExperiment(baseline_projections=baseline_projections, design_file=self.experiment_design_file)
            simulation_layers: list[SimulationLayer] = []
            last_simulation_layer: SimulationLayer = None
            for simulation_layer_definition in experiment.simulation_layer_definitions:
                simulation_layers.append(
                    SimulationLayer(
                        simulation_layer_definition=simulation_layer_definition,
                        baseline_projections=baseline_projections,
                        previous_simulation_layer=last_simulation_layer
                    )
                )
                last_simulation_layer: SimulationLayer = simulation_layers[-1]

            # Generate the CSV file containing simulation projections
            last_simulation_layer.graphable_projections.to_csv(f"{self.results_directory}/simulation_projections.csv")

            # Generate the CSV file containing the simulation deviation from baseline projections
            experiment.graphable_deviation_projections(reference_projections=last_simulation_layer, comparison_projections=baseline_projections).to_csv(f"{self.results_directory}/deviation_projections.csv")

            logging.info(f"Simulation projections have been saved as CSV files in {self.results_directory}")



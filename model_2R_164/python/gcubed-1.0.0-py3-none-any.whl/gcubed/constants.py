# ------------------------------------------------------------------
# Purpose: Define a set of global constants.
# Author: Geoff Shuetrim
#
# Most of these constants should be produced by the SYM processor
# from model attributes rather than hard coded into the Python
# implementation of the model.
# ------------------------------------------------------------------

USA_REGION_CODE: str = "UU"

# Weighted price of domestic output. See gcubed.Model
PRID_PREFIX: str = "PRID"
WAGE_PREFIX: str = "WAGE"
NOMINAL_GDP_PREFIX = "LGDPN"
REAL_GDP_PREFIX = "LGDPR"
US_REAL_GDP_RATIO_PREFIX = "YRATR"

INTEREST_RATE_PREFIXES: list[str] = ["INPL", "INPN", "INTF", "INTL", "INTN", "INTR"]

BOND_RATE_PREFIXES: list[str] = ["NB02", "NB05", "NB10", "RB10"]

STATE_LEAD_VARIABLES: list[str] = ["INTN", "EXCH", "INPN", "REXB"]

# These are used along with wage and prid prefixes to do projections
JUMPING_VARIABLE_PREFIXES_FOR_REGIONS = ["REXC", "WELH", "LAMY", "LAMZ", "EYGR", "EPRC"]
JUMPING_VARIABLE_PREFIXES_FOR_REGIONS_AND_SECTORS = ["LAM"]

# Constants relevant to rebasing operations. See gcubed.Rebaser.

LOG_INDEX_PREFIXES = ["PRCT", "PRID", "PRIM", "PRIX", "PRIE", "PRII", "PRKY", "PRKZ",
                      "WAGE", "PGDP", "EXCH", "REXC", "NEER", "PRCE", "PRCO", "REER", 
                      "MONE", "PRGT", "PROI", "PRDX", "PRY", "PRD", 
                      "PIM", "PRE", "POI", "PRK", "PRP", "WAG", "PMR", "PMQ", "PRX"]
LEAD_LOG_INDEX_PREFIXES = ["EXCL"]
LAG_LOG_INDEX_PREFIXES = ["PRCL", "PRDL"]
INDEX_PREFIXES = ["GDPN"]

NON_STANDARD_INTERTEMPORAL_CONSTANT_VARIABLE_PREFIXES = [
    ('EPRC', 'z1l'),
    ('EYGR', 'z1l'),
    ('WAGE', 'x1l')]
    
NON_STANDARD_VARIABLES_ADJUSTED_BY_INTERTEMPORAL_CONSTANTS_PREFIXES = [
    ('EPRC', 'z1l'),
    ('EYGR', 'z1l'),
    ('PRID', 'zel')]

REXC_FOR_USA = 'REXC(UU)'

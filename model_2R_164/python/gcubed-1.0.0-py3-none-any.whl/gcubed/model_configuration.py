# ------------------------------------------------------------------
# Purpose: Definition of the model details class.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------

import logging
import pandas as pd
import numpy as np
import os
import os.path
import sys
import importlib
from gcubed.base import Base


class ModelConfiguration(Base):

    """
    Provides access to model configuration details.
    """

    def __init__(self, configuration_file: str) -> None:
        """
        Initialises the model details from a modified version of the CSV files
        used by G-cubed. The information in the file is a subset of the information
        in the modeldetails.csv file and a subset of the information that is stored
        in the baseinfo.csv file.

        Arguments:
            configuration_file: the relative path to the model configuration file.
        """

        if not configuration_file:
            raise Exception("A configuration file is required to create a model.")

        if not os.path.isfile(configuration_file):
            raise Exception(f"Configuration file {configuration_file} does not exist.")

        # Get the directory that contains the model configuration and other related files.
        self._model_directory = os.path.dirname(os.path.realpath(configuration_file))

        data: pd.DataFrame = pd.read_csv(configuration_file, header=None)
        self.load_configuration_details(configuration_details = data)
        self.validate()

        logging.info(f"Preparing to use model {self.version} {self.number}.")

        if __class__.DOING_DETAILED_DEBUG:
            logging.info("Verbose debugging information will be logged.")
            np.set_printoptions(suppress=False, formatter={'float': lambda x: "{0:0.12f}".format(x)})
            pd.set_option('display.max_rows', None)
            pd.set_option('display.max_columns', None)
            pd.set_option('display.width', 2000)

    @property
    def model_directory(self):
        return f"{self._model_directory}/"
    
    @property
    def data_directory(self):
        return f"{self.model_directory}data/"

    @property
    def sym_directory(self):
        return f"{self.model_directory}sym/"

    @property
    def ox_directory(self):
        return f"{self.model_directory}ox/"

    @property
    def build_directory(self):
        return f"{self.model_directory}build/"

    @property
    def benchmarking_reports_directory(self):
        return f"{self.model_directory}benchmarking/"

    @property
    def python_reports_directory(self):
        return f"{self.model_directory}python/"

    @property
    def simulations_directory(self) -> str:
        return f"{self.model_directory}simulations/"

    @property
    def version(self):
        """
        The model type - a number plus single letter string, where number represents sectors, letter for regions.
        - 2R is the 2 region/2 sector model
        - 20R is the 2 region/20 sector model
        - 20J is the 10 region/20 sector model used for carbon emissions modelling
        """
        return self._version

    @property
    def number(self):
        """
        The model build number
        """
        return self._number

    @property
    def sym_input_file(self):
        """
        The name of the file to process with the sym processor.
        """
        return "{}{}".format(self.sym_directory, self._sym_input_file)

    @property
    def sym_output_filename_prefix(self):
        """
        The equations Python module that is imported by the Lineariser.
        """
        return "model_{}_{}".format(self.version, self.number)

    @property
    def fully_qualified_equations_module_name(self):
        """
        The fully qualified module name required to import the 
        SYM generated Python equations module.
        """
        return f"model.{self.version}.{self.number}.sym.{self.sym_output_filename_prefix}"

    @property
    def equations_python_module_file(self):
        return "{}{}.py".format(self.sym_directory, self.sym_output_filename_prefix)

    @property
    def sym_output_file_path_and_prefix(self):
        return "{}{}".format(self.sym_directory, self.sym_output_filename_prefix)

    @property
    def varmap_file(self):
        return "{}_varmap.csv".format(self.sym_output_file_path_and_prefix)

    @property
    def eqnmap_file(self):
        """
        The file containing a listing of left and right hand side variables
        in the model equations. the LHS variable comes first, as a name of
        the vector (column 1), and the index in that vector (column 2). Then each
        RHS variable appears, again as the vector name in column 2 and the index
        in that vector in column 2.

        This information is used to populate a dictionary with keys being the vector
        and index tuple for each RHS variable and the value being a list of of
        vector name, vector index tuples, one for each equation that the RHS variable 
        occurs in. That dictionary then drives the equation evaluations used in model
        linearisation.
        """
        return f"{self.sym_output_file_path_and_prefix}_eqnmap.csv"

    @property
    def variables_info_file(self):
        return f"{self.sym_output_file_path_and_prefix}_varinfo.csv"

    @property
    def opt_map_file(self):
        return f"{self.sym_output_file_path_and_prefix}_optmap.csv"

    @property
    def model_summary_file(self):
        return f"{self.sym_output_file_path_and_prefix}.lis"

    @property
    def database_file(self):
        return f"{self.data_directory}{self._database_file}"

    @property
    def io_table_file(self):
        return f"{self.data_directory}{self._io_table_file}"

    @property
    def parameters_file(self):
        return f"{self.data_directory}{self._parameters_file}"

    @property
    def productivity_file(self):
        return f"{self.data_directory}{self._productivity_file}"

    @property
    def population_file(self):
        return f"{self.data_directory}{self._population_file}"

    @property
    def aeei_file(self):
        return f"{self.data_directory}{self._aeei_file}"

    @property
    def linearisation_year(self):
        return self._linearisation_year

    @property
    def calibration_year(self):
        return self._calibration_year

    @property
    def calibration_of_carbon_coefficients_year(self):
        return self._calibration_of_carbon_coefficients_year

    @property
    def first_available_year(self):
        """
        The first year of actual data that is available to us in the database file.
        """
        return self._first_available_year

    @property
    def last_available_year(self):
        """
        The last year of actual data that is available to us in the database file.
        """
        return self._last_available_year

    @property
    def base_year(self):
        """
        The year in which all indices are based at 1 (so their log values are 0).
        This is currently required to be the same as the start_year but we may relax that.
        """
        return self._base_year

    @property
    def start_year(self):
        """
        The first year to include in the analysis that will produce projections.
        TODO: Can this be made redundant, given the start_projection_year and the base_year?
        """
        return self._start_year

    @property
    def start_projection_year(self):
        """
        Corresponds to the start_year specified in the Ox build/baseinfo.csv file.
        This is currently required to be start_year+1.
        """
        return self._start_projection_year

    @property
    def projection_base_year(self):
        """
        Base year for index variables in the database used for projections.
        """
        return self._projection_base_year

    @property
    def end_year(self):
        """
        The last year for which data will be projected.
        """
        return self._end_year

    @property
    def start_to_base_years(self) -> list[int]:
        return range(self.start_year, self.base_year+1)

    @property
    def start_to_base_year_column_labels(self) -> list[str]:
        return [str(x) for x in self.start_to_base_years]

    @property
    def base_to_end_years(self) -> list[int]:
        return range(self.base_year, self.end_year+1)

    @property
    def base_to_end_year_column_labels(self) -> list[str]:
        return [str(x) for x in self.base_to_end_years]

    @property
    def start_to_end_years(self) -> list[int]:
        return range(self.start_year, self.end_year+1)

    @property
    def start_to_end_year_column_labels(self) -> list[str]:
        return [str(x) for x in self.start_to_end_years]

    @property
    def projection_years(self) -> list[int]:
        return range(self.start_projection_year, self.end_year+1)

    @property
    def base_and_projection_years(self) -> list[int]:
        return range(self.projection_base_year, self.end_year+1)

    @property
    def projection_years_column_labels(self) -> list[str]:
        return [str(x) for x in self.projection_years]

    @property
    def base_and_projection_years_column_labels(self) -> list[str]:
        return [str(x) for x in self.base_and_projection_years]

    @property
    def projection_year_count(self) -> int:
        return (self.end_year - self.start_projection_year + 1)

    @property
    def base_and_projection_year_count(self) -> int:
        """
        Returns the number of years that projections are done for plus one for the base projection
        year that is the year before the start of the projection years.
        """
        return (self.end_year - self.projection_base_year + 1)

    @property
    def available_years(self) -> list[int]:
        return range(self.first_available_year, self.last_available_year+1)

    @property
    def available_years_column_labels(self) -> list[str]:
        return [str(x) for x in self.available_years]

    @property
    def all_years(self) -> list[int]:
        """
        Returns all years from the first year with data in the database
        to the last year of the projections horizon. This is used for the
        publishable projections that includes the actual data and the projections.
        """
        return range(self.first_available_year, self.end_year+1)

    @property
    def all_year_count(self) -> int:
        return (self.end_year - self.first_available_year + 1)

    def available_years_column_labels(self) -> list[str]:
        return [str(x) for x in self.all_years]

    @property
    def stable_manifold_use_policy_optimisation(self):
        """
        Set to 1 if the stable manifold is calculated while
        allowing (monetary?) policy to optimise according to 
        a set of policy objectives and set to 0 otherwise.

        Note that this can only be set to 1 if the model parameters
        include a TCAX and an EMZT
        """
        return self._stable_manifold_use_policy_optimisation

    @property
    def stable_manifold_tolerance(self):
        return self._stable_manifold_tolerance

    @property
    def stable_manifold_maximum_iterations(self):
        return self._stable_manifold_maximum_iterations

    @property
    def neutral_real_interest_rate(self):
        """
        Used for linearising the model and for projections.

        Returns the global neutral real interest rate.
        """
        return self._neutral_real_interest_rate

    def load_configuration_details(self, configuration_details: pd.DataFrame):
        """
        The detail identifier is in the first column.
        The detail value is in the second column.
        Other columns are ignored.
        """

        for row in configuration_details.itertuples(index=False):
            match row[0]:
                case "Version":
                    self._version = row[1]
                case "Number":
                    self._number = row[1]
                case "Debugging":
                    self.__class__.DOING_DETAILED_DEBUG = (int(row[1]) == 1)
                case "SymInputFile":
                    self._sym_input_file = row[1]
                case "UserParameters":
                    self._parameters_file = row[1]
                case "IOTables":
                    self._io_table_file = row[1]
                case "Database":
                    self._database_file = row[1]
                case "Productivity":
                    self._productivity_file = row[1]
                case "Population":
                    self._population_file = row[1]
                case "AutonomousEnergyEfficiencyImprovement":
                    self._aeei_file = row[1]
                case "LinearisationYear":
                    self._linearisation_year = int(row[1])
                case "CalibrationYear":
                    self._calibration_year = int(row[1])
                case "CalibrationOfCarbonCoefficientsYear":
                    self._calibration_of_carbon_coefficients_year = int(row[1])
                case "FirstAvailableYear":
                    self._first_available_year = int(row[1])
                case "LastAvailableYear":
                    self._last_available_year = int(row[1])
                case "BaseYear":
                    self._base_year = int(row[1])
                case "ProjectionBaseYear":
                    self._projection_base_year = int(row[1])
                case "StartYear":
                    self._start_year = int(row[1])
                case "StartProjectionYear":
                    self._start_projection_year = int(row[1])
                case "EndYear":
                    self._end_year = int(row[1])
                case "StableManifoldUsePolicyOptimisation":
                    self._stable_manifold_use_policy_optimisation = float(row[1])
                case "StableManifoldTolerance":
                    self._stable_manifold_tolerance = float(row[1])
                case "StableManifoldMaximumIterations":
                    self._stable_manifold_maximum_iterations = int(row[1])
                case "NeutralRealInterestRate":
                    self._neutral_real_interest_rate = float(row[1])
                case _:
                    raise Exception(f"Configuration parameter {row[0]} is not recognised.")

    def validate(self):

        # Check we have a model version and a model build number.
        assert self.version is not None
        assert self.number is not None

        # Check that all of the files named in the configuration exist.
        if not os.path.isfile(self.sym_input_file):
            raise Exception(f"Could not find the sym_input_file: {self.sym_input_file}")
        if not os.path.isfile(self.varmap_file):
            raise Exception(f"Could not find the varmap file generated by the SYM processor: {self.varmap_file}")
        assert os.path.isfile(self.varmap_file)
        assert os.path.isfile(self.eqnmap_file)
        assert os.path.isfile(self.variables_info_file)
        assert os.path.isfile(self.opt_map_file)
        assert os.path.isfile(self.model_summary_file)
        assert os.path.isfile(self.equations_python_module_file)

        assert os.path.isfile(self.database_file)
        assert os.path.isfile(self.io_table_file)
        assert os.path.isfile(self.parameters_file)

        assert os.path.isfile(self.productivity_file)
        assert os.path.isfile(self.population_file)

        sys.path.append(self.sym_directory)
        equations_module = importlib.import_module(self.sym_output_filename_prefix)
        assert equations_module is not None
        assert getattr(equations_module, "Equations") is not None

        assert self.first_available_year > 1900
        assert self.last_available_year < 2050

        assert self.start_year >= self.first_available_year
        assert self.start_year < self.end_year

        assert self.base_year >= self.first_available_year
        assert self.base_year <= self.last_available_year

        assert self.calibration_year >= self.first_available_year
        assert self.calibration_year <= self.last_available_year

        assert self.projection_base_year >= self.start_year
        assert self.projection_base_year <= self.end_year

        assert self.start_projection_year > self.start_year
        assert self.start_projection_year < self.end_year
        
        if self.stable_manifold_use_policy_optimisation:
            raise Exception("Stable manifold determination in conjunction with policy optimisation is not yet implemented.")

        if self.stable_manifold_tolerance > 0.0001:
            raise Exception("The convergence tolerance when searching for the stable manifold must be less than 1e-4.")

        if self.stable_manifold_maximum_iterations < 100:
            raise Exception("You must allow for at least 100 iterations in converging to the stable manifold")
        
    def shift_forward(self, steps:int):
        """
        Adjusts this model configuration by incrementing the start and base years for the projection by steps.

        This shift operation is used to roll the model forward by steps years.
        """
        self._projection_base_year += steps
        self._start_projection_year += steps
        self._linearisation_year = self.projection_base_year
        
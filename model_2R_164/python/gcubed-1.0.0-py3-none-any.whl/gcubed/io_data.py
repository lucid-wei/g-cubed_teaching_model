# ------------------------------------------------------------------
# Purpose: Manage loading and provision of IO table information.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------

from __future__ import annotations
import logging
import os
import re
import pandas as pd
import numpy as np
from gcubed.base import Base
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData


class IOData(Base):
    """
    Encapsulates all of the information about the IO data used by a Model.

    Properties:

        TODO: Complete this listing of class properties and their explanations.
        _database: the dataframe containing the annual data for all variables.

    """

    def __init__(self, sym_data: SymData) -> None:


        assert sym_data is not None
        assert isinstance(sym_data, SymData)
        self._sym_data = sym_data
        logging.info(f"Loading IO tables from {self.sym_data.configuration.io_table_file}")
        self.__load_io_tables()
        self.__validate()

    @property
    def sym_data(self):
        return self._sym_data

    def __load_io_tables(self):
        """
        Loads the IO tables into a dictionary of dataframes.
        The keys are the region identifier.
        Each dataframe contains the IO table for the associated region.
        The dataframes have row and column names that correspond to the
        sectors.
        """
        filename: str = self.sym_data.configuration.io_table_file
        if not os.path.isfile(filename):
            raise Exception("Could not load IO tables from " +
                            filename + " because the file does not exist.")

        # Load the raw IO tables data into a single dataframe ready to parse into 
        # separate tables for the various regions.
        data: pd.DataFrame = pd.read_csv(filename, header=None)

        # Label the columns of the raw IO table dataframe
        columns = self.io_table_uses
        columns.insert(0,"row_labels")
        data.columns = columns

        # Get the table names - one for each region
        regions: list[str] = self.sym_data.regions_members
        table_rows = len(self.io_table_inputs)
        table_columns = len(self.io_table_uses)

        # Load the table for each region into the dictionary of IO tables.
        self._io_tables = dict()
        for region in regions:

            # Make sure the data source has an IO table for the region
            if not region in data.row_labels.values:
                raise Exception(f"Region {region} does not have IO table data in {filename}")

            # Get the data for the table
            io_table_heading_row: int = int(data.index[data.row_labels == region].to_list()[0])
            io_table: pd.DataFrame = data.iloc[(io_table_heading_row + 1):(io_table_heading_row+1+table_rows), 1:(table_columns+1)].copy()
            io_table = io_table.astype(float)
            io_table.index = self.io_table_inputs
            io_table.columns=self.io_table_uses

            # Store the table in the dictionary of IO tables, one for each region
            self._io_tables[region] = io_table

    def io_table(self, region: str) -> pd.DataFrame:
        if region in self._io_tables:
            return self._io_tables[region]
        raise Exception("There is no IO table defined for " + region)

    def has_io_table(self, region: str) -> bool:
        return region in self._io_tables

    @ property
    def io_table_inputs(self):
        """
        Returns the row names for each region's IO table.
        """
        input_names = self.sym_data.goods_members
        input_names.extend(
            [self.io_table_labour, self.io_table_capital, self.io_table_tax])
        return input_names

    @ property
    def io_table_tax(self) -> str:
        """
        Returns the tax row label.
        """
        return "TAX"

    @ property
    def io_table_labour(self) -> str:
        """
        Returns the labour row label.
        """
        return "L"

    @ property
    def io_table_capital(self) -> str:
        """
        Returns the capital row label.
        """
        return "K"

    @ property
    def io_table_consumption(self) -> str:
        """
        Returns the consumption column label.
        """
        return "C"

    @ property
    def io_table_investment(self) -> str:
        """
        Returns the investment column label.
        """
        return "I"

    @ property
    def io_table_government(self) -> str:
        """
        Returns the government spending column label.
        """
        return "G"

    @ property
    def io_table_exports(self) -> str:
        """
        Returns the exports column label.
        """
        return "X"

    @ property
    def io_table_imports(self) -> str:
        """
        Returns the imports column label.
        """
        return "M"

    @ property
    def io_table_uses(self):
        """
        Returns the column names for each region's IO table.
        """
        use_names = self.sym_data.sectors_members
        # TODO: Figure out how to interpret the first column.
        use_names.extend([self.io_table_consumption, self.io_table_investment,
                         self.io_table_government, self.io_table_exports, self.io_table_imports])
        return use_names

    def __validate(self):
        """
        Raise an exception if the IO data is invalid
        """
        pass

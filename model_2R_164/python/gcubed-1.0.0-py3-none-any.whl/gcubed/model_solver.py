# ------------------------------------------------------------------
# Purpose: Find a point that solves the equations in the model
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
import logging
import pandas as pd
import numpy as np
import importlib
from gcubed.data.gdp_scaled_database import GDPScaledDatabase
from gcubed.model import Model
from gcubed.base import Base


class ModelSolver(Base):
    """
    Find a point that simultaneously solves the nonlinear equations 
    in the model, taking as given the values for the vectors:
    - yxr
    - yjr
    - exz
    - exo

    If a solution can be found, it will be values for the
    following vectors:
    - x1r
    - j1r
    - zer
    - z1r

    The process will be:
    1. Set up database
    2. Populate all vectors using database values for the linearisation year.
    3. Rearrange the model equations so that we can solve for all vectors by evaluating all 
    of the model equations and then take the RHS of the equation

    TODO: Implement based on logic in TestLinearisationRootFindingModel2R164

    """

    def __init__(self, model: Model, linearisation_year: int ):
        pass

# ------------------------------------------------------------------
# Purpose: Base class that every other class inherits from.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
import logging
import re
import os
import pandas as pd
import numpy as np


class Base:
    """
    Provide convenience methods for all classes.
    """

    # Set to true if you are doing a detailed debug of the model.
    DOING_DETAILED_DEBUG = True

    def __init__(self) -> None:
        np.set_printoptions(formatter={'float': lambda x: "{0:0.4f}".format(x)})
        np.set_printoptions(suppress=True, linewidth=400)
        pass

    def log(self):
        logging.debug(vars(self))

    def zeros(self, rows=1, cols=1) -> pd.DataFrame:
        """
        Create a dataframe filled with zeros.

        Arguments

        rows: the number of dataframe rows

        cols: the number of dataframe columns

        Return a dataframe containing zeros with the given number
        of rows and the given number of columns.
        """
        data: pd.DataFrame = pd.DataFrame(
            index=range(rows), columns=range(cols))
        data = data.replace(np.nan, 0)
        if (len(data.columns)) == 1:
            data.columns = ["value"]
        return data

    def load_data(self, filename: str, name_column: int = 1):
        """
        Loads data from a CSV file, splitting it into two parts,
        the data selected as the columns with a 4 digit column name,
        and the non-data, selected as all other columns.

        This is used to load a variety of different CSV data sources.

        Arguments:

        filename: the name of the CSV file, including the path relative
        to the model root directory.

        name_column: the column of the CSV file that contains the variable
        names, indexed from zero for the first column and defaulting to 1.
        """
        if not os.path.isfile(filename):
            raise Exception(f"Could not load data from {filename} because it does not exist.")

        # Use row 0 (first row) as column headers
        data: pd.DataFrame = pd.read_csv(filename, header=0).dropna(axis='columns')

        # Index rows using the variable names.
        data.index = data.iloc[:, name_column]

        column_names = data.columns
        # Use a regular expression to pick out the data columns.
        regular_expression = re.compile("[1-9][0-9]{3}")
        data_column_names = list(
            filter(regular_expression.match, column_names))
        other_column_names = [
            x for x in column_names if x not in data_column_names]
        variables = data.loc[:,other_column_names]
        data = data.loc[:,data_column_names]
        return (variables, data)

    # Regular expression to match YYYY format year labels.
    __YYY_regular_expression = re.compile("[1-9][0-9]{3}")

    def get_year_labels(self, labels:list[str]) -> list[str]:
        """
        Return all strings in the list that match the YYYY year format.
        """
        return list(filter(__class__.__YYY_regular_expression.match, labels))
        
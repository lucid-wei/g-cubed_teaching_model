# ------------------------------------------------------------------
# Purpose: Compute and provide access to simulations that overlay
# baseline projections and possibly other simulation layers.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
import logging
import os
import pandas as pd
import numpy as np
import gcubed.constants as CONSTANTS
from gcubed.data.database import Database
from gcubed.projections.base_projections import BaseProjections
from gcubed.projections.baseline_projections import BaselineProjections
from gcubed.projections.simulation_layer_definition import SimulationLayerDefinition

class SimulationLayer(BaseProjections):
    """
    TODO: Complete the simulations implementation
    Compute model simulations over the projection horizon.
    """

    def __init__(self, simulation_layer_definition: SimulationLayerDefinition, baseline_projections: BaselineProjections, previous_simulation_layer=None) -> None:
        """
        Use this constructor for any simulation that is the first simulation layer applied to baseline projections.
        """
        assert baseline_projections is not None
        self._baseline_projections = baseline_projections
        self._stable_manifold = self.baseline_projections.stable_manifold

        self._previous_simulation_layer = previous_simulation_layer

        assert simulation_layer_definition is not None
        self._simulation_layer_definition = simulation_layer_definition

        assert os.path.isfile(self.data_file)

        if self.previous_simulation_layer is not None:
            assert self.event_year > self.previous_simulation_layer.event_year
        else:
            assert self.event_year > self.baseline_projections.base_year

        self.load_simulation_data()

        self.__generate_simulation_projections()

        self.generate_database_projections()

        self.generate_publishable_projections()

        self.__validate()

        logging.info(f"The {self.name} projections have been generated.")



    def __validate(self):
        """
        TODO:  Validate the simulations: 
        """

    @property
    def simulation_layer_definition(self) -> SimulationLayerDefinition:
        return self._simulation_layer_definition

    @property
    def name(self) -> str:
        return self._simulation_layer_definition.name

    @property
    def description(self) -> str:
        return self._simulation_layer_definition.description

    @property
    def data_file(self) -> str:
        """
        Returns the string specifying the name of the file containing the simulation data.
        """
        return self.simulation_layer_definition.data_filename

    @property
    def event_year(self) -> str:
        """
        Returns the event year for the simulation layer.
        This is the first year that knowledge of the simulation event becomes available
        to agents.
        """
        return self.simulation_layer_definition.event_year

    @property
    def previous_simulation_layer(self):
        """
        Note that the return type is not specified because the SimulationLayer class cannot
        refer to itself in its own definition.

        Returns the previous simulation layer, or none if there is none.
        """
        if hasattr(self,'_previous_simulation_layer'):
            return self._previous_simulation_layer
        return None

    @property
    def previous_projection_layer(self) -> BaseProjections:
        if self.previous_simulation_layer is None:
            return self.baseline_projections
        return self.previous_simulation_layer

    @property
    def baseline_projections(self) -> BaselineProjections:
        """
        Returns the baseline projections underpinning this simulation
        """
        if self.previous_simulation_layer is not None:
            return self.previous_simulation_layer.baseline_projections
        return self._baseline_projections

    @property
    def database(self) -> Database:
        """
        Returns the database associated with the baseline projections.
        """
        return self.baseline_projections.database

    @property
    def simulation_variables(self) -> pd.DataFrame:
        """
        Returns the variable summary information for the simulation data.
        """
        return self._simulation_variables

    @property
    def simulation_data(self) -> pd.DataFrame:
        """
        Returns the simulation data.
        """
        return self._simulation_data

    def load_simulation_data(self):
        """
        
        TODO: Check if there are simulations where shocks to state variable initial values are not allowed.

        Load and apply the simulation data that affect exogenous variables. 
        Load and apply the simulation data that affect state variables initial values.
        
        When a variable has data in the simulation file, load that into the appropriate 
        SYM-specified row of the exogenous variable projections, from the start projection year onwards.

        When a variable has data in the simulation file (control.csv by default), load that into the appropriate 
        SYM-specified row of the state variable projection start year vector and ignore
        data in the control file for all years after that projection start year.

        Adjust the simulation data as follows, depending on the units of the variable:
            gdp - multiply by (projection base year YRATR / 100).
            mmgdp - same as gdp
            btugdp - same as gdp 
            gwhgdp - same as gdp
            usgdp - divide the value in the control file by 100.
            All other units - divide the value in the control file by 100.
        """

        # Load the simulation data.
        filename: str = self.data_file
        assert os.path.isfile(filename)
        (self._simulation_variables, self._simulation_data) = self.load_data(filename)
        self._simulation_variables.columns = ['name']
        self._simulation_variables.index = self._simulation_variables.name
        self._simulation_data = self._simulation_data.astype(float)
        self._simulation_data.index = self._simulation_variables.name

        try:
            self._simulation_data = self._simulation_data.loc[:, self.projection_years_column_labels]
        except:
            raise Exception(f"The simulation data in {self.data_file} should have data from {self.event_year} to {self.end_year}")

        # Iterate the shocks, allocating the shocks
        yratr: pd.DataFrame = self.baseline_projections.database.get_data(name_regular_expression=f"^{CONSTANTS.US_REAL_GDP_RATIO_PREFIX}\(", years=[self.base_year])
        yratr.index = self.sym_data.regions_members

        for variable_name in self._simulation_variables.index:
            variable_region: str = str(self.baseline_projections.database.variables.loc[variable_name, 'region'])
            variable_units: str = str(self.sym_data.combined_variable_summary.loc[variable_name, 'units'])
            data: pd.DataFrame = self._simulation_data.loc[[variable_name], :] / 100
            vector_name = self.sym_data.projection_vector_for_variable(variable_name=variable_name)
            variable_sequence: int = self.sym_data.variable_index(vector_name=vector_name, variable_name=variable_name)
            yratr_for_region: float = float(yratr.loc[variable_region, :].values[0])
            match variable_units:
                case 'gdp':
                    data = data * yratr_for_region
                case 'mmgdp':
                    data = data * yratr_for_region
                case 'btugdp':
                    data = data * yratr_for_region
                case 'gwhgdp':
                    data = data * yratr_for_region
                case _:
                    pass

            self._exo_projections = self.previous_projection_layer.exo_projections_as_dataframe.loc[:, self.projection_years_column_labels]

            x1_initial_values: pd.DataFrame = self.previous_projection_layer.yxr_projections_as_dataframe.loc[:, [str(self.event_year)]].copy()

            match vector_name:
                case 'exo':
                    self._exo_projections.loc[[variable_name], self.projection_years_column_labels] += data
                    pass

                case 'x1l':
                    x1_initial_values.loc[[variable_name], [str(self.event_year)]] += float(data[0])
                    pass

            self._x1_initial_values: np.ndarray = x1_initial_values.to_numpy()


    def compute_functions_of_future_exogenous_variables(self):
        """
        The rules governing the dynamic behaviour of variables depend on functions of the current and future exogenous variables.
        These functions are evaluated and the results are stored in numpy matrices that match the number of rows
        for the related vector of variables and that have a column for each year from the base projection year to the
        last year in the projections.
        """

        # Set up the arrays that will be populated and initialise them to zeros.

        # This is equivalent to h3t in the newsetsymbl.ox script (j by 1 dimensions)
        self._h3t: np.ndarray = np.zeros(shape=(self.sym_data.vector_length(vector_name='j1l'), self.projection_years_count))

        # Populate for period T.

    	# c4t=invert(unit(nez)-zel_exz_ssf)*cz5   (r by 1 dimensions)
        interim_calculation = self.stable_manifold.Gamma_rT @ self.baseline_projections.ze_constants

        # c6t = invert(unit(j)-j1l_yjr_ssf-j1l_exz_ssf*mu2t) * (cz4+j1l_exz_ssf*c4t)
        # c6t = invert(unit(j)-j1l_yjr_ssf-j1l_exz_ssf*mu2t) * (cz4+j1l_exz_ssf*c4t)
        #     = Gamma_jT (cz4+j1l_exz_ssf*interim_calculation)
        c6T_column = self.stable_manifold.Gamma_jT @ (self.baseline_projections.j1_constants + self.state_space_form.delta('j1l', 'exz') @ interim_calculation)

    	# c4t = c4t + mu2t * c6t (r by 1 dimensions)
        c4T_column = interim_calculation + self.stable_manifold.psi_rj @ c6T_column

        # c4t=ones(rows(c4t),nobs).*c4t (r by T dimensions)
        self._c4t: np.ndarray = np.tile(c4T_column, (1, self.projection_years_count))

        # c6t=ones(rows(c6t),nobs).*c6t (j by T dimensions)
        c6t: np.ndarray = np.tile(c6T_column, (1, self.projection_years_count))

        # c2t=h2t*exog+c6t    (j by T dimensions)
        c2t: np.ndarray = self.stable_manifold.H2 @ self.exo_projections + c6t

        # (s by T dimensions)
        c5t: np.ndarray = np.zeros(shape=(self.sym_data.vector_length(vector_name='x1l'), self.projection_years_count))

        # (j by T dimensions)
        c2t_lead: np.ndarray = c2t.copy()
        c4t_lead: np.ndarray = self._c4t.copy()

        # Populate for earlier periods.
        j = self.projection_years_count-1
        for k in range(self.projection_years_count-1, -1, -1):

            # c5t[][k] = wvi*(x1l_exz_ssf*c4tl[][j] + cz2)          (s by 1 : note no need for T columns)
            c5t: np.ndarray = self.stable_manifold.Gamma_st @ (self.state_space_form.delta('x1l', 'exz') @
                                                               c4t_lead[:, [j]] + self.baseline_projections.x1_constants)

            # c6t[][k] = fdeltinv*(th6t*c5t[][k] - j1l_exz_ssf*c4tl[][j] + c2tl[][j] - cz4)         (j rows)
            c6t[:, [k]] = self.stable_manifold.Gamma_jt @ (self.stable_manifold.common_factor @ c5t - self.state_space_form.delta(
                'j1l', 'exz') @ c4t_lead[:, [j]] + c2t_lead[:, [j]] - self.baseline_projections.j1_constants)

            # c5t[][k] = c5t[][k] + th2t*c6t[][k]
            c5t = c5t + self.stable_manifold.tau_sjt @ c6t[:, [k]]

            # c4t[][k] = mu1tl*c5t[][k] + c4tl[][j]
            self._c4t[:, [k]] = self.stable_manifold.M1_lead @ c5t + c4t_lead[:, [j]]

            # h3t[][k] = c6t[][k]
            self._h3t[:, [k]] = c6t[:, [k]].copy()

            # c2t[][k] = h2t*exog[][k] + h3t[][k]
            c2t[:, [k]] = self.stable_manifold.H2 @ self.exo_projections[:, [k]] + self._h3t[:, [k]]

            # c4tl[][k] = nmu4t*exog[][k] + zel_yjr_ssf*h3t[][k] + zel_exz_ssf*c4t[][k] + cz5
            c4t_lead[:, [k]] = self.stable_manifold.M2 @ self.exo_projections[:, [k]] + \
                self.state_space_form.delta('zel', 'yjr') @ self._h3t[:, [k]] + \
                self.state_space_form.delta('zel', 'exz') @ self._c4t[:, [k]] + \
                self.baseline_projections.ze_constants

            c2t_lead = c2t.copy()

            j = k


    @property
    def h3t(self) -> np.ndarray:
        """
        Equivalent to h3t in the Ox implementation
        Functions of current and future exogenous variables affecting J1.
        """
        return self._h3t

    @property
    def c4t(self) -> np.ndarray:
        """
        Equivalent to c4t in the Ox implementation
        Functions of current and future exogenous variables affecting ZE.
        """
        return self._c4t

    def __generate_simulation_projections(self):
        """
        Implements the projection logic in msgsimBL2.ox.

        Recalculate the functions of future exogenous variables, incorporating 
        the updated exogenous variable projections and  all constant adjustments, 
        the intertemporal constants and the other constants  capturing the difference 
        between the SSF equation results in the base year and the observed 
        values in the base year.
        
        Do the actual projection calculations
        Set up properties so that baseline projections are available for all vectors.

        Re-sort the variable projections into the same order as the original database.

        Set up property to access baseline projections as the original data in CSV format.

        """
        # Recalculate functions of future exogenous variables now that cycle information is included
        self.compute_functions_of_future_exogenous_variables()

        # Project the state variables, X1, and store in dataframe X.
        constantBL: pd.DataFrame = pd.DataFrame(self.stable_manifold.Znew @ self.exo_projections +
            self.state_space_form.delta('x1l', 'yjr') @ self.h3t +
            self.state_space_form.delta('x1l', 'exz') @ self.c4t +
            self.baseline_projections.x1_constants)

        constantBL.columns = self.projection_years_column_labels
        constantBL.index = self.sym_data.vector_variable_names(vector_name='x1l')
        yxr: pd.DataFrame = self.zeros(rows=self.sym_data.vector_length('x1l'), cols=self.projection_years_count)
        yxr.columns = self.projection_years_column_labels
        yxr.index = self.sym_data.vector_variable_names(vector_name='x1l')
        yxr.loc[:, [str(self.event_year)]] = self._x1_initial_values
        previous_year_label = str(self.event_year)
        for year in self.projection_years_column_labels[1:]:
            yxr.loc[:, [year]] = self.stable_manifold.Anew @ yxr.loc[:, [previous_year_label]].to_numpy() + \
                constantBL.loc[:, [previous_year_label]].to_numpy()
            previous_year_label = year
        self._yxr_projections: pd.DataFrame = yxr

        # Project J1
        # er = h1t*x + h2t*exog[][1:nobs] + h3t
        # yjr: pd.DataFrame = pd.DataFrame(self.stable_manifold.H1 @ (yxr.to_numpy()))
        yjr: pd.DataFrame = pd.DataFrame(self.stable_manifold.H1 @ (yxr.to_numpy()) + self.stable_manifold.H2 @ self.exo_projections + self.h3t)
        yjr.columns = self.projection_years_column_labels
        yjr.index = self.sym_data.vector_variable_names(vector_name='j1l')
        self._yjr_projections: pd.DataFrame = yjr

        # Project time t expected value of ZE in period t+1 (EXZ)
        # Project time t expected value of ZE in period t+1 (EXZ)
        # tzl = mu1t*x + mu4t*exog[][1:nobs] + c4t
        exz: pd.DataFrame = pd.DataFrame(
            self.stable_manifold.mu1 @ yxr.to_numpy() +
            self.stable_manifold.mu2 @ self.exo_projections +
            self.c4t
        )
        exz.columns = self.projection_years_column_labels
        exz.index = self.sym_data.vector_variable_names(vector_name='zer')
        self._exz_projections: pd.DataFrame = exz

        # Project time t values of ZE using the SSF equation (this should be done with M1 and M2?)
        # What about the functions of future exogenous variables and the constant adjustments
        zel: pd.DataFrame = pd.DataFrame(
            self.state_space_form.delta('zel', 'yxr') @ self.yxr_projections +
            self.state_space_form.delta('zel', 'exz') @ self.exz_projections +
            self.state_space_form.delta('zel', 'yjr') @ self.yjr_projections +
            self.state_space_form.delta('zel', 'exo') @ self.exo_projections)
        zel.columns = self.projection_years_column_labels
        zel.index = self.sym_data.vector_variable_names(vector_name='zel')
        self._zel_projections: pd.DataFrame = zel + self.baseline_projections.ze_constants

        # Project Z1 using the SSF equation
        z1l: pd.DataFrame = pd.DataFrame(
            self.state_space_form.delta('z1l', 'yxr') @ self.yxr_projections +
            self.state_space_form.delta('z1l', 'exz') @ self.exz_projections +
            self.state_space_form.delta('z1l', 'yjr') @ self.yjr_projections +
            self.state_space_form.delta('z1l', 'exo') @ self.exo_projections)
        z1l.columns = self.projection_years_column_labels
        z1l.index = self.sym_data.vector_variable_names(vector_name='z1l')
        self._z1l_projections: pd.DataFrame = z1l + self.baseline_projections.z1_constants

        # Combine the projections into a single dataframe in the same order as the database
        self._projections = pd.concat([
            self.yxr_projections_as_dataframe,
            self.z1l_projections_as_dataframe,
            self.zel_projections_as_dataframe,
            self.yjr_projections_as_dataframe,
            self.exo_projections_as_dataframe])
        database_ordered_variable_list: pd.DataFrame = self.baseline_projections.database.variables.name
        self._projections = pd.concat([database_ordered_variable_list, self._projections], axis=1)
        self._projections.drop('name', inplace=True, axis=1)

        # Concatenate with the projections from the previous layer to get complete projections from the base projection
        # year through to the end projection year
        self._projections = pd.concat([self.previous_projection_layer.projections.loc[:, self.preceding_projection_years_column_labels], self.projections], axis=1)

        self._projections = self._projections.astype(float)

# ------------------------------------------------------------------
# Purpose: Base class for baseline projections and simulations
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
import logging
import pandas as pd
import numpy as np
import gcubed.constants as CONSTANTS
from gcubed.base import Base
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData
from gcubed.model import Model
from gcubed.model_parameters.parameters import Parameters
from gcubed.state_space_form import StateSpaceForm
from gcubed.stable_manifold import StableManifold

class BaseProjections(Base):
    """
    Base class for simulations and for Baseline Projections.
    """

    @classmethod
    def get_deviations_between_projections(cls, new_projections:pd.DataFrame, original_projections:pd.DataFrame) -> pd.DataFrame:
        """
        Arguments:

        new_projections: A dataframe of projections

        original_projections: A second dataframe of projections

        Produce a dataframe of differences between two projections (new_projections - original_projections).

        Note that this can be used for raw, database, publishable and graphable projection types. However, the new 
        and original projections must be the same type for the results to be meaningful.

        Raises exceptions if the dataframes have different indexes or different columns.
        """

        if not new_projections.index.equals(original_projections.index):
            raise Exception("The two sets of projections are not for identical lists of variables. Make sure they are both for the same model.")
        if not new_projections.columns.equals(original_projections.columns):
            raise Exception("The two sets of projections are not for identical years so differences between them cannot be calculated.")
        
        return (new_projections - original_projections)

    def __init__(self, stable_manifold: StableManifold) -> None:

        assert stable_manifold is not None
        assert stable_manifold.converged
        self._stable_manifold = stable_manifold
        self._event_year = self.base_year # gets overridden by subclasses.
        self.__validate()

    def __validate(self):
        """
        TODO:  Validate the projections: 
        1. check that they are available for the expected projection years.
        2. Check that the base year projections are equal to the base year data values.
        """
        pass

    @property
    def stable_manifold(self) -> StableManifold:
        return self._stable_manifold

    @property
    def state_space_form(self) -> StateSpaceForm:
        return self.stable_manifold.ssf

    @property
    def model(self) -> Model:
        return self.state_space_form.model

    @property
    def sym_data(self) -> SymData:
        return self.model.sym_data

    @property
    def parameters(self) -> Parameters:
        return self.model.parameters

    @property
    def configuration(self) -> ModelConfiguration:
        return self.sym_data.configuration

    @property
    def base_year(self) -> int:
        return self.configuration.projection_base_year

    @property
    def end_year(self) -> int:
        return self.configuration.end_year

    @property
    def event_year(self) -> int:
        return self._event_year

    @property
    def projection_years(self) -> list[int]:
        """
        Returns the list of years for projections from the event year through to 
        and including the projection end year.
        """
        return range(self.event_year, self.end_year+1)

    @property
    def projection_years_count(self) -> list[int]:
        return (self.end_year - self.event_year + 1)

    @property
    def projection_years_column_labels(self) -> list[str]:
        return [str(x) for x in self.projection_years]

    @property
    def preceding_projection_years(self) -> list[int]:
        """
        Returns the list of years for projections from the base year through to but
        not including the event year for this baseline projection or simulation layer.
        """
        return range(self.base_year, self.event_year)

    @property
    def preceding_projection_years_count(self) -> list[int]:
        return (self.event_year - self.base_year)

    @property
    def preceding_projection_years_column_labels(self) -> list[str]:
        return [str(x) for x in self.preceding_projection_years]

    @property
    def simulation_data_columns(self) -> list[str]:
        """
        Returns the list of years (YYYY format) as strings from the event year to the
        end year in the projections.
        """
        return [str(x) for x in range(self.event_year, self.configuration.end_year+1)]

    @property
    def projections(self) -> pd.DataFrame:
        """
        Returns the dataframe of projections for all variables in the model that are part of the 
        4 vectors specified. There still need to be additional variable projected that are computed
        outside of the system to take non-linearity into account (eg long-term interest rates.)
        """
        if hasattr(self, '_projections'):
            return self._projections
        raise Exception(f"The projections for all variables are not yet available for this {type(self)}.")

    @property
    def database_projections(self) -> pd.DataFrame:
        """
        Returns the dataframe of projections for all variables in the model in forms that are consistent with
        the values contained in the original model database.
        """
        if hasattr(self, '_database_projections'):
            return self._database_projections
        raise Exception(f"The database projections for all variables are not yet available for this {type(self)}.")

    @property
    def publishable_projections(self) -> pd.DataFrame:
        """
        Returns the dataframe of projections for all variables in the model.
        """
        if hasattr(self, '_publishable_projections'):
            return self._publishable_projections
        raise Exception(f"The publishable projections for all variables are not yet available for this {type(self)}.")

    @property
    def yxr_projections_as_dataframe(self) -> pd.DataFrame:
        """
        Get yxr variable projection values
        of the projection years as a dataframe.
        """
        if hasattr(self, '_yxr_projections'):
            return self._yxr_projections
        raise Exception(f"The period t state variable projections (yxr) are not yet available for this {type(self)}.")

    @property
    def yxr_projections(self) -> np.ndarray:
        """
        Get yxr variable projection values
        of the projection years.
        """
        if hasattr(self, '_yxr_projections'):
            return self._yxr_projections.to_numpy()
        raise Exception(f"The period t state variable projections are not yet available for this {type(self)}.")

    @property
    def yjr_projections_as_dataframe(self) -> pd.DataFrame:
        """
        Get yjr variable projection values
        of the projection years as a dataframe.
        """
        if hasattr(self, '_yjr_projections'):
            return self._yjr_projections
        raise Exception(f"The period t costate variable projections (yjr) are not yet available for this {type(self)}.")

    @property
    def yjr_projections(self) -> np.ndarray:
        """
        Get yjr variable projection values
        of the projection years.
        """
        if hasattr(self, '_yjr_projections'):
            return self._yjr_projections.to_numpy()
        raise Exception(f"The period t costate variable projections (yjr) are not yet available for this {type(self)}.")

    @property
    def exz_projections_as_dataframe(self) -> pd.DataFrame:
        """
        Get exz variable projection values
        of the projection years as a dataframe.
        """
        if hasattr(self, '_exz_projections'):
            return self._exz_projections
        raise Exception(f"The period t expected values for t+1 variables projections (exz) are not yet available for this {type(self)}.")

    @property
    def exz_projections(self) -> np.ndarray:
        """
        Get exz variable projection values
        of the projection years.
        """
        if hasattr(self, '_exz_projections'):
            return self._exz_projections.to_numpy()
        raise Exception(f"The period t expected values for t+1 variables projections (exz) are not yet available for this {type(self)}.")

    @property
    def zel_projections_as_dataframe(self) -> pd.DataFrame:
        """
        Get zel variable projection values
        of the projection years as a dataframe.
        """
        if hasattr(self, '_zel_projections'):
            return self._zel_projections
        raise Exception(f"The period t ZEL projections are not yet available for this {type(self)}.")

    @property
    def zel_projections(self) -> np.ndarray:
        """
        Get zel variable projection values
        of the projection years.
        """
        if hasattr(self, '_zel_projections'):
            return self._zel_projections.to_numpy()
        raise Exception(f"The period t ZEL projections are not yet available for this {type(self)}.")

    @property
    def z1l_projections_as_dataframe(self) -> pd.DataFrame:
        """
        Get z1l variable projection values
        of the projection years as a dataframe.
        """
        if hasattr(self, '_z1l_projections'):
            return self._z1l_projections
        raise Exception(f"The period t Z1L projections are not yet available for this {type(self)}.")

    @property
    def z1l_projections(self) -> np.ndarray:
        """
        Get z1l variable projection values
        of the projection years.
        """
        if hasattr(self, '_z1l_projections'):
            return self._z1l_projections.to_numpy()
        raise Exception(f"The period t Z1L projections are not yet available for this {type(self)}.")

    @property
    def exo_projections_as_dataframe(self) -> pd.DataFrame:
        """
        Get exogenous variable projection values
        of the projection years as a dataframe.
        """
        if hasattr(self, '_exo_projections'):
            return self._exo_projections
        raise Exception(f"The exogenous variable projections are not yet available for this {type(self)}.")

    @property
    def exo_projections(self) -> np.ndarray:
        """
        Get exogenous variable projection values
        of the projection years.
        """
        if hasattr(self, '_exo_projections'):
            return self._exo_projections.to_numpy()
        raise Exception(f"The exogenous variable projections are not yet available for this {type(self)}.")

    def longrate_calculation(self, term: int, rates: pd.DataFrame) -> pd.DataFrame:
        """
        Utility method that returns the compounding long rates given the yearly rates.

        Rates are provided as decimal values so 1% is 0.01.
 
        Arguments:

        term: the number of years of the term of the instrument. 2 for a 2 year bond.

        rates: the projections of the 1 year interest rates, (nominal or real).

        Returns the long rates that can be computed from the one year rates. This series is shorter
        than the series of one year rates because the required data is not available for 
        the last (term-1) observations. It is padded with NaN values in the returned projection.
        """
        shortrates = rates.copy()
        name_suffix = str(shortrates.index[0]).split('(')[1]
        longrates_columns = shortrates.iloc[:, 0:(len(shortrates.columns)-term+1)].columns
        preceding_year: int = int(shortrates.columns[0])-1
        shortrates = shortrates + 1

        shortrates = shortrates.cumprod(axis='columns')
        shortrates.insert(0, str(preceding_year), 1.0)

        longrates: pd.DataFrame = pd.DataFrame(np.power(shortrates.iloc[:, term:].to_numpy() / shortrates.iloc[:, 0:-term:1].to_numpy(), 1/term) - 1.0)
        longrates.columns = longrates_columns
        match str(rates.index[0]).split('(')[0]:
            case 'INTN':
                match term:
                    case 2:
                        long_rate_name = 'NB02'
                    case 5:
                        long_rate_name = 'NB05'
                    case 10:
                        long_rate_name = 'NB10'
                    case _:
                        raise Exception(f"Invalid nominal bond term specified: {term}")
            case "INTR":
                match term:
                    case 2:
                        long_rate_name = 'RB02'
                    case 5:
                        long_rate_name = 'RB05'
                    case 10:
                        long_rate_name = 'RB10'
                    case _:
                        raise Exception(f"Invalid real bond term specified: {term}")
            case _:
                raise Exception(f"Invalid variable used to compute bond rates: {str(rates.index[0])}. Use a 1 year interest rate.")
        longrates.index = [ f"{long_rate_name}({name_suffix}" ]
        return longrates.astype(float)

    @property
    def long_rate_constants(self):
        """
        The constant adjustments to long bond rates 
        (real and nominal) in the base projection year 
        to ensure projections equal observed values.
        """
        return self._long_rate_constants

    def generate_database_projections(self):
        """
        Converts the raw projections into projections that are consistent with the database being used
        by the model. These projections can be spliced on to the original database (as opposed to the
        GDP scaled database) that was loaded with the model used to produce the projections.

        Implements the first parts of the projection conversion logic in datamsymbl.ox.

        Step 1.
        Get a copy of the raw projections.

        Step 2b.
        Divide the projections by YRATR in the projection base year for every variable that has units of:
            gdp
            mmtgdp
            btugdp
            gwhgdp
        This ensures that the resulting values are comparable to the original database aside from scaling by 100.

        # Step 3.
        At this stage the interest rates are expressed as decimals so 0.02 is a 2% interest rate.
        Adjust the interest rate variables using the intcons adjustment, adding the difference between 
        the base-projection year interest rate and the assumed neutral real interest rate to each of the interest 
        rate variables.
        This ensures that the result short interest rates are comparable to the original database, aside from scaling by 100.

        # Step 4.
        Generate long rates from short rates
        This ensures that the long interest rates are derived from the short rates.
         
        # Step 5.
        Adjust long rate projections by adding long rate constants that
        are calculated to ensure that the long rates are equal to the 
        observed values in the base projection year.
        This ensures that the long interest rates are comparable to the original database aside from scaling by 100.

        Step 6.
        Multiply projection values by 100
        This ensures that the projections are scaled in the same way as the original database.

        Step 7.
        Get LGDPR (real GDP level) data in the projection base year for each 
        region and grow over projection years at rate given by 'labgrow' parameter.
        Store the LGDPR projections in the publishable projections dataset.

        Saves the result in the _database_projections property.

        These database projections should be associated with the publication_units of measurement
        available from the sym_data variable summary.

        """

        # Step 1.
        database_projections: pd.DataFrame = self.projections.copy()

        # Step 2.
        yratr_data: pd.DataFrame = self.database.data.loc[self.database.variables.name.str.startswith("YRATR("), str(self.base_year)].copy()
        yratr_data.index = self.sym_data.regions_members
        for variable_name, variable_projection in database_projections.iterrows():
            units: str = str(self.database.variables.loc[variable_name,'units'])
            match units:
                case 'gdp' | 'btugdp' | 'mmtgdp' | 'gwhgdp':
                    variable_region: str = str(self.database.variables.loc[variable_name, 'region'])
                    factor: float = yratr_data.loc[variable_region]
                    database_projections.loc[[variable_name], :] /= factor

        # Step 3.
        # Make the adjustment for the neutral real interest rate.
        for prefix in CONSTANTS.INTEREST_RATE_PREFIXES:
            variable_names = self.database.variables.loc[self.database.variables.name.str.startswith(f"{prefix}("), 'name']
            for variable_name in variable_names:
                database_projections.loc[[variable_name], :] += (float(self.database.data.loc[variable_name, str(self.base_year)] - self.configuration.neutral_real_interest_rate))

        # Step 4.
        # Calculate the long rates.
        real_interest_rates: pd.DataFrame = database_projections.loc[database_projections.index.str.startswith("INTR("), str(self.base_year):].copy()
        for variable_name in real_interest_rates.index:
            rb10: pd.DataFrame = self.longrate_calculation(term=10, rates=real_interest_rates.loc[[variable_name], :])
            database_projections.loc[[str(rb10.index[0])], :] = rb10
        nominal_interest_rates: pd.DataFrame = database_projections.loc[database_projections.index.str.startswith("INTN("), str(self.base_year):].copy()
        for variable_name in nominal_interest_rates.index:
            nb02: pd.DataFrame = self.longrate_calculation(term=2, rates=nominal_interest_rates.loc[[variable_name], :])
            database_projections.loc[[str(nb02.index[0])], :] = nb02
            nb05: pd.DataFrame = self.longrate_calculation(term=5, rates=nominal_interest_rates.loc[[variable_name], :])
            database_projections.loc[[str(nb05.index[0])], :] = nb05
            nb10: pd.DataFrame = self.longrate_calculation(term=10, rates=nominal_interest_rates.loc[[variable_name], :])
            database_projections.loc[[str(nb10.index[0])], :] = nb10

        # Step 5.
        # Determine the constants to add to the long rates to match base projection year observed and projected values.
        self._long_rate_constants: pd.DataFrame = None
        for prefix in CONSTANTS.BOND_RATE_PREFIXES:
            observed_values: pd.DataFrame = self.database.data.loc[self.database.variables.name.str.startswith(f"{prefix}("), [str(self.base_year)]].copy()
            projected_values: pd.DataFrame = database_projections.loc[database_projections.index.str.startswith(f"{prefix}("), [
                str(self.base_year)]].copy()
            constants: pd.DataFrame = observed_values - projected_values
            constants.columns = [str(self.base_year)]
            constants.index = observed_values.index
            if self._long_rate_constants is None:
                self._long_rate_constants = constants
            else:
                self._long_rate_constants = pd.concat([self._long_rate_constants, constants], axis=0)

        # Add the long rate constants to the long rate projections to line the long rate projections
        # up with observed data in the base projection year.
        for variable_name in self.long_rate_constants.index:
            database_projections.loc[[variable_name], :] += self.long_rate_constants.loc[variable_name, str(self.base_year)]

        # Step 6.
        database_projections *= 100.0

        # Step 7.
        rows_containing_LGDPR_data = self.database.variables.name.str.startswith("LGDPR(")
        lgdpr_data: pd.DataFrame = self.database.data.loc[rows_containing_LGDPR_data, [str(self.base_year)]].copy() / 100
        us_longrun_effective_labour_productivity_index: pd.DataFrame = self.model.effective_labour_productivity.us_longrun_effective_labour_index.loc[:,self.configuration.base_and_projection_years_column_labels]
        lgdpr_longrun_projections: pd.DataFrame = pd.DataFrame(lgdpr_data.values * us_longrun_effective_labour_productivity_index.values)
        lgdpr_longrun_projections.columns = self.configuration.base_and_projection_years_column_labels
        lgdpr_longrun_projections.index = lgdpr_data.index # Index with the LGDPR full variable names
        database_projections.loc[rows_containing_LGDPR_data, :] = lgdpr_longrun_projections.copy()

        # Splice on the actual data from the model database
        for column in self.model.database.data.columns[::-1]:
            if not (column in database_projections.columns):
                if int(column) < int(database_projections.columns[0]):
                    database_projections.insert(0, column, self.model.database.data.loc[:,column], True)
                else:
                    break

        # Save the results for use later.
        self._database_projections = database_projections.astype(float)

    def generate_publishable_projections(self):
        """

        Uses the real GDP trend growth projections to adjust 
        the projections of all variables with units equal to 
        'usgdp' or 'gdp'.

        Implements the real GDP scaling part of the projection conversion logic in datamsymbl.ox.

        Step 1.
        For all projections with units equal to usgdp, multiply the projection 
        by the US LGDPR projection computed in step 4 when producing the database projections.

        Step 2.
        For all projections with units equal to 'gdp', multiply the projection by the associated
        region's LGDPR projection computed in step 4 when producing the database projections.

        These publishable projections should be associated with the publication_units of measurement
        available from the sym_data variable summary.

        Saves the result in the _publishable_projections property.
        """

        publication_projections: pd.DataFrame = self.database_projections.copy()

        # Real GDP scaling
        lgdpr_database_projections: pd.DataFrame = self.database_projections.loc[self.database_projections.index.str.startswith("LGDPR("), :].copy()
        lgdpr_database_projections.index = self.model.sym_data.regions_members
        for variable_name in publication_projections.index:
            variable_units: str = str(self.database.variables.loc[variable_name,'units'])
            match variable_units:
                case 'usgdp' | 'mmtusgdp' | 'btuusgdp':
                    publication_projections.loc[[variable_name], :] *= lgdpr_database_projections.loc[[CONSTANTS.USA_REGION_CODE],:].values
                case 'gdp' | 'mmtgdp' | 'btugdp' | 'gwhgdp':
                    variable_region: str = str(self.database.variables.loc[variable_name, 'region'])
                    publication_projections.loc[[variable_name], :] *= lgdpr_database_projections.loc[[variable_region],:].values

        # Save the results for use later.
        self._publishable_projections = publication_projections.astype(float)

    @property
    def graphable_projections(self) -> pd.DataFrame:
        """
        Produces publishable projections in a format suitable 
        for loading into graphing systems such as R.

        The publishable projections are transposed so there is 
        a column for each variable and a row for each year.
        """
        result: pd.DataFrame = self.publishable_projections.copy().transpose()
        result.index = self.model.configuration.all_years
        return result


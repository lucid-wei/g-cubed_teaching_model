# ------------------------------------------------------------------
# Purpose: An ordered list of simulation layer definitions.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------

import os
import os.path
import pandas as pd
from gcubed.base import Base
from gcubed.model_configuration import ModelConfiguration
from gcubed.projections.simulation_layer_definition import SimulationLayerDefinition
from gcubed.sym_data import SymData


class SimulationLayerDefinitions(Base):
    """
    An event_year ordered list of simulation layer definitions.

    The ordered list implemented as a singly linked list.

    It supports addition, removal and iteration of simulation layer definitions.
    """

    def __init__(self, sym_data: SymData) -> None:
        """Create an empty ordered list of SimulationLayerDefinitions"""

        assert sym_data is not None
        self._sym_data = sym_data

        self.head: SimulationLayerDefinition = None
        self.size = 0

    @property
    def sym_data(self) -> SymData:
        return self._sym_data

    @property
    def configuration(self) -> ModelConfiguration:
        return self.sym_data.configuration

    def __len__(self):
        """Return the number of SimulationLayerDefinitions in the list"""
        return self.size

    def __iter__(self):
        """Return an iterator over the SimulationLayerDefinitions in the list"""
        current = self.head
        while current:
            yield current
            current = current.next

    def add(self, simulation_layer_definition: SimulationLayerDefinition):
        """Insert a SimulationLayerDefinition into the list in the correct order"""
        if self.head is None or simulation_layer_definition.event_year <= self.head.event_year:
            simulation_layer_definition.next = self.head
            self.head = simulation_layer_definition
        else:
            current: SimulationLayerDefinition = self.head
            while current.next and current.next.event_year <= simulation_layer_definition.event_year:
                current = current.next
            simulation_layer_definition.next = current.next
            current.next = simulation_layer_definition
        self.size += 1

    def remove(self, simulation_layer_definition: SimulationLayerDefinition):
        """Remove a SimulationLayerDefinition from the list"""
        current = self.head
        previous = None
        while current is not None:
            if current == simulation_layer_definition:
                if previous is None:
                    self.head = current.next
                else:
                    previous.next = current.next
                self.size -= 1
                return
            previous = current
            current = current.next
            raise ValueError(f"The simulation layer definition {simulation_layer_definition.name} was not found in the list.")

    def get_simulation_layer_definition(self, simulation_name: str) -> SimulationLayerDefinition:
        """
        Arguments:

        simulation_name: The name of the simulation to retrieve details for.

        Returns the definition for a named simulation layer.
        """
        for candidate in self:
            if candidate.name == simulation_name:
                return candidate
        raise Exception(f"There is no simulation layer named {simulation_name}")

    def load_from_csv_file(self, design_file: str):
        """

        Arguments:

        design_file: the name and relative path to the experiment configuration file from the simulations directory,
            e.g. 'example_experiment/design.csv'

        Loads the simulation layer definitions from a CSV file that lists the files along with other details of each simulation layer.
        The CSV file columns are expected to be, in the following order:
        name - the name of the simulation layer
        data - the name of the simulation layer data file. The data files are expected to be in the same directory
        as the CSV design file that defines the simulation layers.
        event_year - the event year for the simulation layer.
        description - the text description of the simulation layer.
        """

        filename: str = f"{self.configuration.simulations_directory}{design_file}"

        if not filename:
            raise Exception("An experiment design file is required to set up a simulation experiment.")

        if not os.path.isfile(filename):
            raise Exception(f"Experiment design file {filename} does not exist.")

        data_files_directory = f"{os.path.dirname(filename)}/"

        simulations: pd.DataFrame = pd.read_csv(filename, header=0)

        for simulation_details in simulations.itertuples(index=False):
            simulation_layer_definition: SimulationLayerDefinition = SimulationLayerDefinition(
                sym_data=self.sym_data,
                name=simulation_details.name,
                event_year=int(simulation_details.event_year),
                data_filename=f"{data_files_directory}{simulation_details.data}",
                description=simulation_details.description)
            self.add(simulation_layer_definition=simulation_layer_definition)

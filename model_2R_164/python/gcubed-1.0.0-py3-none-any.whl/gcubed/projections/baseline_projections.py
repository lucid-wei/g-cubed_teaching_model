# ------------------------------------------------------------------
# Purpose: Compute and provide access to baseline projections.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
import logging
import os
import pandas as pd
import numpy as np
import gcubed.constants as CONSTANTS
from gcubed.stable_manifold import StableManifold
from gcubed.model import Model
from gcubed.state_space_form import StateSpaceForm
from gcubed.sym_data import SymData
from gcubed.model_parameters.parameters import Parameters
from gcubed.model_configuration import ModelConfiguration
from gcubed.data.gdp_scaled_database import GDPScaledDatabase
from gcubed.baseline.effective_labour_productivity import EffectiveLabourProductivity
from gcubed.baseline.energy_usage_efficiency import EnergyUsageEfficiency
from gcubed.projections.base_projections import BaseProjections
from gcubed.projections.simulation_layer_definitions import SimulationLayerDefinitions
from gcubed.projections.simulation_layer_definition import SimulationLayerDefinition


class BaselineProjections(BaseProjections):
    """
    Compute the baseline model projections over the projection horizon 
    from the base projection year (the last year with available data)
    through to the last projection year.
    """

    # The perturbation to use when computing partial derivatives for intertemporal constant determination.
    PERTURBATION = 0.0001

    def __init__(self, stable_manifold: StableManifold, simulation_layer_definitions: SimulationLayerDefinitions = None) -> None:
        """
        Arguments:

        stable_manifold: The stable manifold that provides access to all of the model information required to produce projections.

        simulation_layer_definitions: An optional input that provides an ordered list of simulation layer definitions 
        that can be used to augment the initial state vector and the exogenous variable projections that underpin the projections. 
        The simulation layers are ignored if they have an event year that is not equal to the base projection year.
        """
        super().__init__(stable_manifold=stable_manifold)

        self._simulation_layer_definitions = simulation_layer_definitions

        self._database = GDPScaledDatabase(database=self.model.database, base_year=self.configuration.projection_base_year)

        self._event_year = self.base_year

        self.__set_base_year_observed_values()

        self.__store_observed_x1_values()

        # Set up the exogenous variable projections
        self.__create_exogenous_variable_projections()

        # Adjust the exogenous projections and initial state vector for any relevant simulation layers
        self.__apply_simulation_layers()

        self.__store_observed_values_of_variables_adjusted_by_intertemporal_constants()
        self.__compute_base_year_ssf_deviations_from_observed_values()

        if not self.using_rolled_projections:
            self.__calculate_intertemporal_constants()

        # Generate the baseline projections
        self.__generate_projections()

        # Generate the database projections
        self.generate_database_projections()

        # Generate publishable version of the projections
        self.generate_publishable_projections()

        self.__validate()

        logging.info("The baseline projections have been generated.")

    def __validate(self):
        """
        TODO:  Validate the projections: 
        1. check that they are available for the expected projection years.
        2. Check that the base year projections are equal to the base year data values.
        """
        pass

    @property
    def stable_manifold(self) -> StableManifold:
        return self._stable_manifold

    @property
    def state_space_form(self) -> StateSpaceForm:
        return self.stable_manifold.ssf

    @property
    def model(self) -> Model:
        return self.state_space_form.model

    @property
    def sym_data(self) -> SymData:
        return self.model.sym_data

    @property
    def parameters(self) -> Parameters:
        return self.model.parameters

    @property
    def configuration(self) -> ModelConfiguration:
        return self.sym_data.configuration

    @property
    def database(self) -> GDPScaledDatabase:
        return self._database

    @property
    def base_year(self) -> int:
        return self.configuration.projection_base_year

    @property
    def simulation_layer_definitions(self) -> SimulationLayerDefinitions:
        return self._simulation_layer_definitions

    @property
    def has_simulation_layer_definitions(self) -> bool:
        return (self.simulation_layer_definitions is not None)

    @property
    def using_rolled_projections(self) -> bool:
        """
        Returns true if these projections are building on
        previous projections rather than just observed data.
        This affects how the baseline projections are set up in terms
        of the constants used 
        """
        return self.database.has_data_for_all_projection_years

    def __update_perturbed_variable(self, variable_details: pd.Series):
        """
        Change the perturbed variable, preparing for the next evaluation of the values needed to compute
        partial derivatives relevant to the determination of the intertemporal constants.
        """

        if hasattr(self, '_perturbed_variable_details'):
            sequence = self._perturbed_variable_details['sequence']
            match self._perturbed_variable_details['var_type']:
                case 'x1l':
                    self.x1r_difference_from_ssf[sequence] = self._original_value
                case 'j1l':
                    self.j1r_difference_from_ssf[sequence] = self._original_value
                case 'zel':
                    self.zer_difference_from_ssf[sequence] = self._original_value
                case 'z1l':
                    self.z1r_difference_from_ssf[sequence] = self._original_value
            delattr(self, '_original_value')

        if variable_details is None:
            delattr(self, '_perturbed_variable_details')
        else:
            sequence = variable_details['sequence']
            match variable_details['var_type']:
                case 'x1l':
                    self._original_value = float(self.x1r_difference_from_ssf[sequence])
                    self.x1r_difference_from_ssf[sequence] = self._original_value + __class__.PERTURBATION
                case 'j1l':
                    self._original_value = float(self.j1r_difference_from_ssf[sequence])
                    self.j1r_difference_from_ssf[sequence] = self._original_value + __class__.PERTURBATION
                case 'zel':
                    self._original_value = float(self.zer_difference_from_ssf[sequence])
                    self.zer_difference_from_ssf[sequence] = self._original_value + __class__.PERTURBATION
                case 'z1l':
                    self._original_value = float(self.z1r_difference_from_ssf[sequence])
                    self.z1r_difference_from_ssf[sequence] = self._original_value + __class__.PERTURBATION
            self._perturbed_variable_details = variable_details

    @property
    def perturbed_variable_details(self) -> pd.Series:
        """
        Returns the var_map details of the variable being perturbed to as part of computing
        derivatives needed to set intertemporal constants or none if just doing projections.
        """
        if hasattr(self, '_perturbed_variable_details'):
            return self._perturbed_variable_details
        return None

    @property
    def base_year_projections_of_variables_adjusted_by_intertemporal_constants(self) -> np.ndarray:
        """
        Extract the values of the variables that have been changed by the perturbation to 
        an intertemporal constant as part of computing partial derivatives for setting the
        intertemporal constants appropriately. These values are a column vector
        for the base project year only.
        """
        result = np.zeros(shape=(len(self.sym_data.variables_adjusted_by_intertemporal_constants), 1))
        i = 0
        for index, adjusted_variable_details in self.sym_data.variables_adjusted_by_intertemporal_constants.iterrows():
            sequence = adjusted_variable_details['sequence']
            match adjusted_variable_details['var_type']:
                case 'x1l':
                    result[i, 0] = self.yxr_base_year_projections[[sequence]]
                case 'j1l':
                    result[i, 0] = self.yjr_base_year_projections[[sequence]]
                case 'zel':
                    result[i, 0] = self.exz_base_year_projections[[sequence]]
                case 'z1l':
                    result[i, 0] = self.z1l_base_year_projections[[sequence]]
            i += 1
        return result

    def __set_base_year_observed_values(self):
        """
        Get the database values for the various vectors in the model in the projection base year.
        """
        # RHS (identical to LHS) vector values to be compared to SSF calculated values
        self._base_year_x1r: np.ndarray = self.database.rhs_vector_value(vector_name='x1r', year=self.base_year, use_neutral_real_interest_rate=True)  # t+1
        self._base_year_j1r: np.ndarray = self.database.rhs_vector_value(vector_name='j1r', year=self.base_year, use_neutral_real_interest_rate=True)  # t+1
        self._base_year_zer: np.ndarray = self.database.rhs_vector_value(vector_name='zer', year=self.base_year, use_neutral_real_interest_rate=True)  # t
        self._base_year_z1r: np.ndarray = self.database.rhs_vector_value(vector_name='z1r', year=self.base_year, use_neutral_real_interest_rate=True)  # t

        # SSF RHS vector values
        self._base_year_yxr: np.ndarray = self.database.rhs_vector_value(vector_name='yxr', year=self.base_year, use_neutral_real_interest_rate=True)  # t
        self._base_year_yjr: np.ndarray = self.database.rhs_vector_value(vector_name='yjr', year=self.base_year, use_neutral_real_interest_rate=True)  # t
        self._base_year_exz: np.ndarray = self.database.rhs_vector_value(vector_name='exz', year=self.base_year, use_neutral_real_interest_rate=True)  # t+1
        self._base_year_exo: np.ndarray = self.database.rhs_vector_value(vector_name='exo', year=self.base_year, use_neutral_real_interest_rate=True)  # t

    def __store_observed_x1_values(self):
        """
        Save the values of the state vector in the base projection year to use in
        initiating the projection process.
        """
        self._x1_observed_values_in_base_projection_year = self.base_year_yxr.copy()

    def __store_observed_values_of_variables_adjusted_by_intertemporal_constants(self):
        """
        Save the database values of the variables
        that are adjusted by intertemporal constants so that we can use
        those as the values we adjust the variables to using the intertemporal
        constants.
        """
        self._base_year_observed_values_of_variables_adjusted_by_intertemporal_constants: np.ndarray = \
            np.zeros(shape=(len(self.sym_data.variables_adjusted_by_intertemporal_constants), 1))
        i = 0
        for index, adjusted_variable_details in self.sym_data.variables_adjusted_by_intertemporal_constants.iterrows():
            sequence = adjusted_variable_details['sequence']
            match adjusted_variable_details['var_type']:
                case 'x1l':
                    self._base_year_observed_values_of_variables_adjusted_by_intertemporal_constants[i, 0] = self.base_year_yxr[[sequence]]  # t = base year
                case 'j1l':
                    self._base_year_observed_values_of_variables_adjusted_by_intertemporal_constants[i, 0] = self.base_year_yjr[[sequence]]  # t = base year
                case 'zel':
                    self._base_year_observed_values_of_variables_adjusted_by_intertemporal_constants[i, 0] = self.base_year_exz[[
                        sequence]]  # t+1 = year after base year
                case 'z1l':
                    self._base_year_observed_values_of_variables_adjusted_by_intertemporal_constants[i, 0] = self.base_year_z1r[[sequence]]  # t = base year
            i += 1

    def __compute_base_year_ssf_deviations_from_observed_values(self):
        """
        Compute the SSF values for the base projection year and calculate the differences from
        observed variable values for all system-determined variables (not the exogenous ones).
        See setconSYMBL.ox for details of the Ox implementation.

        Compute values for LHS variables based on RHS variable values in the projection base year 
        based on the SSF model. Then determine the difference between these LHS variables 
        (model predictions) and the actual values.

        Results are saved as data minus projections for all vectors.
        """

        # No constant adjustments for differences from SSF when doing rolling baseline projections
        if self.using_rolled_projections:
            self._x1r_difference_from_ssf = np.zeros((self.sym_data.vector_length(vector_name='x1r'), 1))
            self._j1r_difference_from_ssf = np.zeros((self.sym_data.vector_length(vector_name='j1r'), 1))
            self._zer_difference_from_ssf = np.zeros((self.sym_data.vector_length(vector_name='zer'), 1))
            self._z1r_difference_from_ssf = np.zeros((self.sym_data.vector_length(vector_name='z1r'), 1))
            return

        # We got here so we must be done the initial baseline projections that require a constant adjustment
        # for the SSF differences from observed data values in the base projection year.

        self.x1l_ssf_calculations_using_base_year_data = self.state_space_form.delta('x1l', 'yxr') @ self.base_year_yxr + \
            self.state_space_form.delta('x1l', 'yjr') @ self.base_year_yjr + \
            self.state_space_form.delta('x1l', 'exz') @ self.base_year_exz + \
            self.state_space_form.delta('x1l', 'exo') @ self.base_year_exo

        self.j1l_ssf_calculations_using_base_year_data = self.state_space_form.delta('j1l', 'yxr') @ self.base_year_yxr + \
            self.state_space_form.delta('j1l', 'yjr') @ self.base_year_yjr + \
            self.state_space_form.delta('j1l', 'exz') @ self.base_year_exz + \
            self.state_space_form.delta('j1l', 'exo') @ self.base_year_exo

        self.zel_ssf_calculations_using_base_year_data = self.state_space_form.delta('zel', 'yxr') @ self.base_year_yxr + \
            self.state_space_form.delta('zel', 'yjr') @ self.base_year_yjr + \
            self.state_space_form.delta('zel', 'exz') @ self.base_year_exz + \
            self.state_space_form.delta('zel', 'exo') @ self.base_year_exo

        self.z1l_ssf_calculations_using_base_year_data = self.state_space_form.delta('z1l', 'yxr') @ self.base_year_yxr + \
            self.state_space_form.delta('z1l', 'yjr') @ self.base_year_yjr + \
            self.state_space_form.delta('z1l', 'exz') @ self.base_year_exz + \
            self.state_space_form.delta('z1l', 'exo') @ self.base_year_exo

        self._x1r_difference_from_ssf = self.base_year_x1r - self.x1l_ssf_calculations_using_base_year_data  # t+1 = year after base year
        self._j1r_difference_from_ssf = self.base_year_j1r - self.j1l_ssf_calculations_using_base_year_data  # t+1 = year after base year
        self._zer_difference_from_ssf = self.base_year_zer - self.zel_ssf_calculations_using_base_year_data  # t = base year
        self._z1r_difference_from_ssf = self.base_year_z1r - self.z1l_ssf_calculations_using_base_year_data  # t = base year

    @property
    def base_year_x1r(self) -> np.ndarray:
        """
        If the base year = t:
        Returns the value of x1r from the database as the value of x1 in period t+1
        """
        return self._base_year_x1r

    @property
    def base_year_j1r(self) -> np.ndarray:
        """
        If the base year = t:
        Returns the value of j1r from the database as the value of j1 in period t+1
        """
        return self._base_year_j1r

    @property
    def base_year_zer(self) -> np.ndarray:
        """
        If the base year = t:
        Returns the value of zer from the database as the value of x1 in period t
        """
        return self._base_year_zer

    @property
    def base_year_z1r(self) -> np.ndarray:
        """
        If the base year = t:
        Returns the value of z1r from the database as the value of z1 in period t
        """
        return self._base_year_z1r

    @property
    def base_year_yxr(self) -> np.ndarray:
        """
        If the base year = t:
        Returns the value of yxr from the database as the value of x1 in period t
        """
        return self._base_year_yxr

    @property
    def base_year_yjr(self) -> np.ndarray:
        """
        If the base year = t:
        Returns the value of yjr from the database as the value of j1 in period t
        """
        return self._base_year_yjr

    @property
    def base_year_exz(self) -> np.ndarray:
        """
        If the base year = t:
        Returns the value of exz from the database as the value of ze in period t+1
        """
        return self._base_year_exz

    @property
    def base_year_exo(self) -> np.ndarray:
        """
        If the base year = t:
        Returns the value of exo from the database as the value of exogenous variables (exo)
        in period t
        """
        return self._base_year_exo

    @property
    def x1r_difference_from_ssf(self):
        """
        In Ox: decl cz2 = x1r - x1l
        """
        return self._x1r_difference_from_ssf

    @property
    def j1r_difference_from_ssf(self):
        """
        In Ox: decl cz4 = j1r - j1l
        """
        return self._j1r_difference_from_ssf

    @property
    def zer_difference_from_ssf(self):
        """
        In Ox: decl cz5 = zer - zel
        """
        return self._zer_difference_from_ssf

    @property
    def z1r_difference_from_ssf(self):
        """
        In Ox: decl cz6 = z1r - z1l
        """
        return self._z1r_difference_from_ssf

    @property
    def x1_observed_values_in_base_projection_year(self) -> np.ndarray:
        """
        Returns the observed values of the state variables in the base projection year.
        """
        return self._x1_observed_values_in_base_projection_year

    def compute_functions_of_future_exogenous_variables(self):
        """
        The rules governing the dynamic behaviour of variables depend on functions of the current and future exogenous variables.
        These functions are evaluated and the results are stored in numpy matrices that match the number of rows
        for the related vector of variables and that have a column for each year from the base projection year to the
        last year in the projections.
        """

        # Set up the arrays that will be populated and initialise them to zeros.

        # // setup for baseline with optimization
        # decl id=invert(unit(nez)-c4n);
        # c4t=id*cz5;

        # decl mu2t=id*c6n;

        # id=invert(unit(njm)-ff-we*mu2t);
        # c6t=id*(cz4+we*c4t);

        # c4t=c4t+mu2t*c6t;
        # c4t=ones(rows(c4t),nobs).*c4t;
        # c6t=ones(rows(c6t),nobs).*c6t;
        # c2t=h2t*exog+c6t+bt2t*gam3t;

        # This is equivalent to h3t in the newsetsymbl.ox script (j by 1 dimensions)
        h3t: np.ndarray = np.zeros(shape=(self.sym_data.vector_length(vector_name='j1l'), self.projection_years_count))

        # Populate for period T.

    	# c4t=invert(unit(nez)-zel_exz_ssf)*cz5   (r by 1 dimensions)
        interim_calculation = self.stable_manifold.Gamma_rT @ self.ze_constants

        # c6t = invert(unit(j)-j1l_yjr_ssf-j1l_exz_ssf*mu2t) * (cz4+j1l_exz_ssf*c4t)
        #     = Gamma_jT (cz4+j1l_exz_ssf*interim_calculation)
        c6T_column = self.stable_manifold.Gamma_jT @ (self.j1_constants + self.state_space_form.delta('j1l', 'exz') @ interim_calculation)

    	# c4t = c4t + mu2t * c6t (r by 1 dimensions)
        c4T_column = interim_calculation + self.stable_manifold.psi_rj @ c6T_column

        # c4t=ones(rows(c4t),nobs).*c4t (r by T dimensions)
        c4t: np.ndarray = np.tile(c4T_column, (1, self.projection_years_count))

        # c6t=ones(rows(c6t),nobs).*c6t (j by T dimensions)
        c6t: np.ndarray = np.tile(c6T_column, (1, self.projection_years_count))

        # c2t=h2t*exog+c6t    (j by T dimensions)
        c2t: np.ndarray = self.stable_manifold.H2 @ self.exo_projections + c6t

        # (s by T dimensions)
        c5t: np.ndarray = np.zeros(shape=(self.sym_data.vector_length(vector_name='x1l'), self.projection_years_count))

        # (j by T dimensions)
        c2t_lead: np.ndarray = c2t.copy()
        c4t_lead: np.ndarray = c4t.copy()

        # Populate for earlier periods.
        j = self.projection_years_count-1
        for k in range(self.projection_years_count-1, -1, -1):

            # c5t[][k] = wvi*(x1l_exz_ssf*c4tl[][j] + cz2)          (s by 1 : note no need for T columns)
            c5t: np.ndarray = self.stable_manifold.Gamma_st @ (self.state_space_form.delta('x1l', 'exz') @ c4t_lead[:, [j]] + self.x1_constants)

            # c6t[][k] = fdeltinv*(th6t*c5t[][k] - j1l_exz_ssf*c4tl[][j] + c2tl[][j] - cz4)         (j rows)
            c6t[:, [k]] = self.stable_manifold.Gamma_jt @ (self.stable_manifold.common_factor @ c5t - self.state_space_form.delta(
                'j1l', 'exz') @ c4t_lead[:, [j]] + c2t_lead[:, [j]] - self.j1_constants)

            # c5t[][k] = c5t[][k] + th2t*c6t[][k]
            c5t = c5t + self.stable_manifold.tau_sjt @ c6t[:, [k]]

            # c4t[][k] = mu1tl*c5t[][k] + c4tl[][j]
            c4t[:, [k]] = self.stable_manifold.M1_lead @ c5t + c4t_lead[:, [j]]

            # h3t[][k] = c6t[][k]
            h3t[:, [k]] = c6t[:, [k]].copy()

            # c2t[][k] = h2t*exog[][k] + h3t[][k]
            c2t[:, [k]] = self.stable_manifold.H2 @ self.exo_projections[:, [k]] + h3t[:, [k]]

            # c4tl[][k] = nmu4t*exog[][k] + zel_yjr_ssf*h3t[][k] + zel_exz_ssf*c4t[][k] + cz5
            c4t_lead[:, [k]] = self.stable_manifold.M2 @ self.exo_projections[:, [k]] + \
                self.state_space_form.delta('zel', 'yjr') @ h3t[:, [k]] + \
                self.state_space_form.delta('zel', 'exz') @ c4t[:, [k]] + \
                self.ze_constants

            c2t_lead = c2t.copy()

            j = k

        # Store the functions of future exogenous variables to access when doing projections.
        self._h3t = h3t.copy()
        self._c4t = c4t.copy()

    @property
    def h3t(self) -> np.ndarray:
        """
        Equivalent to h3t in the Ox implementation
        
        Returns constants and the functions of current and future exogenous variables affecting J1.
        """
        return self._h3t

    @property
    def c4t(self) -> np.ndarray:
        """
        Equivalent to c4t in the Ox implementation
        
        Returns constants and the functions of current and future exogenous variables affecting ZE.
        """
        return self._c4t

    @property
    def reference_h3t_used_to_compute_intertemporal_constants(self) -> np.ndarray:
        """
        Equivalent to h3t in the Ox implementation
        Functions of current and future exogenous variables affecting J1.
        This is the reference version of h3t, computed to calculation the projections
        for the base year that will be used as a reference projection when determining 
        the numeric derivatives for calculation of the intertemporal constants.

        Its only role is to preserve the appropriate information for benchmarking against Ox.
        """
        return self._reference_h3t_used_to_compute_intertemporal_constants

    @property
    def reference_c4t_used_to_compute_intertemporal_constants(self) -> np.ndarray:
        """
        Equivalent to c4t in the Ox implementation
        Functions of current and future exogenous variables affecting ZE.
        This is the reference version of h3t, computed to calculation the projections
        for the base year that will be used as a reference projection when determining 
        the numeric derivatives for calculation of the intertemporal constants.

        Its only role is to preserve the appropriate information for benchmarking against Ox.
        """
        return self._reference_c4t_used_to_compute_intertemporal_constants

    @property
    def x1_constants(self) -> np.ndarray:
        """
        The constant adjustments to X1 to ensure projections equal observed values.
        Add any intertemporal constant values to the X1R difference to SSF equation 
        results with zero constants to get the combined set of constants.
        """

        if hasattr(self, "_x1_constants"):
            return self._x1_constants

        result: np.ndarray = self.x1r_difference_from_ssf.copy()
        if not hasattr(self, "intertemporal_constants"):
            return result

        i = 0
        for index, variable_details in self.sym_data.intertemporal_constant_variables.iterrows():
            if variable_details['var_type'] == 'x1l':
                result[variable_details['sequence'], 0] += self.intertemporal_constants.loc[variable_details['name'], 'constant_value']
            i = i + 1

        self._x1_constants: np.ndarray = result
        return self._x1_constants

    @property
    def j1_constants(self) -> np.ndarray:
        """
        The constant adjustments to J1 to ensure projections equal observed values.
        Add any intertemporal constant values to the X1R difference to SSF equation results with zero constants
        to get the combined set of constants.
        """

        if hasattr(self, "_j1_constants"):
            return self._j1_constants

        result: np.ndarray = self.j1r_difference_from_ssf.copy()
        if not hasattr(self, "intertemporal_constants"):
            return result
        i = 0
        for index, variable_details in self.sym_data.intertemporal_constant_variables.iterrows():
            if variable_details['var_type'] == 'j1l':
                result[variable_details['sequence'], 0] += self.intertemporal_constants.loc[variable_details['name'], 'constant_value']
            i = i + 1

        self._j1_constants: np.ndarray = result
        return self._j1_constants

    @property
    def ze_constants(self) -> np.ndarray:
        """
        The constant adjustments to ZE to ensure projections equal observed values.
        Add any intertemporal constant values to the X1R difference to SSF equation results with zero constants
        to get the combined set of constants.
        """

        if hasattr(self, "_ze_constants"):
            return self._ze_constants

        result: np.ndarray = self.zer_difference_from_ssf.copy()
        if not hasattr(self, "intertemporal_constants"):
            return result

        i = 0
        for index, variable_details in self.sym_data.intertemporal_constant_variables.iterrows():
            if variable_details['var_type'] == 'zel':
                logging.debug(
                    f"At index {i} intertemporal constant is {self.intertemporal_constants.loc[variable_details['name'],'constant_value']} : shape is {self.intertemporal_constants.shape}")
                result[variable_details['sequence'], 0] += self.intertemporal_constants.loc[variable_details['name'], 'constant_value']
            i = i + 1

        self._ze_constants: np.ndarray = result
        return self._ze_constants

    @property
    def z1_constants(self) -> np.ndarray:
        """
        The constant adjustments to Z1 to ensure projections equal observed values.
        Add any intertemporal constant values to the X1R difference to SSF equation results with zero constants
        to get the combined set of constants.
        """

        if hasattr(self, "_z1_constants"):
            return self._z1_constants

        result: np.ndarray = self.z1r_difference_from_ssf.copy()
        if not hasattr(self, "intertemporal_constants"):
            return result
        i = 0
        for index, variable_details in self.sym_data.intertemporal_constant_variables.iterrows():
            if variable_details['var_type'] == 'z1l':
                result[variable_details['sequence'], 0] += self.intertemporal_constants.loc[variable_details['name'], 'constant_value']
            i = i + 1

        self._z1_constants: np.ndarray = result
        return self._z1_constants

    def __create_exogenous_variable_projections(self):
        """
        Populates the exogenous variable values through the projection years. 
        These values are determined outside the system.

        The rolling baseline projections just copy the exogenous values from the previous projections
        and use those as the starting point for the next round of projection generation.

        Otherwise, when initially setting up baseline projections, incorporate values from:
        - the database in the base projection year
        - effective labour productivity projections
        - energy efficiency improvement projections
        """

        # If we are doing the baseline projections after rolling forward to a new base projection year,
        # just copy the database values for the exogenous variables over the projection years
        # and then we are done.
        if self.using_rolled_projections:
            matching_indices: pd.Index = self.sym_data.combined_variable_summary.loc[self.sym_data.combined_variable_summary.vector == 'exo', :].index
            self._exo_projections: pd.DataFrame = self.database.data.loc[matching_indices, self.configuration.base_and_projection_years_column_labels]
            return

        # We got here so we must be setting up the exogenous variable projections for the first time ...

        # Replicate projection base year values across all projection periods for all exogenous variables.
        base_year_values: np.ndarray = self.base_year_exo
        projections: pd.DataFrame = pd.DataFrame(np.tile(base_year_values, (1, self.configuration.base_and_projection_year_count)))
        projections.columns = self.configuration.base_and_projection_years_column_labels
        projections.reset_index()

        # Add effective labour productivity and energy usage efficiency.
        effective_labour_productivity: EffectiveLabourProductivity = self.model.effective_labour_productivity
        rogy: pd.DataFrame = effective_labour_productivity.rogy
        energy_usage_efficiency: EnergyUsageEfficiency = self.model.energy_usage_efficiency
        for region in self.sym_data.regions_members:

            regional_effective_labour_productivity: pd.DataFrame = effective_labour_productivity.effective_productivity_deviations(region=region)
            regional_energy_usage_efficiency: pd.DataFrame = energy_usage_efficiency.sector_cumulative_energy_usage_efficiency_gains(region=region)
            consumption_energy_usage_efficiency: pd.DataFrame = energy_usage_efficiency.consumption_cumulative_energy_usage_efficiency_gains

            variable_prefix_ROGY: str = f"ROGY"
            rogy_name: str = f"{variable_prefix_ROGY}({region})"
            if self.sym_data.has_variables(variable_name_prefix=rogy_name):
                rogy_index: int = self.sym_data.variable_index(vector_name='exo', variable_name=rogy_name)
                rogy_units = self.sym_data.variable_units(vector_name='exo', variable_name_prefix=variable_prefix_ROGY)
                rogy_data: pd.DataFrame = rogy.loc[[region], self.configuration.base_and_projection_years_column_labels]
                if 'gdp' in rogy_units:
                    raise Exception(f"{rogy_name} has gdp units so shocks to that variable are not supported.")

                projections.loc[[rogy_index], :] = projections.loc[[rogy_index], :] + (rogy_data.to_numpy().flatten() / 100)
            # else:
            #     logging.warning(f"{rogy_name} is not in the SYM model.")

            shefc_name_prefix: str = f"SHEFC"
            shefc_name: str = f"{shefc_name_prefix}({region})"
            if self.sym_data.has_variables(variable_name_prefix=shefc_name_prefix):
                shefc_index: int = self.sym_data.variable_index(vector_name='exo', variable_name=shefc_name)
                shefc_units = self.sym_data.variable_units(vector_name='exo', variable_name_prefix=shefc_name_prefix)
                shefc_data: pd.DataFrame = consumption_energy_usage_efficiency.loc[[region], self.configuration.base_and_projection_years_column_labels]
                if 'gdp' in shefc_units:
                    raise Exception(f"{shefc_name} has gdp units so shocks to that variable are not supported.")
                projections.loc[[shefc_index], :] = projections.loc[[shefc_index], :] + (shefc_data.to_numpy().flatten() / 100)
            # else:
            #     logging.warning(f"{shefc_name} is not in the SYM model.")

            variable_prefix_SHL: str = 'SHL'
            variable_prefix_SHEF: str = 'SHEF'
            for sector in self.sym_data.sectors_members:

                shl_name: str = f"{variable_prefix_SHL}({region},{sector})"
                if self.sym_data.has_variables(variable_name_prefix=shl_name):
                    shl_index: int = self.sym_data.variable_index(vector_name='exo', variable_name=shl_name)
                    shl_units = self.sym_data.variable_units(vector_name='exo', variable_name_prefix=variable_prefix_SHL)
                    shl_data: pd.DataFrame = regional_effective_labour_productivity.loc[[sector], self.configuration.base_and_projection_years_column_labels]
                    if 'gdp' in shl_units:
                        raise Exception(f"{shl_name} has gdp units so shocks to that variable are not supported.")
                    projections.loc[[shl_index], :] = projections.loc[[
                        shl_index], :] + (shl_data.to_numpy().flatten() / 100)
                # else:
                #     logging.warning(f"{shl_name} is not in the SYM model.")

                shef_name: str = f"{variable_prefix_SHEF}({sector},{region})"
                if self.sym_data.has_variables(variable_name_prefix=shef_name):
                    shef_index: int = self.sym_data.variable_index(vector_name='exo', variable_name=shef_name)
                    shef_units = self.sym_data.variable_units(vector_name='exo', variable_name_prefix=variable_prefix_SHEF)
                    shef_data: pd.DataFrame = regional_energy_usage_efficiency.loc[[sector], self.configuration.base_and_projection_years_column_labels]
                    if 'gdp' in shef_units:
                        raise Exception(f"{shef_name} has gdp units so shocks to that variable are not supported.")
                    projections.loc[[shef_index], :] = projections.loc[[shef_index], :] + (shef_data.to_numpy().flatten() / 100)
                # else:
                #     logging.warning(f"{shef_shock_name} is not in the SYM model.")

            # THIS IS OBSOLETE.
            # See https://bitbucket.org/msgpl/gcubedcode/issues/140/prodmat-file-for-20r-is-missing-some
            # for sector in self.sym_data.capital_sectors_members:
            #     variable_prefix_SHL_capital = f"SHL{sector}"
            #     shl_name: str = f"{variable_prefix_SHL_capital}({region})"
            #     if self.sym_data.has_variables(variable_name_prefix=variable_prefix_SHL_capital):
            #         shl_index: int = self.sym_data.variable_index(vector_name='exo', variable_name=shl_name)
            #         shl_units = self.sym_data.variable_units(vector_name='exo', variable_name_prefix=variable_prefix_SHL_capital)
            #         shl_data: pd.DataFrame = regional_effective_labour_productivity.loc[[sector], self.configuration.base_and_projection_years_column_labels]
            #         if 'gdp' in shl_units:
            #             raise Exception(f"{shl_name} has gdp units so shocks to that variable are not supported.")
            #         projections.loc[[shl_index], :] = projections.loc[[shl_index], :] + (shl_data.to_numpy().flatten() / 100)
            #     # else:
            #     #     logging.warning(f"{shl_name} is not in the SYM model.")

        # Index with variable names.
        projections.index = self.sym_data.vector_variable_names(vector_name='exo')

        # Store the exogenous projections that will be augmented for other projections.
        self._exo_projections: pd.DataFrame = projections

    def __apply_simulation_layers(self):
        """
        Apply adjustments to exogenous variables and any state variables for any simulation layers
        that have their event year matching the base year of these baseline projections.
        """

        if not self.has_simulation_layer_definitions:
            return
        for simulation_layer_definition in self.simulation_layer_definitions:
            self.__apply_simulation_layer(simulation_layer_definition=simulation_layer_definition)

    def __apply_simulation_layer(self, simulation_layer_definition: SimulationLayerDefinition):
        """
        Apply adjustments to exogenous variables and any state variables for the given simulation layer
        """
        if simulation_layer_definition.event_year != self.base_year:
            return

        filename: str = simulation_layer_definition.data_filename
        assert os.path.isfile(filename)
        (self._simulation_variables, self._simulation_data) = self.load_data(filename)
        self._simulation_variables.columns = ['name']
        self._simulation_variables.index = self._simulation_variables.name
        self._simulation_data = self._simulation_data.astype(float)
        self._simulation_data.index = self._simulation_variables.name
        try:
            self._simulation_data = self._simulation_data.loc[:, self.configuration.base_and_projection_years_column_labels]
        except:
            raise Exception(f"The simulation data in {self.simulation_file} should have data from {self.event_year} to {self.end_year}")
        yratr: pd.DataFrame = self.database.get_data(name_regular_expression=f"^{CONSTANTS.US_REAL_GDP_RATIO_PREFIX}\(", years=[self.base_year])
        yratr.index = self.sym_data.regions_members

        for variable_name in self._simulation_variables.index:
            variable_region: str = str(self.database.variables.loc[variable_name, 'region'])
            variable_units: str = str(self.sym_data.combined_variable_summary.loc[variable_name, 'units'])
            data: pd.DataFrame = self._simulation_data.loc[[variable_name], :] / 100
            vector_name = self.sym_data.projection_vector_for_variable(variable_name=variable_name)
            yratr_for_region: float = float(yratr.loc[variable_region, :])
            match variable_units:
                case 'gdp':
                    data = data * yratr_for_region
                case 'mmgdp':
                    data = data * yratr_for_region
                case 'btugdp':
                    data = data * yratr_for_region
                case 'gwhgdp':
                    data = data * yratr_for_region
                case _:
                    pass

            match vector_name:
                case 'exo':
                    self.exo_projections_as_dataframe.loc[[variable_name], self.configuration.base_and_projection_years_column_labels] += data
                    pass

                case 'x1l':
                    self.x1_observed_values_in_base_projection_year.loc[[variable_name], [str(self.base_year)]] += float(data[0])
                    pass

    def __evaluate_base_year_vector_projections(self):
        """
        Computes the values of the model equation vectors in the first period of the projection, 
        using the functions of future exogenous variables, the stable manifold, and ...
        """

        self._exo_base_year_projections = self.exo_projections[:, [0]]

        self._yxr_base_year_projections = self.x1_observed_values_in_base_projection_year.copy()

        # er = h1t*x[][1] + h2t*exog[][1] + h3t[][1];
        self._yjr_base_year_projections = \
            self.stable_manifold.H1 @ self.yxr_base_year_projections + \
            self.stable_manifold.H2 @ self.exo_base_year_projections + \
            self._h3t[:, [0]]

        # tzl = mu1t*x[][1] + mu4t*exog[][1] + c4t[][1];
        self._exz_base_year_projections = \
            self.stable_manifold.mu1 @ self.yxr_base_year_projections + \
            self.stable_manifold.mu2 @ self.exo_base_year_projections + \
            self._c4t[:, [0]]

        # z1l projections = d5n*x[][1]+d7n*exog[][1]+d6n*er+d4n*tzl+cz6[][1]
        self._z1l_base_year_projections = \
            self.state_space_form.delta('z1l', 'yxr') @ self.yxr_base_year_projections + \
            self.state_space_form.delta('z1l', 'exo') @ self.exo_base_year_projections + \
            self.state_space_form.delta('z1l', 'yjr') @ self.yjr_base_year_projections + \
            self.state_space_form.delta('z1l', 'exz') @ self.exz_base_year_projections + \
            self.z1r_difference_from_ssf

    @property
    def yxr_base_year_projections(self):
        """
        Projections of X1_t (yxr) in the base year
        """
        return self._yxr_base_year_projections

    @property
    def yjr_base_year_projections(self):
        """
        Projections of J1_t (yjr) in the base year
        """
        return self._yjr_base_year_projections

    @property
    def exz_base_year_projections(self):
        """
        Projections of ZE_t (exz) in the base year
        """
        return self._exz_base_year_projections

    @property
    def z1l_base_year_projections(self):
        """
        Projections of Z1_t (z1l=z1r) in the base year
        """
        return self._z1l_base_year_projections

    @property
    def exo_base_year_projections(self):
        """
        Projections of EXO_t in the base year
        """
        return self._exo_base_year_projections

    @property
    def base_year_original_projections_of_variables_adjusted_by_intertemporal_constants(self) -> np.ndarray:
        """
        The base year projected values for the variables that are being
        adjusted by the intertemporal constants.

        The values are those for the projection that is not adjusted by intertemporal constants.
        """
        return self._base_year_original_projections_of_variables_adjusted_by_intertemporal_constants

    @property
    def base_year_original_projections_of_yxr(self) -> np.ndarray:
        """
        The base year projected values for the state variables.
        Required for benchmarking against Ox.
        """
        return self._base_year_original_projections_of_yxr

    @property
    def base_year_original_projections_of_yjr(self) -> np.ndarray:
        """
        The base year projected values for the costate variables.
        Required for benchmarking against Ox.
        """
        return self._base_year_original_projections_of_yjr

    @property
    def base_year_original_projections_of_exz(self) -> np.ndarray:
        """
        The base year projected values for the expected endogenous variables exz.
        Required for benchmarking against Ox.
        """
        return self._base_year_original_projections_of_exz

    @property
    def base_year_original_projections_of_z1l(self) -> np.ndarray:
        """
        The base year projected values for the endogenous variables.
        Required for benchmarking against Ox.
        """
        return self._base_year_original_projections_of_z1l

    @property
    def base_year_observed_values_of_variables_adjusted_by_intertemporal_constants(self) -> np.ndarray:
        """
        Returns the observed values in the base projection year of the 
        variables that are adjusted by intertemporal constants.
        """
        return self._base_year_observed_values_of_variables_adjusted_by_intertemporal_constants

    @property
    def base_year_lhs_values(self) -> np.ndarray:
        """
        Values selected from base year SSF-generated LHS vectors using RHS vector values as inputs.
        """
        return self._base_year_lhs_values

    @property
    def intertemporal_constants(self) -> pd.DataFrame:
        return self._intertemporal_constants

    @property
    def partial_derivatives_wrt_intertemporal_constants(self) -> np.ndarray:
        return self._partial_derivatives

    def __calculate_intertemporal_constants(self):
        """
        Computes the intertemporal constant adjustments to jump and other variables to align starting data
        values with model projections in the first year.

        Step 1.
        Compute functions of future exogenous variables through all years of the projection.

        Step 2.
        For the variables that are to be adjusted by the intertemporal
        constants, compute their projected values in the base projection year
        and store these values for comparison to perturbed base year projections so we can calculate
        the derivatives matrix needed to set the intertemporal constants.
        Also store the values of each of the 4 vectors in the model in the base year for benchmarking.

        Step 3.
        Initialise the partial derivatives matrix. This is the matrix of derivatives of each of the
        variables that is adjusted by intertemporal constants, with respect to each of the intertemporal
        constants.
        Iterate over the intertemporal constants, perturbing each and recalculating the base year projections
        of the variables that are adjusted by intertemporal constants so that we can 
        estimate the relevant numeric derivatives.
        """

        # Step 1.
        self.compute_functions_of_future_exogenous_variables()
        self._reference_c4t_used_to_compute_intertemporal_constants = self.c4t.copy()
        self._reference_h3t_used_to_compute_intertemporal_constants = self.h3t.copy()

        # Step 2.
        self.__evaluate_base_year_vector_projections()
        self._base_year_original_projections_of_yxr = self.yxr_base_year_projections.copy()
        self._base_year_original_projections_of_yjr = self.yjr_base_year_projections.copy()
        self._base_year_original_projections_of_exz = self.exz_base_year_projections.copy()
        self._base_year_original_projections_of_z1l = self.z1l_base_year_projections.copy()
        self._base_year_original_projections_of_variables_adjusted_by_intertemporal_constants = \
            self.base_year_projections_of_variables_adjusted_by_intertemporal_constants.copy()

        # Step 3.
        self._partial_derivatives = np.zeros(shape=(len(self.sym_data.intertemporal_constant_variables), len(
            self.sym_data.variables_adjusted_by_intertemporal_constants)))
        i = 0
        for index, variable_details in self.sym_data.intertemporal_constant_variables.iterrows():
            self.__update_perturbed_variable(variable_details=variable_details)
            self.compute_functions_of_future_exogenous_variables()
            self.__evaluate_base_year_vector_projections()
            self._partial_derivatives[:, [i]] = (
                self.base_year_projections_of_variables_adjusted_by_intertemporal_constants -
                self._base_year_original_projections_of_variables_adjusted_by_intertemporal_constants) \
                / __class__.PERTURBATION
            i += 1

        # Get the unperturbed values of the start year variables

        # Generate the baseline projection to use in computing partial derivatives
        # and to generate matrix values that are used later in projection processes.
        self.__update_perturbed_variable(variable_details=None)

        # Use newtons method adjustment to compute intertemporal constant values
        self._intertemporal_constants = self.sym_data.intertemporal_constant_variables
        values: np.ndarray = np.linalg.inv(self._partial_derivatives) @ \
            (self.base_year_observed_values_of_variables_adjusted_by_intertemporal_constants -
             self.base_year_original_projections_of_variables_adjusted_by_intertemporal_constants)
        values = values.reshape((len(self.intertemporal_constants.index), 1))
        self._intertemporal_constants['constant_value'] = values
        logging.info("The intertemporal constants have been calibrated.")

    def __generate_projections(self):
        """
        Implements the projection logic in msgsimBL.ox. This runs the various equations
        to project variables based on the starting state vector and the values of
        exogenous variables in all years. The steps are as follows:

        Step 1.
        Recalculate the functions of future exogenous variables, incorporating 
        the updated exogenous variable projections and all constant adjustments: 
        the intertemporal constants and the other constants  capturing the difference 
        between the SSF equation results in the base year and the observed 
        values in the base year.
        
        Step 2.
        Project the state vector. (x_t+1 as a function of x_t and exogenous variables and constant adjustments)
        This uses the Anew and Znew matrices computed as part of getting the stable manifold.

        Step 3. 
        Combine all variable projections into a single data frame.

        Step 4.
        Sort the variables in the projection dataframe into the same order as the original database.
        """

        # Step 1.
        self.compute_functions_of_future_exogenous_variables()

        # Step 2.
        constantBL: pd.DataFrame = pd.DataFrame(
            self.stable_manifold.Znew @ self.exo_projections +
            self.state_space_form.delta('x1l', 'yjr') @ self.h3t +
            self.state_space_form.delta('x1l', 'exz') @ self.c4t +
            self.x1_constants)
        constantBL.columns = self.configuration.base_and_projection_years_column_labels
        constantBL.index = self.sym_data.vector_variable_names(vector_name='x1l')
        yxr: pd.DataFrame = pd.DataFrame(index=self.sym_data.vector_variable_names(vector_name='x1l'),
                                         columns=self.configuration.base_and_projection_years_column_labels)
        yxr.loc[:, [str(self.configuration.projection_base_year)]] = self.x1_observed_values_in_base_projection_year
        previous_year_label = str(self.configuration.projection_base_year)
        for year in self.configuration.projection_years_column_labels:
            yxr.loc[:, [year]] = self.stable_manifold.Anew @ yxr.loc[:, [previous_year_label]].to_numpy() + constantBL.loc[:, [previous_year_label]].to_numpy()
            previous_year_label = year
        self._yxr_projections = yxr

        # Project J1
        # er = h1t*x + h2t*exog[][1:nobs] + h3t
        # yjr: pd.DataFrame = pd.DataFrame(self.stable_manifold.H1 @ (yxr.to_numpy()))
        yjr: pd.DataFrame = pd.DataFrame(self.stable_manifold.H1 @ (yxr.to_numpy()) + self.stable_manifold.H2 @ self.exo_projections + self._h3t)
        yjr.columns = self.configuration.base_and_projection_years_column_labels
        yjr.index = self.sym_data.vector_variable_names(vector_name='j1l')
        self._yjr_projections = yjr

        # Project time t expected value of ZE in period t+1 (EXZ)
        # Project time t expected value of ZE in period t+1 (EXZ)
        # tzl = mu1t*x + mu4t*exog[][1:nobs] + c4t
        exz: pd.DataFrame = pd.DataFrame(
            self.stable_manifold.mu1 @ yxr.to_numpy() +
            self.stable_manifold.mu2 @ self.exo_projections +
            self._c4t
        )
        exz.columns = self.configuration.base_and_projection_years_column_labels
        exz.index = self.sym_data.vector_variable_names(vector_name='zer')
        self._exz_projections = exz

        # Project time t values of ZE using the SSF equation (this should be done with M1 and M2?)
        # What about the functions of future exogenous variables and the constant adjustments
        zel: pd.DataFrame = pd.DataFrame(
            self.state_space_form.delta('zel', 'yxr') @ self.yxr_projections +
            self.state_space_form.delta('zel', 'exz') @ self.exz_projections +
            self.state_space_form.delta('zel', 'yjr') @ self.yjr_projections +
            self.state_space_form.delta('zel', 'exo') @ self.exo_projections)
        zel.columns = self.configuration.base_and_projection_years_column_labels
        zel.index = self.sym_data.vector_variable_names(vector_name='zel')
        self._zel_projections = zel + self.ze_constants

        # Project Z1 using the SSF equation
        z1l: pd.DataFrame = pd.DataFrame(
            self.state_space_form.delta('z1l', 'yxr') @ self.yxr_projections +
            self.state_space_form.delta('z1l', 'exz') @ self.exz_projections +
            self.state_space_form.delta('z1l', 'yjr') @ self.yjr_projections +
            self.state_space_form.delta('z1l', 'exo') @ self.exo_projections)
        z1l.columns = self.configuration.base_and_projection_years_column_labels
        z1l.index = self.sym_data.vector_variable_names(vector_name='z1l')
        self._z1l_projections = z1l + self.z1_constants

        # Combine the projections into a single dataframe in the same order as the database
        self._projections = pd.concat([
            self.yxr_projections_as_dataframe,
            self.z1l_projections_as_dataframe,
            self.zel_projections_as_dataframe,
            self.yjr_projections_as_dataframe,
            self.exo_projections_as_dataframe])
        database_ordered_variable_list: pd.DataFrame = self.database.variables.name
        self._projections = pd.concat([database_ordered_variable_list, self._projections], axis=1)
        self._projections.drop('name', inplace=True, axis=1)

        # timeshift forward the special state variables by 1 period.
        for variable_name_prefix in CONSTANTS.STATE_LEAD_VARIABLES:
            matching_variables = self._projections.index.str.startswith(variable_name_prefix)
            self._projections.iloc[matching_variables, 0:-2] = self._projections.iloc[matching_variables, 1:-1]
            self._projections.iloc[matching_variables, -1] = 0  # TODO: Once we are past benchmarking against Ox, set this equal to NaN.

        self._projections = self._projections.astype(float)

    @property
    def publishable_data(self) -> pd.DataFrame:
        """
        Transforms the data so that it can be compared with publishable projections.

        Step 1.
        Get a copy of the raw data.

        Step 2.
        Divide the projections by YRATR/100 in the projection base year for every variable that has units of:
            gdp
            mmtgdp
            btugdp
            gwhgdp

        Step 3.
        Multiply values by 100

        Step 4.
        Get LGDPR data in the projection base year for each region and apply labgrow growth rates to translate
        across database years.

        Step 5.
        For all projections with units equal to usgdp, multiply the projection by the US LGDPR projection computed in step 4.

        Step 6.
        For all projections with units equal to 'gdp', multiply the projection by the associated
        region's LGDPR projection computed in step 4.

        These publishable projections should then be associated with the publication_units of measurement
        available from the sym_data variable summary.
        The units changes are as follows:
            del -> pct
            pct -> Index
            mmtgdp -> mmt
            btugdp -> btu
            gwhgdp -> gwh
            mmtusgdp -> mmt
            btuusgdp -> btu
            usgdp -> $US Bil
            gdp -> $US Bil

        Saves the result in the _publishable_data property.

        """

        # Step 1.
        publication_data: pd.DataFrame = self.database.data.copy()

        # Step 2.
        yratr_data: pd.DataFrame = self.database.data.loc[self.database.variables.name.str.startswith("YRATR("), str(self.configuration.base_year)].copy()
        yratr_data.index = self.sym_data.regions_members
        for variable_name in publication_data.index:
            units: str = str(self.database.variables.loc[variable_name, 'units'])
            match units:
                case 'gdp' | 'btugdp' | 'mmtgdp' | 'gwhgdp':
                    variable_region: str = str(self.database.variables.loc[variable_name, 'region'])
                    factor: float = yratr_data.loc[variable_region]
                    publication_data.loc[[variable_name], :] /= factor

        # Step 3.
        publication_data *= 100.0

        # Step 4.
        # TODO: refactor out this calculation so it is not being done each time we convert to publishable projections
        lgdpr_in_base_year: pd.DataFrame = self.database.data.loc[self.database.variables.name.str.startswith("LGDPR("), [str(self.base_year)]].copy() / 100
        us_long_run_growth_rate: float = float(self.parameters.parameter(parameter_name="labgrow").loc[:, self.sym_data.us_region].values[0])
        scale_factor = pd.DataFrame(index=['values'], columns=self.database.data.columns)
        scale_factor.loc['values', str(self.configuration.projection_base_year)] = 1
        for year in range(self.configuration.projection_base_year+1, int(self.database.data.columns[-1]) + 1):
            scale_factor.loc['values', str(year)] = scale_factor.loc['values', str(year-1)] * (1+us_long_run_growth_rate)
        for year in range(self.configuration.projection_base_year-1, int(self.database.data.columns[0]) - 1, -1):
            scale_factor.loc['values', str(year)] = scale_factor.loc['values', str(year+1)] / (1+us_long_run_growth_rate)
        lgdpr_data: pd.DataFrame = pd.DataFrame(lgdpr_in_base_year.values * scale_factor.values)
        lgdpr_data.index = self.sym_data.regions_members
        lgdpr_data.columns = publication_data.columns

        # Step 5 and 6.
        for variable_name in publication_data.index:
            variable_units: str = str(self.database.variables.loc[variable_name, 'units'])
            match variable_units:
                case 'usgdp':
                    publication_data.loc[[variable_name], :] *= lgdpr_data.loc[[CONSTANTS.USA_REGION_CODE], :].values
                case 'mmtusgdp':
                    publication_data.loc[[variable_name], :] *= lgdpr_data.loc[[CONSTANTS.USA_REGION_CODE], :].values
                case 'btuusgdp':
                    publication_data.loc[[variable_name], :] *= lgdpr_data.loc[[CONSTANTS.USA_REGION_CODE], :].values
                case 'gdp':
                    variable_region: str = str(self.database.variables.loc[variable_name, 'region'])
                    publication_data.loc[[variable_name], :] *= lgdpr_data.loc[[variable_region], :].values
                case 'mmtgdp':
                    variable_region: str = str(self.database.variables.loc[variable_name, 'region'])
                    publication_data.loc[[variable_name], :] *= lgdpr_data.loc[[variable_region], :].values
                case 'btugdp':
                    variable_region: str = str(self.database.variables.loc[variable_name, 'region'])
                    publication_data.loc[[variable_name], :] *= lgdpr_data.loc[[variable_region], :].values
                case 'gwhgdp':
                    variable_region: str = str(self.database.variables.loc[variable_name, 'region'])
                    publication_data.loc[[variable_name], :] *= lgdpr_data.loc[[variable_region], :].values

        return publication_data.astype(float)

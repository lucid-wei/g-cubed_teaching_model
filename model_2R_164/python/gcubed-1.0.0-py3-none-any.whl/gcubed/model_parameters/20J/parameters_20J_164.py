# ------------------------------------------------------------------
# Purpose: Model parameter handling
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
from __future__ import annotations
import logging
import pandas as pd
from gcubed.model_parameters.parameters import Parameters
from gcubed.data.database import Database


class Parameters20J164(Parameters):
    """
    Customise parameter calibration for model 20J 164.
    """

    def __init__(self, database: Database, base_year: int) -> None:
        super().__init__(database=database, base_year=base_year)
        self.__set_delta_ed()

        # Required statements in all final subclasses of the parameter class.
        self._parameter_values.index = self._parameter_full_names
        self.validate()

    def validate(self):
        super().validate()
        pass

    def __set_delta_ed(self):
        """
        delta_ed (note the transpose before storing and vectorising )
        """

        delta_ed: pd.DataFrame = self.zeros(rows=self.sym_data.electricity_generation_goods_count, cols=self.sym_data.regions_count)
        delta_ed.index = self.sym_data.electricity_generation_goods_members
        delta_ed.columns = self.sym_data.regions_members

        for region in self.sym_data.regions_members:

            io_table: pd.DataFrame = self._io_data.io_table(region)
            if io_table is None:
                raise Exception(f"There is no IO table for region {region}")

            # delta_ed
            if self.sym_data.electricity_generation_goods_count > 0:
                delta_ed_intermediate: pd.DataFrame = io_table.loc[self.sym_data.electricity_generation_goods_members, (self.sym_data.sectors_members[0])]
                delta_ed_intermediate = delta_ed_intermediate / delta_ed_intermediate.sum()
                delta_ed.loc[:, region] = delta_ed_intermediate.to_numpy()
            else:
                pass  # delta_ed has been initialised to zeros so we are done.

        # Store delta_ed - after transposing it.
        delta_ed = delta_ed.transpose()
        self._all_parameters["delta_ed"] = delta_ed
        self.insert_parameter(parameter_name="delta_ed", parameter_value_vector=delta_ed.to_numpy().flatten())

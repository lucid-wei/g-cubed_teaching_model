# ------------------------------------------------------------------
# Purpose: Model parameter handling
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
from __future__ import annotations
import logging
import os
import re
import pandas as pd
import numpy as np
from gcubed.base import Base
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData
from gcubed.data.database import Database
from gcubed.data.calibration_database import CalibrationDatabase
from gcubed.io_data import IOData

class Parameters(Base):
    """
    Manage loading, calculation and provision of model parameters.

    Properties:

        database: The model database

        TODO: Complete this listing of class properties and their explanations.
        _database: the dataframe containing the annual data for all variables.

    """

    def __init__(self, database: Database, base_year: int) -> None:

        logging.info(f"Calibrating the model parameters")

        assert database is not None
        self._sym_data: SymData = database.sym_data
        self._base_year = base_year
        self._calibration_database: CalibrationDatabase = CalibrationDatabase(database=database, base_year=base_year)
        self._io_data: IOData = IOData(sym_data = self.sym_data)

        self._all_parameters: dict[str, dict[str, float]] = None
        self._parameter_values: pd.DataFrame = None

        # Build up dictionary of parameter values provided by the user.
        self.__load_user_set_parameters()

        # Configure all parameter values, using user-specified and computed parameters.
        self.__configure_parameter_values()


    def validate(self):
        """
        Run from subclass initialisation after the subclass initialisation has completed.
        Raise an exception if the parameter setting information is invalid
        """
        assert self._all_parameters is not None
        assert self._parameter_values is not None

        # No parameter value remains null.
        parameters_with_missing_values = self.parameter_values[self.parameter_values['value'].isnull()].index.tolist()
        if len(parameters_with_missing_values) > 0:
            logging.error("The following parameters have not been set:\n{}".format(parameters_with_missing_values))
            raise Exception(f"The model is not ready to run. The following parameters have missing values:\n{parameters_with_missing_values}")

        # If there is an electricity distribution sector,
        # then phi parameter has a row for each non-distribution sector
        # otherwise there is a row for all sectors.
        phi = self.parameter("phi")
        if self.sym_data.energy_distribution_sectors_count > 0:
            assert len(
                phi.index) == self.sym_data.non_energy_distribution_sectors_count
        else:
            assert len(
                phi.index) == self.sym_data.sectors_count

        # If the parameters include TCAX, then the SYM model must include the variable with the same name.
        # TODO: enable these validations when adding optimal policy handling to stable manifold class.
        # if self.EMZT is not None and isinstance(self.EMZT, pd.DataFrame):
        #     assert self.TCAX  is not None
        #     if not self.sym_data.has_variable(variable_name_prefix="EMZT"):
        #         logging.error(
        #             "The user parameters refer to EMZT but EMZT is not in the SYM model definition.")
        # if self.TCAX is not None and isinstance(self.TCAX, pd.DataFrame):
        #     assert self.EMZT is not None
        #     if not self.sym_data.has_variable(variable_name_prefix="TCAX"):
        #         logging.error(
        #             "The user parameters refer to TCAX but TCAX is not in the SYM model definition.")

        # Policy optimisation only allowed to be turned on 
        # if the model parameters include TCAX and EMZT for all regions
        # and both of those parameters are not zero for all regions.
        # TODO: enable these validations when adding optimal policy handling to stable manifold class.
        # TODO: Are there other constraints that should also be imposed (e.g. TCAX and EMZT should be 1 for same regions?)
        if self.configuration.stable_manifold_use_policy_optimisation:
            assert self.EMZT is not None
            assert isinstance(self.EMZT , pd.DataFrame)
            if self.EMZT.to_numpy().sum().sum() == 0:
                raise Exception("You cannot set the model configuration to use optimal policy if EMZT (refer to the SYM variables documentation for the model) is all zeros or missing from the user set parameters.")
            assert self.TCAX is not None
            assert isinstance(self.TCAX, pd.DataFrame)
            if self.TCAX.to_numpy().sum().sum() == 0:
                raise Exception("You cannot set the model configuration to use optimal policy if TCAX (refer to the SYM variables documentation for the model) is all zeros or missing from the user set parameters.")

    @property 
    def sym_data(self) -> SymData:
        return self._sym_data

    @property
    def configuration(self) -> ModelConfiguration:
        return self.sym_data.configuration

    @property
    def calibration_database(self) -> CalibrationDatabase:
        return self._calibration_database

    @property
    def calibration_year(self) -> int:
        return self._base_year

    @ property
    def non_sym_parameter_names(self):
        """
        Returns a tuple containing the names of parameters that are assigned values in 
        the user-set parameter values by region but where those parameters are not
        defined in the SYM model definition.
        """
        return ("discrate", "TCAX", "EMZT")

    @ property
    def all_parameters(self):
        return self._all_parameters

    def parameter(self, parameter_name: str) -> pd.DataFrame:
        """
        Arguments:

        parameter_name: The name of the parameter to return.

        Return the value of the named parameter as a dataframe.

        Raise an exception if the parameter is not available.
        """
        if parameter_name in self.all_parameters:
            return self.all_parameters[parameter_name]
        raise Exception(f"Parameter {parameter_name} is not set in the model.")

    def has_parameter(self, parameter_name: str) -> bool:
        """
        Arguments:

        parameter_name: The name of the parameter to return.

        Return true iff the parameter is available and false otherwise.
        """
        if not parameter_name in self.all_parameters:
            return False
        return True


    @ property
    def parameter_values(self):
        """
        The vectorised parameter values in SYM model order as a data frame
        indexed by the parameter name.
        """
        return self._parameter_values

    @ property
    def parameter_values_vector(self) -> np.ndarray:
        """
        Used when evaluating the model equations for linearisation.
        """
        result: np.ndarray = self.parameter_values.value.to_numpy()
        return result

    @ property
    def discrate(self) -> pd.DataFrame:
        """
        Discount rates by region
        """
        return self.all_parameters["discrate"]

    @ property
    def TCAX(self) -> pd.DataFrame:
        """
        The TCAX parameter values are 1 for regions where the TCAX (unit tax on carbon)
        is to be used for the region and 0 if it is not to be used for the region.
        This feeds into the stable manifold calculation.
        """
        return self.all_parameters["TCAX"]

    @ property
    def EMZT(self) -> pd.DataFrame:
        """
        The EMZT parameter values are 1 for regions where the EMZT (carbon emissions)
        is to be used for the region and 0 if it is not to be used for the region.
        This feeds into the stable manifold calculation.
        """
        return self.all_parameters["EMZT"]


    def __load_user_set_parameters(self):
        """
        Loads the user-specified parameter values from the CSV file
        listed in the model configuration.
        """

        # Load the parameter values that are set by the user (not in code)
        filename = self.configuration.parameters_file
        if not os.path.isfile(filename):
            raise Exception("setparameters file " +
                            filename + " does not exist.")

        # Load the data and drop the header row that was read in from the CSV file.
        data: pd.DataFrame = pd.read_csv(filename, header=None)
        data = data.iloc[1:, :]

        # Read through the rows of the data, populating
        # a parameter-name keyed dictionary of parameter values.
        # Take care with parameters that have values spanning
        # multiple rows. Just store them using the base name
        # and with the value being the grid of associated values.
        self._all_parameters: dict[str, pd.DataFrame] = dict()
        key: str = None
        values: pd.DataFrame = None

        for row in data.itertuples(index=False):
            name: str = row[0]

            if isinstance(name, float):
                raise Exception(f"In the parameters CSV file, the parameter {name} should not have a float datatype. Is it missing?")

            if name is None:
                continue

            if name == 'end':
                if key is not None:
                    values.columns = self.sym_data.regions_members
                    self._all_parameters[key] = values
                break

            new_values = pd.DataFrame(row[1:])
            new_values = pd.DataFrame.transpose(new_values)
            new_values = new_values.astype("float")

            if '(' in name:
                name_parts: list = name.split('(')
                base_name = name_parts[0]
                if base_name != key:
                    if key is not None:
                        values.columns = self.sym_data.regions_members
                        self._all_parameters[key] = values
                    key = base_name
                    values = new_values
                else:
                    values = pd.concat([values, new_values], ignore_index=True)
                    values.reset_index()
            else:
                if key is not None:
                    values.columns = self.sym_data.regions_members
                    self._all_parameters[key] = values
                key = None
                values = None
                new_values.columns = self.sym_data.regions_members
                self._all_parameters[name] = new_values


    def __configure_parameter_values(self):
        """
        Associates a value with each parameter in the model.
        Parameters are either set by the user or they
        are computed.
        """
        # Get the list of parameter names as the relevant column from var_map
        parameter_details: pd.DataFrame = self.sym_data.var_map
        parameter_details = self.sym_data.var_map[self.sym_data.var_map.var_type == "par"].copy()

        # Add a column of missing values that will be filled in.
        parameter_details['value'] = np.nan
        self._parameter_full_names = parameter_details.name.to_list()
        self._parameter_base_names: list[str] = [re.sub("[\(\[].*?[\)\]]", "", parameter_name) for parameter_name in self._parameter_full_names]
        parameter_details = parameter_details.reset_index(drop=True)
        self._parameter_values = parameter_details

        # Incorporate information for the user-specified parameters.
        self.__set_user_specified_parameters()

        # Now set up the parameters that are determined programmatically (not by direct user input)
        # Store them in the parameters dictionary as well as in the long vector of parameter values.
        self.__set_a_matrix_parameters()
        self.__set_investment_parameters()
        self.__set_cd_parameters()
        self.__set_delta_parameters()
        self.__set_emissions_parameters()
        self._set_weight_parameters()
        self.__set_other_parameters()


    def __set_user_specified_parameters(self):
        """
        Set the values in the parameters.

        The user set parameters are contained in a dictionary of dataframes.
        Iterate this dictionary, vectorise the dataframe appropriately, and add the vectorised
        values to the parameter_details value column.
        """
        user_set_parameter_names = self._all_parameters.keys()
        for user_set_parameter_name in user_set_parameter_names:

            # Stack the transposed rows of the parameter value to store in dataframe.
            user_set_parameter_value: pd.DataFrame = self._all_parameters[user_set_parameter_name]
            assert user_set_parameter_value is not None

            vectorised_parameter_value: np.ndarray = user_set_parameter_value.to_numpy().flatten()
            vectorised_parameter_value = vectorised_parameter_value.reshape((len(vectorised_parameter_value), 1))
            self.insert_parameter(user_set_parameter_name, vectorised_parameter_value)

    def __set_a_matrix_parameters(self):
        """
        aeye - Identity matrix.
        ashr -
        ainv - Inverse of (aeye - ashr)
        """
        # aeye - Identity matrix
        aeye: pd.DataFrame = pd.DataFrame(np.identity(self.sym_data.regions_count))
        aeye.index = self.sym_data.regions_members
        aeye.columns = self.sym_data.regions_members
        self._all_parameters["aeye"] = aeye
        self.insert_parameter("aeye", aeye.to_numpy().flatten())

        # ashr parameter - Supposed to be the asset split among currencies, for each region.
        # TODO: Figure out why this approach to setting ashr makes sense. Figure out why this is a constant.
        # Create the vector yra that is the value of YRATN(XX) for each region XX as given in the original data set
        # The yra matrix is the values for YRATN in the base year?. (nominal? GDP ratios to USA)
        # Replicate yra as a column vector, once for each region, to create a square matrix and then obtain its lower triangular matrix,
        # (zeroing out the values above the main diagonal). Use the numpy tril function to get the lower triangular matrix.
        # Subtract the lower triangular matrix from the original matrix to get zero everywhere except
        # above the main diagonal.
        # sum the columns of this resulting matrix.
        # For each region, if its column total is above zero, divide all elements in the regions
        # column of the resulting matrix by the column total to get the column to sum to 1.
        # If the region's column total is zero, then set the first element in that column to 1
        # implying that all future holdings of assets by the region described by that column will be in US dollars.
        yra: np.ndarray = self.calibration_database.get_data('^YRATN\(', self.calibration_year).to_numpy()
        ashr: np.ndarray = np.repeat(yra, self.sym_data.regions_count)
        ashr = ashr.reshape((self.sym_data.regions_count,
                             self.sym_data.regions_count))
        ashr = ashr - np.tril(ashr, k=0)
        column_totals = ashr.sum(axis=0)
        # Divide by column totals, ensuring that we do not try to
        # divide zero by zero. Use -1 in place of the zeros so we can find the zeros in the next step...
        column_totals[column_totals == 0] = -1
        ashr = ashr/column_totals
        for i in range(1, self.sym_data.regions_count-1, 1):
            if column_totals[i] == -1:
                ashr[0][i] = 1
        ashr = np.abs(ashr)
        self._all_parameters["ashr"] = ashr
        self.insert_parameter("ashr", ashr.flatten())

        # ainv parameter - matrix inverse of (aeye - ashr)
        ainv: np.ndarray = np.linalg.inv(aeye - ashr)
        # logging.debug("####### ainv")
        # logging.debug(ainv)
        self._all_parameters["ainv"] = ainv
        self.insert_parameter("ainv", ainv.flatten())

    def __set_investment_parameters(self):
        """
        base_jk parameter - base investment (J) divided by capital (K)
        for the calibration year for each region/standard industry combination:

        This corresponds to a matrix formed from elements
        in each row of data provided in the calibration year database.
        """
        inv: np.ndarray = self.calibration_database.get_data('^INV\(', self.calibration_year).to_numpy()
        cap: np.ndarray = self.calibration_database.get_data('^CAP\(', self.calibration_year).to_numpy()
        base_jk: np.ndarray = (inv / cap).reshape((self.sym_data.non_energy_distribution_sectors_count,self.sym_data.regions_count))
        self._all_parameters["base_jk"] = base_jk
        self.insert_parameter("base_jk", base_jk.flatten())

    def __set_cd_parameters(self):
        """
        cd_*  parameters are all switches to flip between the
        Constant Elasticity of Substitution (CES) production function
        and the Cobb-Douglas production function.

        A value of 1 means Cobb-Douglas and 0 means CES.

        These parameters are all inferred from the supplied elasticities of
        substitution. If the elasticities of substitution are close enough to 1
        then the elasticity of substitution is effectively set to 1 by
        working with the Cobb-Douglas function.
        """

        sigma_parameter_names: list[str] = []
        for parameter_name in self.all_parameters:
            if parameter_name.startswith("sigma_"):
                sigma_parameter_names.append(parameter_name)

        for sigma_parameter_name in sigma_parameter_names:
            cd_parameter_name: str = sigma_parameter_name.replace("sigma_", "cd_", 1)
            cd_parameter_value = self.__set_cd(self._all_parameters[sigma_parameter_name])
            self._all_parameters[cd_parameter_name] = cd_parameter_value
            self.insert_parameter(cd_parameter_name, cd_parameter_value.to_numpy().flatten())

    def __set_delta_parameters(self):
        """
        TODO: Document the definitions of each of these parameters
        and the economics behind their calibration.

        delta_dom
        delta_e
        delta_m
        delta_ff
        delta_mH - C: consumption column of IO table
        delta_mR - I: investment column of IO table
        delta_mG - G: government column of IO table
        delta_eH - C: consumption column of IO table - energy sectors
        delta_eR - I: investment column of IO table - energy sectors
        delta_eG - G: government column of IO table - energy sectors
        delta_oG - C: consumption column of IO table
        delta_oH - I: investment column of IO table
        delta_oR - G: government column of IO table
        """

        # delta_dom parameter - The ratio of OUY (composite supply) to
        # OUP (domestic production), in the calibration year,
        # for all the non-electricity generation sectors (g01, g02, ...).
        # OUP is region AND sector based.
        # OUY is region and good based.
        oup: np.ndarray = self.calibration_database.get_data('^OUP\(', self.calibration_year).to_numpy()
        oup = pd.DataFrame(oup.reshape(self.sym_data.goods_count, self.sym_data.regions_count))
        oup.index = self.sym_data.goods_members
        oup.columns = self.sym_data.regions_members
        ouy: np.ndarray = self.calibration_database.get_data('^OUY\(', self.calibration_year).to_numpy()
        ouy = pd.DataFrame(ouy.reshape(self.sym_data.goods_count, self.sym_data.regions_count))
        ouy.index = self.sym_data.goods_members
        ouy.columns = self.sym_data.regions_members
        oup = oup.loc[self.sym_data.non_electricity_generation_goods_members, :]
        ouy = ouy.loc[self.sym_data.non_electricity_generation_goods_members, :]
        delta_dom = oup / ouy
        self._all_parameters["delta_dom"] = delta_dom
        self.insert_parameter("delta_dom", delta_dom.to_numpy().flatten())

        # Initialise the delta parameters that will be populated as we iterate the regions
        delta_e: np.ndarray = None

        delta_m: np.ndarray = None

        delta_mH: pd.DataFrame = self.zeros(
            rows=self.sym_data.non_energy_or_generation_goods_count, cols=self.sym_data.regions_count)
        delta_mH.index = self.sym_data.non_energy_or_generation_goods_members
        delta_mH.columns = self.sym_data.regions_members

        delta_mR: pd.DataFrame = self.zeros(
            rows=self.sym_data.non_energy_or_generation_goods_count, cols=self.sym_data.regions_count)
        delta_mR.index = self.sym_data.non_energy_or_generation_goods_members
        delta_mR.columns = self.sym_data.regions_members

        delta_mG: pd.DataFrame = self.zeros(
            rows=self.sym_data.non_energy_or_generation_goods_count, cols=self.sym_data.regions_count)
        delta_mG.index = self.sym_data.non_energy_or_generation_goods_members
        delta_mG.columns = self.sym_data.regions_members

        delta_eG: pd.DataFrame = self.zeros(
            rows=self.sym_data.energy_goods_count, cols=self.sym_data.regions_count)
        delta_eG.index = self.sym_data.energy_goods_members
        delta_eG.columns = self.sym_data.regions_members

        delta_eH: pd.DataFrame = self.zeros(
            rows=self.sym_data.energy_goods_count, cols=self.sym_data.regions_count)
        delta_eH.index = self.sym_data.energy_goods_members
        delta_eH.columns = self.sym_data.regions_members

        delta_eR: pd.DataFrame = self.zeros(
            rows=self.sym_data.energy_goods_count, cols=self.sym_data.regions_count)
        delta_eR.index = self.sym_data.energy_goods_members
        delta_eR.columns = self.sym_data.regions_members

        delta_oH: pd.DataFrame = self.zeros(
            rows=self.sym_data.factors_of_production_count, cols=self.sym_data.regions_count)
        delta_oH.index = self.sym_data.factors_of_production_members
        delta_oH.columns = self.sym_data.regions_members

        delta_oR: pd.DataFrame = self.zeros(
            rows=self.sym_data.factors_of_production_count, cols=self.sym_data.regions_count)
        delta_oR.index = self.sym_data.factors_of_production_members
        delta_oR.columns = self.sym_data.regions_members

        delta_oG: pd.DataFrame = self.zeros(
            rows=self.sym_data.factors_of_production_count, cols=self.sym_data.regions_count)
        delta_oG.index = self.sym_data.factors_of_production_members
        delta_oG.columns = self.sym_data.regions_members

        # delta_o preparation
        delta_o_rows: list[str] = self._io_data.io_table_inputs
        delta_o_rows = [i for i in delta_o_rows if i not in self.sym_data.energy_distribution_sectors_members]
        delta_o_rows = [i for i in delta_o_rows if i not in [self._io_data.io_table_tax]]
        delta_oK: pd.DataFrame = self.zeros(rows=self.sym_data.non_energy_distribution_sectors_count, cols=self.sym_data.regions_count)
        delta_oL: pd.DataFrame = self.zeros(rows=self.sym_data.non_energy_distribution_sectors_count, cols=self.sym_data.regions_count)
        delta_oE: pd.DataFrame = self.zeros(rows=self.sym_data.non_energy_distribution_sectors_count, cols=self.sym_data.regions_count)
        delta_oM: pd.DataFrame = self.zeros(rows=self.sym_data.non_energy_distribution_sectors_count, cols=self.sym_data.regions_count)
        delta_oK.columns = self.sym_data.regions_members
        delta_oL.columns = self.sym_data.regions_members
        delta_oE.columns = self.sym_data.regions_members
        delta_oM.columns = self.sym_data.regions_members
        delta_oK.index = self.sym_data.non_energy_distribution_sectors_members
        delta_oL.index = self.sym_data.non_energy_distribution_sectors_members
        delta_oE.index = self.sym_data.non_energy_distribution_sectors_members
        delta_oM.index = self.sym_data.non_energy_distribution_sectors_members

        # Now calculate the delta parameters based on the IO tables.
        for region in self.sym_data.regions_members:

            io_table: pd.DataFrame = self._io_data.io_table(region)
            if io_table is None:
                raise Exception(f"There is no IO table for region {region}")

            # delta_e
            if self.sym_data.energy_distribution_sectors_count > 0:
                delta_e_column_names = self.sym_data.non_energy_distribution_sectors_members
            else:
                delta_e_column_names = self.sym_data.sectors_members
            delta_e_io_data = io_table.loc[self.sym_data.energy_goods_members,delta_e_column_names]
            delta_e_io_data_totals = delta_e_io_data.sum()
            delta_e_region = np.transpose((delta_e_io_data / delta_e_io_data_totals).to_numpy())
            if delta_e is None:
                delta_e = delta_e_region
            else:
                delta_e = np.vstack((delta_e, delta_e_region))

           # delta_m
            if self.sym_data.energy_goods_count > 0:
                delta_m_column_names = self.sym_data.non_energy_distribution_sectors_members
            else:
                delta_m_column_names = self.sym_data.sectors_members
            delta_m_io_data = io_table.loc[self.sym_data.non_energy_goods_members,
                                           delta_m_column_names]
            delta_m_io_data_totals = delta_m_io_data.sum()
            delta_m_region = delta_m_io_data / delta_m_io_data_totals
            delta_m_region = pd.DataFrame(
                np.transpose(delta_m_region.to_numpy()))
            delta_m_region.index = delta_m_column_names
            delta_m_region.columns = self.sym_data.non_energy_goods_members
            delta_m_region_subset = delta_m_region.loc[:, self.sym_data.non_energy_or_generation_goods_members]
            delta_m_region = delta_m_region_subset.to_numpy()
            if delta_m is None:
                delta_m = delta_m_region
            else:
                delta_m = np.vstack((delta_m, delta_m_region))

            # delta_mH
            delta_mH_intermediate: pd.DataFrame = io_table.loc[self.sym_data.non_energy_goods_members,"C"]
            delta_mH_intermediate = delta_mH_intermediate / delta_mH_intermediate.sum()
            delta_mH.loc[self.sym_data.non_energy_or_generation_goods_members,region] = delta_mH_intermediate

            # delta_mR
            delta_mR_intermediate: pd.DataFrame = io_table.loc[self.sym_data.non_energy_goods_members, "I"]
            delta_mR_intermediate = delta_mR_intermediate / delta_mR_intermediate.sum()
            delta_mR.loc[self.sym_data.non_energy_or_generation_goods_members, region] = delta_mR_intermediate

            # delta_mG
            delta_mG_intermediate: pd.DataFrame = io_table.loc[self.sym_data.non_energy_goods_members, "G"]
            delta_mG_intermediate = delta_mG_intermediate / delta_mG_intermediate.sum()
            delta_mG.loc[self.sym_data.non_energy_or_generation_goods_members, region] = delta_mG_intermediate

            # delta_eH
            delta_eH_intermediate: pd.DataFrame = io_table.loc[self.sym_data.energy_goods_members, "C"]
            delta_eH_intermediate = delta_eH_intermediate / delta_eH_intermediate.sum()
            delta_eH.loc[:, region] = delta_eH_intermediate.to_numpy()

            # delta_eR
            delta_eR_intermediate: pd.DataFrame = io_table.loc[self.sym_data.energy_goods_members, "I"].copy() * 1000000000
            delta_eR_intermediate = delta_eR_intermediate / delta_eR_intermediate.sum()
            delta_eR.loc[:, region] = delta_eR_intermediate.to_numpy()

            # delta_eG
            delta_eG_intermediate: pd.DataFrame = io_table.loc[self.sym_data.energy_goods_members, "G"]
            delta_eG_intermediate = delta_eG_intermediate / delta_eG_intermediate.sum()
            delta_eG.loc[:, region] = delta_eG_intermediate.to_numpy()

            # delta_oH, delta_oR, delta_oG
            non_tax_rows = io_table.index.to_list()
            non_tax_rows.remove("TAX")

            delta_oH_intermediate: pd.DataFrame = io_table.loc[non_tax_rows, "C"]
            delta_oH_total = delta_oH_intermediate.sum()
            delta_oH.loc["K", region] = delta_oH_intermediate["K"] / delta_oH_total
            delta_oH.loc["L", region] = delta_oH_intermediate["L"] / delta_oH_total
            delta_oH.loc["E", region] = delta_oH_intermediate[self.sym_data.energy_goods_members].sum() / delta_oH_total
            delta_oH.loc["M", region] = delta_oH_intermediate[self.sym_data.non_energy_goods_members].sum() / delta_oH_total

            delta_oR_intermediate: pd.DataFrame = io_table.loc[non_tax_rows, "I"]
            delta_oR_total = delta_oR_intermediate.sum()
            delta_oR.loc["K", region] = delta_oR_intermediate["K"] / delta_oR_total
            delta_oR.loc["L", region] = delta_oR_intermediate["L"] / delta_oR_total
            delta_oR.loc["E", region] = delta_oR_intermediate[self.sym_data.energy_goods_members].sum() / delta_oR_total
            delta_oR.loc["M", region] = delta_oR_intermediate[self.sym_data.non_energy_goods_members].sum() / delta_oR_total

            non_tax_rows.remove("K")
            delta_oG_intermediate: pd.DataFrame = io_table.loc[non_tax_rows, "G"]
            delta_oG_total = delta_oG_intermediate.sum()
            delta_oG.loc["K", region] = 0 / delta_oG_total
            delta_oG.loc["L", region] = delta_oG_intermediate["L"] /  delta_oG_total
            delta_oG.loc["E", region] = delta_oG_intermediate[self.sym_data.energy_goods_members].sum() / delta_oG_total
            delta_oG.loc["M", region] = delta_oG_intermediate[self.sym_data.non_energy_goods_members].sum() / delta_oG_total

            # delta_o (delta_oK, delta_oL, delta_oE, delta_oM) calculations
            delta_o_denominators = io_table.loc[delta_o_rows,self.sym_data.non_energy_distribution_sectors_members].sum()
            delta_oK_numerators = io_table.loc[self._io_data.io_table_capital,self.sym_data.non_energy_distribution_sectors_members]
            delta_oK_region = delta_oK_numerators / delta_o_denominators
            delta_oL_numerators = io_table.loc[self._io_data.io_table_labour,self.sym_data.non_energy_distribution_sectors_members]
            delta_oL_region = delta_oL_numerators / delta_o_denominators
            delta_oE_numerators = io_table.loc[self.sym_data.energy_goods_members,self.sym_data.non_energy_distribution_sectors_members].sum()
            delta_oE_region = delta_oE_numerators / delta_o_denominators
            delta_oM_numerators = io_table.loc[self.sym_data.non_energy_goods_members,self.sym_data.non_energy_distribution_sectors_members].sum()
            delta_oM_region = delta_oM_numerators / delta_o_denominators

            # Store the delta_o components
            delta_oK.loc[:, region] = delta_oK_region.to_numpy()
            delta_oL.loc[:, region] = delta_oL_region.to_numpy()
            delta_oE.loc[:, region] = delta_oE_region.to_numpy()
            delta_oM.loc[:, region] = delta_oM_region.to_numpy()

        # Store all the delta parameters that were populated
        # while iterating over the IO tables for the regions.

        # Store delta_e
        delta_e: pd.DataFrame = pd.DataFrame(delta_e)
        delta_e.columns = self.sym_data.energy_goods_members
        self._all_parameters["delta_e"] = delta_e
        self.insert_parameter("delta_e", delta_e.to_numpy().flatten())

        # Store delta_m
        delta_m: pd.DataFrame = pd.DataFrame(delta_m)
        delta_m.columns = self.sym_data.non_energy_or_generation_goods_members
        self._all_parameters["delta_m"] = delta_m
        self.insert_parameter("delta_m", delta_m.to_numpy().flatten())

        # Store delta_mH
        self._all_parameters["delta_mH"] = delta_mH
        self.insert_parameter("delta_mH", delta_mH.to_numpy().flatten())

        # Store delta_mR
        self._all_parameters["delta_mR"] = delta_mR
        self.insert_parameter("delta_mR", delta_mR.to_numpy().flatten())

        # Store delta_mG
        self._all_parameters["delta_mG"] = delta_mG
        self.insert_parameter("delta_mG", delta_mG.to_numpy().flatten())

        # Store delta_eH
        # Replace nan values due to division by zero, with zero.
        delta_eH = delta_eH.fillna(0)
        self._all_parameters["delta_eH"] = delta_eH
        self.insert_parameter("delta_eH", delta_eH.to_numpy().flatten())

        # Store delta_eR
        # Replace nan values due to division by zero, with zero.
        delta_eR = delta_eR.fillna(0)
        self._all_parameters["delta_eR"] = delta_eR
        self.insert_parameter("delta_eR", delta_eR.to_numpy().flatten())

        # Store delta_eG
        # Replace nan values due to division by zero, with zero.
        delta_eG = delta_eG.fillna(0)
        self._all_parameters["delta_eG"] = delta_eG
        self.insert_parameter("delta_eG", delta_eG.to_numpy().flatten())

        # Store delta_oH
        self._all_parameters["delta_oH"] = delta_oH
        self.insert_parameter("delta_oH", delta_oH.to_numpy().flatten())

        # Store delta_oR
        self._all_parameters["delta_oR"] = delta_oR
        self.insert_parameter("delta_oR", delta_oR.to_numpy().flatten())

        # Store delta_oG
        self._all_parameters["delta_oG"] = delta_oG
        self.insert_parameter("delta_oG", delta_oG.to_numpy().flatten())

        # store delta_o
        delta_o: pd.DataFrame = pd.DataFrame(np.vstack((delta_oK.to_numpy(), delta_oL.to_numpy(), delta_oE.to_numpy(), delta_oM.to_numpy())))
        delta_o.columns = self.sym_data.regions_members
        self.all_parameters["delta_o"] = delta_o
        self.insert_parameter("delta_o", delta_o.to_numpy().flatten())

        # delta_ff calculation - very similar to eer_weight calculation!!!
        # delta_ff foreign source weights in FF
        imp = self.calibration_database.get_data('^IMP\(', self.calibration_year).to_numpy()
        imp = imp.reshape((self.sym_data.non_electricity_generation_goods_count,
                           self.sym_data.regions_count,
                           self.sym_data.regions_count))

        # Sum across sectors (given in axis 0 of the numpy 3D array)
        # to give the total for each region/region combination
        # produce the data in variable a as used in Ox implementation.
        imp_totals = np.sum(imp, axis=2)

        # Divide region to region data for each good by sum across to-regions - I think...
        # This replicates the normalisation in the Ox implementation and vectorises in the same way...
        # Geoff: I am sure we could do less transposing if I had good understanding of axis
        # manipulation in Python numpy arrays.
        delta_ff: np.ndarray = None
        delta_ff_dataframe: pd.DataFrame = None
        for good_index in range(self.sym_data.non_electricity_generation_goods_count):
            imp[good_index, :, :] = np.transpose(imp[good_index, :, :]) / imp_totals[good_index, :]
            if delta_ff is None:
                delta_ff = np.transpose(imp[good_index, :, :]).flatten()
                delta_ff_dataframe = imp[good_index, :, :]
            else:
                delta_ff_dataframe = np.vstack((delta_ff_dataframe, imp[good_index, :, :]))
                delta_ff = np.hstack((delta_ff, np.transpose(imp[good_index, :, :]).flatten()))

        delta_ff_dataframe = pd.DataFrame(delta_ff_dataframe)
        delta_ff_dataframe.columns = self.sym_data.regions_members
        self._all_parameters["delta_ff"] = delta_ff_dataframe
        delta_ff = np.transpose(delta_ff)
        self.insert_parameter("delta_ff", delta_ff)

    def _set_weight_parameters(self):
        """
        prid_weight - Domestic production for each sector in a region.
        as a fraction of total domestic production across all sectors
        for that region.

        prim_weight - DF imports by good type divided by
        the value of imports in total at the destination.

        prix_weight - Exports by non-electricity generating sector  as a fraction of region total exports
        where exports are measured as a percentage of real GDP for the region.

        eer_weight - trade weights, NEER (trade-weighted exch rate, FC/domestic) and REER (trade-weighted real exch rate, FC/domestic)

        All of these parameters are set using data from the calibration year.
        """

        # prid_weight calculation
        oup: np.ndarray = self.calibration_database.get_data('^OUP\(', self.calibration_year)
        oup_matrix = oup.to_numpy().reshape((self.sym_data.sectors_count, self.sym_data.regions_count))
        oup_by_region = np.sum(oup_matrix, axis=0)
        prid_weight = pd.DataFrame(oup_matrix / oup_by_region)
        prid_weight.index = self.sym_data.sectors_members
        prid_weight.columns = self.sym_data.regions_members
        self._all_parameters["prid_weight"] = prid_weight
        self.insert_parameter("prid_weight", prid_weight.to_numpy().flatten())

        # prim_weight calculation

        imq: np.ndarray = self.calibration_database.get_data('^IMQ\(', self.calibration_year)
        imq_matrix = imq.to_numpy().reshape((self.sym_data.non_electricity_generation_goods_count, self.sym_data.regions_count))

        imqt: np.ndarray = self.calibration_database.get_data('^IMQT\(', self.calibration_year).to_numpy().reshape((1, self.sym_data.regions_count))
        prim_weight = pd.DataFrame(imq_matrix / imqt)
        prim_weight.index = self.sym_data.non_electricity_generation_goods_members
        prim_weight.columns = self.sym_data.regions_members
        self._all_parameters["prim_weight"] = prim_weight
        self.insert_parameter("prim_weight", prim_weight.to_numpy().flatten())

        # prix_weight calculation
        exq = self.calibration_database.get_data('^EXQ\(', self.calibration_year).to_numpy().reshape((self.sym_data.non_electricity_generation_goods_count, self.sym_data.regions_count))
        exq_region_totals = np.sum(exq, axis=0)
        prix_weight = pd.DataFrame(exq / exq_region_totals)
        prix_weight.index = self.sym_data.non_electricity_generation_goods_members
        prix_weight.columns = self.sym_data.regions_members
        self._all_parameters["prix_weight"] = prix_weight
        self.insert_parameter("prix_weight", prix_weight.to_numpy().flatten())

        # eer_weight calculation
        imp = self.calibration_database.get_data('^IMP\(', self.calibration_year).to_numpy()
        imp = imp.reshape((self.sym_data.non_electricity_generation_goods_count,
                           self.sym_data.regions_count,
                           self.sym_data.regions_count))
        # Sum across sectors (given in axis 0 of the numpy 3D array)
        # to give the total for each region/region combination
        imp = np.sum(imp, axis=0)
        imp_totals = np.sum(imp, axis=1)
        # TODO: Geoff says: Someone with better knowledge of numpy arrays
        # should eliminate at least one transpose in the line below.
        imp = np.transpose(np.transpose(imp) / imp_totals)
        eer_weight = pd.DataFrame(imp)
        eer_weight.index = self.sym_data.regions_members
        eer_weight.columns = self.sym_data.regions_members
        self._all_parameters["eer_weight"] = eer_weight
        self.insert_parameter("eer_weight", eer_weight.to_numpy().flatten())

    def __set_other_parameters(self):
        """
        transgdp - transfers per unit of GDP - set to zeros.

        mongdp - coefficient on money-demanded in
        the equation for total wealth for a region

        TODO: Determine if makeinv is being computed as described in the SYM documentation.
        The Ox implementation is being replicated at the moment but the makeinv table is
        not aligned to the way it is described in the SYM documentation.

        makeinv - Supposed to be the inverse of the make table but
        currently being set up as rows of 1s in a log matrix of zeros.

        """

        # transgdp - done.
        transgdp = self.zeros(rows=1, cols=self.sym_data.regions_count)
        self._all_parameters["transgdp"] = transgdp
        self.insert_parameter("transgdp", transgdp.to_numpy().flatten())

        # mongdp
        mongdp = self.zeros(rows=1, cols=self.sym_data.regions_count)
        self._all_parameters["mongdp"] = mongdp
        self.insert_parameter("mongdp", mongdp.to_numpy().flatten())

        # TODO: implement makeinv calculation
        sector_count = self.sym_data.sectors_count
        makeinv = self.zeros(rows=(sector_count * sector_count),
                             cols=self.sym_data.regions_count)
        unit_vector = self.zeros(rows=1,
                                 cols=self.sym_data.regions_count) + 1
        for i in range(sector_count):
            row_index = i*(sector_count)+i
            makeinv.iloc[row_index, :] = unit_vector
            i = i + 1
        self._all_parameters["makeinv"] = makeinv
        self.insert_parameter("makeinv", makeinv.to_numpy().flatten())

    def __set_emissions_parameters(self):
        """
        Set the values of the emissions parameters.
        TODO: These parameters need more detailed descriptions in SYM.
        carcoef - carbon emissions coefficients
        btucoef - emissions coefficients, energy
        gwhcoef - gigawatt hours electricity per annum
        """

        if self.sym_data.electricity_generation_goods_count == 0:

            carcoef: pd.DataFrame = self.zeros(rows=self.sym_data.sectors_count, cols=self.sym_data.regions_count)
            self._all_parameters["carcoef"] = carcoef
            self.insert_parameter("carcoef", carcoef.to_numpy().flatten())

            btucoef: pd.DataFrame = self.zeros(rows=self.sym_data.sectors_count, cols=self.sym_data.regions_count)
            self._all_parameters["btucoef"] = btucoef
            self.insert_parameter("btucoef", btucoef.to_numpy().flatten())

            return

        # Now for the non-zero setting of the emissions parameters.
        e_coal: np.ndarray = self.calibration_database.get_data('^ECOL\(', self.configuration.calibration_of_carbon_coefficients_year).to_numpy()
        e_oil: np.ndarray = self.calibration_database.get_data('^EOIL\(', self.configuration.calibration_of_carbon_coefficients_year).to_numpy()
        e_gas: np.ndarray = self.calibration_database.get_data('^EGAS\(', self.configuration.calibration_of_carbon_coefficients_year).to_numpy()

        b_coal: np.ndarray = self.calibration_database.get_data('^BCOL\(', self.configuration.calibration_of_carbon_coefficients_year).to_numpy()
        b_oil: np.ndarray = self.calibration_database.get_data('^BOIL\(', self.configuration.calibration_of_carbon_coefficients_year).to_numpy()
        b_gas: np.ndarray = self.calibration_database.get_data('^BGAS\(', self.configuration.calibration_of_carbon_coefficients_year).to_numpy()


        # Keep as a pd.Dataframe instead of a np.ndarray so we can select by region later on.
        lgdpn: pd.DataFrame = self.calibration_database.get_data('^LGDPN\(', self.configuration.calibration_of_carbon_coefficients_year)
        lgdpn.index = self.sym_data.regions_members

        carcoef: pd.DataFrame = self.zeros(rows=self.sym_data.sectors_count, cols=self.sym_data.regions_count)
        carcoef.index = self.sym_data.goods_members
        carcoef.columns = self.sym_data.regions_members

        btucoef: pd.DataFrame = self.zeros(rows=self.sym_data.sectors_count, cols=self.sym_data.regions_count)
        btucoef.index = self.sym_data.goods_members
        btucoef.columns = self.sym_data.regions_members

        for good in self.sym_data.non_electricity_generation_goods_members:

            oup: np.ndarray = self.calibration_database.get_data('^OUP\({}'.format(self.sym_data.sector_producing(good)), self.configuration.calibration_of_carbon_coefficients_year).to_numpy()
            imq: np.ndarray = self.calibration_database.get_data('^IMQ\({}'.format(good), self.configuration.calibration_of_carbon_coefficients_year).to_numpy()
            exq: np.ndarray = self.calibration_database.get_data('^EXQ\({}'.format(good), self.configuration.calibration_of_carbon_coefficients_year).to_numpy()

            match good:
                case self.sym_data.oil_sector_good:
                    carcoef.loc[[good], :] = (e_oil / (10 * (oup + imq - exq) * lgdpn.to_numpy())).transpose()
                    btucoef.loc[[good], :] = (b_oil / (10 * (oup + imq - exq) * lgdpn.to_numpy())).transpose()

                case self.sym_data.gas_sector_good:
                    carcoef.loc[[good], :] = (e_gas / (10 * (oup + imq - exq) * lgdpn.to_numpy())).transpose()
                    btucoef.loc[[good], :] = (b_gas / (10 * (oup + imq - exq) * lgdpn.to_numpy())).transpose()

                case self.sym_data.coal_sector_good:
                    carcoef.loc[[good], :] = (e_coal / (10 * (oup + imq - exq) * lgdpn.to_numpy())).transpose()
                    btucoef.loc[[good], :] = (b_coal / (10 * (oup + imq - exq) * lgdpn.to_numpy())).transpose()

        self._all_parameters["carcoef"] = carcoef
        self.insert_parameter("carcoef", carcoef.to_numpy().flatten())
        self._all_parameters["btucoef"] = btucoef
        self.insert_parameter("btucoef", btucoef.to_numpy().flatten())

        # Electricity generation (setparsym line 643.)
        gwhcoef: pd.DataFrame = self.zeros(rows=self.sym_data.sectors_count, cols=self.sym_data.regions_count)
        gwhcoef.index = self.sym_data.goods_members
        gwhcoef.columns = self.sym_data.regions_members

        g_coal: np.ndarray = self.calibration_database.get_data('^GCOL\(', self.configuration.calibration_of_carbon_coefficients_year)
        g_coal.index = self.sym_data.regions_members
        g_gas: np.ndarray = self.calibration_database.get_data('^GGAS\(', self.configuration.calibration_of_carbon_coefficients_year)
        g_gas.index = self.sym_data.regions_members
        g_oil: np.ndarray = self.calibration_database.get_data('^GOIL\(', self.configuration.calibration_of_carbon_coefficients_year)
        g_oil.index = self.sym_data.regions_members
        g_nuclear: np.ndarray = self.calibration_database.get_data('^GNUC\(', self.configuration.calibration_of_carbon_coefficients_year)
        g_nuclear.index = self.sym_data.regions_members
        g_wind: np.ndarray = self.calibration_database.get_data('^GWIND\(', self.configuration.calibration_of_carbon_coefficients_year)
        g_wind.index = self.sym_data.regions_members
        g_solar: np.ndarray = self.calibration_database.get_data('^GSOLAR\(', self.configuration.calibration_of_carbon_coefficients_year)
        g_solar.index = self.sym_data.regions_members
        g_hydro: np.ndarray = self.calibration_database.get_data('^GHYDRO\(', self.configuration.calibration_of_carbon_coefficients_year)
        g_hydro.index = self.sym_data.regions_members
        g_other: np.ndarray = self.calibration_database.get_data('^GOTHER\(', self.configuration.calibration_of_carbon_coefficients_year)
        g_other.index = self.sym_data.regions_members

        g_all = pd.concat([g_coal, g_gas, g_oil, g_nuclear, g_wind, g_solar, g_hydro, g_other], axis=1)
        g_all.columns = self.sym_data.electricity_generation_goods_members

        for region in self.sym_data.regions_members:

            total_electricity_generated_in_region = g_all.loc[region, :]

            io_table: pd.DataFrame = self._io_data.io_table(region)

            io_table_GDP = io_table.loc[:, ["C", "I", "G", "X"]].to_numpy().sum()

            # domestic use of output from each electricity generation sector
            generation_goods = self.sym_data.electricity_generation_goods_members
            domestic_uses = io_table.columns.to_list()
            domestic_uses.remove("X")
            domestic_uses.remove("M")
            sub_io_table = io_table.loc[generation_goods, domestic_uses]
            domestic_use_of_electricity = sub_io_table.sum(
                axis='columns')

            # Get the region's scalar float value for LGDPN in the base calibration year.
            region_lgdpn = float(lgdpn.loc[region,:].values[0])

            region_gwhcoef = (100 * total_electricity_generated_in_region) / (region_lgdpn * (domestic_use_of_electricity / io_table_GDP))

            gwhcoef.loc[generation_goods, region] = region_gwhcoef.to_numpy().reshape((len(generation_goods), 1))

        self._all_parameters["gwhcoef"] = gwhcoef
        self.insert_parameter("gwhcoef", gwhcoef.to_numpy().flatten())

    def __set_cd(self, sigma_parameter: pd.DataFrame) -> pd.DataFrame:
        """
        Converts dataframe to zeros/ones, with 1 for any value in the input
        dataframe that is close enough to 1, and zero otherwise.
        """
        result = ((sigma_parameter > 0.99999) & (sigma_parameter < 1.00001))

        # Multiply by 1 to convert Boolean values to integers
        return (result * 1)

    def insert_parameter(self, parameter_name: str, parameter_value_vector: np.ndarray):
        """
        Inserts the vectorised set of values for a parameter into the full parameter values vector.
        """
        row_indices: list[int] = [i for i, x in enumerate(self._parameter_base_names) if x == parameter_name]

        if len(row_indices) == 0:
            logging.warning(f"Parameter {parameter_name} is created but not used in the model.")
            return

        if len(row_indices) != len(parameter_value_vector):
            logging.error(
                "Expected {} values for parameter {} but received {} values".format(
                    len(row_indices), parameter_name, len(parameter_value_vector)))
            return

        self._parameter_values.loc[row_indices, "value"] = parameter_value_vector

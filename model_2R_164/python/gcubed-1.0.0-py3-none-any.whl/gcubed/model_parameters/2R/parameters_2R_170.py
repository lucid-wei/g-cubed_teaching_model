# ------------------------------------------------------------------
# Purpose: Model parameter handling
# Author: Lucid
# ------------------------------------------------------------------
from __future__ import annotations
from gcubed.model_parameters.parameters import Parameters
from gcubed.data.database import Database


class Parameters2R170(Parameters):
    """
    Customise parameter calibration for model 2R 170.
    """

    def __init__(self, database: Database, base_year: int) -> None:
        super().__init__(database=database, base_year=base_year)

        # Required statements in all final subclasses of the parameter class.
        self._parameter_values.index = self._parameter_full_names
        self.validate()

    def validate(self):
        super().validate()

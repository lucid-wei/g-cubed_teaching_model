# ------------------------------------------------------------------
# Purpose: Linearise the model to produce the partial derivative
# matrices that embody the model dynamics.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
import logging
import pandas as pd
import numpy as np
import sys
import importlib
from gcubed.data.gdp_scaled_database import GDPScaledDatabase
from gcubed.model import Model
from gcubed.base import Base
import gcubed.constants as CONSTANTS
from gcubed.sym_data import SymData
from gcubed.model_configuration import ModelConfiguration


class LinearModel(Base):
    """

    The algebra embodied in this class follows 
    https://www.msgpl.com.au/Manuals2021/GGGv20JManual/softwaremanual/algorithm.pdf
    
    The notation has been extended to also include equations for 
    expected endogenous variables to include exogenous variables.

    This class provides the ability to work with the model equations. It:

    1. Computes the partial derivatives of the model equations
    so that an approximation of the model can be expressed as 
    a set of linear equations.
    2. Constructs the matrices of constants associated with the 
    state-space form of the linearised model. This involves eliminating
    the endogenous variables from the model via substitution.

    To use this class:

    1.  instantiate it with a model.
    2.  run the compute_partial_derivatives() method.

    Once this sequence of steps has been completed without raising an exception,
    the matrices associated with the state space form will be accessible
    as properties of the linear model to support solving the model.

    Instantiation determines the values for the RHS variable vectors
    based upon the model's database and the year that has been chosen
    to determine the variable values that the model will be linearised 
    around.

    These RHS variable vector values, and the implied LHS variable vector values 
    are exposed as properties of the linear model. The names of these vector 
    properties are 3 character acronyms:

    The linear model supports evaluation of the model equations to obtain
    values for the LHS and RHS vectors of variables defined in sym_data.

    To understanding the naming conventions, the partial 
    derivatives matrix associated with the partials of
    x1l with respect to z1r are stored in a property called x1l_z1r_partials.
    The same naming convention is used for all partials matrices:
    <LHS_vector_name>_<RHS_vector_name>_partials.

    """

    def __init__(self, model: Model) -> None:

        # Set this switch to true when the partial derivatives have been computed.
        self._linear_model_is_available = False

        assert model is not None
        self._model = model

        # Load the model parameters
        assert self.model.parameters is not None
        self._parameters = self.model.parameters.parameter_values_vector
        assert self._parameters is not None

        self._database = GDPScaledDatabase(database=self.model.database, base_year=self.configuration.calibration_year)

        # Set up the RHS vectors for the model using data for the linearisation year.
        self.__load_rhs_vectors(linearisation_year=self.configuration.calibration_year)

        # Set up the LHS vectors as vectors of zeros.
        self.__configure_lhs_vectors()

        # Import the model equations.
        sys.path.append(self.configuration.sym_directory)
        equations_module = importlib.import_module(self.configuration.sym_output_filename_prefix)
        equations_class = getattr(equations_module, "Equations")
        self._equations = equations_class(x1l=self._x1l,
                                          j1l=self._j1l,
                                          zel=self._zel,
                                          z1l=self._z1l,
                                          x1r=self._x1r,
                                          j1r=self._j1r,
                                          z1r=self._z1r,
                                          zer=self._zer,
                                          yjr=self._yjr,
                                          yxr=self._yxr,
                                          exo=self._exo,
                                          exz=self._exz,
                                          par=self._parameters)

        # Solve for LHS vectors using the model equations,
        # the parameters and the RHS vectors. Store the results as benchmark
        # values for calculating partial derivatives.
        self.__compute_benchmark_equation_results()

        # Generate differences in LHS variables from those used on RHS to evaluate equations
        # These two lines of code do not typically need to run but give insight into linearisation.
        # self.__generate_nonlinear_equation_differences()
        # self.nonlinear_equation_differences.to_csv(f"{self.model.configuration.benchmarking_reports_directory}nonlinear equation LHS-RHS differences.csv")

        # Load the map from RHS variables to model equations to use when computing partial derivatives.
        self.__load_equation_map()

        # Compute the partial derivatives
        self.compute_partial_derivatives()

        self.__validate()

        logging.info("The model has been linearised.")

    def __validate(self):
        """
        Validate the configuration details.
        """

        # Check we have all vectors and they are the right lengths.
        for vector_name in self.sym_data.lhs_vector_names:
            vector = self.get_vector_by_name(vector_name=vector_name)
            assert vector is not None
            assert len(vector) == self.sym_data.vector_length(
                vector_name=vector_name)

    @property
    def delta(self) -> float:
        """
        return the change in any RHS variable used to compute a partial derivative.
        """
        return 0.00000001

    @property
    def linearisation_database(self) -> GDPScaledDatabase:
        return self._database

    @property
    def linear_model_is_available(self) -> bool:
        return self._linear_model_is_available

    @property
    def equations(self):
        return self._equations

    @property
    def model(self):
        return self._model

    @property
    def sym_data(self) -> SymData:
        return self.model.sym_data

    @property
    def configuration(self) -> ModelConfiguration:
        return self.model.configuration

    @property
    def equations_map(self) -> dict:
        """
        This is a public property to assist with unit testing.
        """
        return self._equations_map
        
    def get_vector_by_name(self, vector_name) -> np.ndarray:
        """
        Use the name of the vector to retrieve its numpy array value.
        These values have been set using the linearisation database.
        """
        if not hasattr(self, "_{}".format(vector_name)):
            raise Exception("There is no vector for {}".format(vector_name))
        return getattr(self, "_{}".format(vector_name))

    def get_base_lhs_vector_by_name(self, lhs_vector_name:str) -> np.ndarray:
        """
        This function is useful for benchmarking the model equation evaluations.

        Use the name of the vector to retrieve its numpy array value.
        These values have been set by evaluating the model's non-linear equations
        using the RHS vector values for the base year chosen for the linearisation.
        """
        if not lhs_vector_name in self._base_lhs_vectors:
            raise Exception(f"The requested vector, {lhs_vector_name}, is not a LHS vector in the model.")
        return self._base_lhs_vectors[lhs_vector_name]

    def get_partials(self, lhs_vector_name:str, rhs_vector_name:str) -> np.ndarray:
        """
        Use the name of the LHS vector and the RHS vector to retrieve 
        the numpy matrix value for the partial derivatives.
        
        The matrices of partial derivatives are stored in a dictionary indexed
        by the lhs and rhs vector names.
        """
        if self._partial_derivatives is None:
            raise Exception(f"Attempted to access partial derivatives {lhs_vector_name} on {rhs_vector_name} before it was created.")
        key = (lhs_vector_name, rhs_vector_name)
        if key in self._partial_derivatives:
            return self._partial_derivatives[key]
        return None

    def get_partials_as_dataframe(self, lhs_vector_name, rhs_vector_name) -> pd.DataFrame:
        """
        Return the required partial derivatives with row and column labels that are variable names.
        """
        if self._partial_derivatives is None:
            raise Exception(
                f"Attempted to access partial derivatives {lhs_vector_name} on {rhs_vector_name} before it was created.")
        key = (lhs_vector_name, rhs_vector_name)
        if key in self._partial_derivatives:
            result: pd.DataFrame = pd.DataFrame(self._partial_derivatives[key])
            result.index = self.sym_data.vector_variable_names(vector_name=lhs_vector_name)
            result.columns = self.sym_data.vector_variable_names(vector_name=rhs_vector_name)
            return result
        return None

    def __configure_lhs_vectors(self):
        """
        Create the LHS vectors that are used by the model equations.
        Initialise LHS vectors with zeros.
        """
        for vector_name in self.sym_data.lhs_vector_names:
            setattr(self, "_{}".format(vector_name), np.zeros(
                shape=(self.sym_data.vector_length(vector_name=vector_name), 1), dtype=float))

    def __load_rhs_vectors(self, linearisation_year: int):
        """
        Create and set values for the RHS vectors that are used by the 
        model equations.

        Do not create vectors if they have no variables (are zero length).

        Arguments:

        linearisation_year: The year in which the model is linearised.
        e.g. 2011 implies linearise model equations around the values
        of the model variables in 2011 (or in adjacent years for leads/lags).
        
        """
        assert self.linearisation_database is not None

        # Initialise RHS vectors with database values from the linearisation base year or the lead/lag from that year.
        for vector_name in self.sym_data.rhs_vector_names:
            rhs_vector:pd.DataFrame = self.linearisation_database.rhs_vector_value(vector_name=vector_name, year=linearisation_year, use_neutral_real_interest_rate=True)
            if rhs_vector is not None:
                setattr(self, f"_{vector_name}", rhs_vector)

    def __compute_benchmark_equation_results(self):
        """
        Compute the benchmark LHS vector values using supplied RHS values.
        These are used in computing the non-linear equations in the model.
        """
        self._base_lhs_vectors: dict[str, np.ndarray] = dict()
        for lhs_vector_name in self.sym_data.lhs_vector_names:
            lhs_vector = getattr(self, "_{}".format(lhs_vector_name))
            for lhs_index in range(len(lhs_vector)):
                function_name = "{}_{}".format(lhs_vector_name, lhs_index)
                if hasattr(self.equations, function_name):
                    func = getattr(self.equations, function_name)
                    func()
                else:
                    # TODO: Reinstate this warning when we are done to ensure SYM models do not collect obsolete variables.
                    # logging.warning("No {} equation for element {}".format(lhs_vector_name, lhs_index))
                    pass
            self._base_lhs_vectors[lhs_vector_name] = lhs_vector.copy()

    def __load_equation_map(self):
        """
        Uses the eqnmap output from the sym processor to create a map from each
        RHS variable (vector + index combination) to the equations that include
        that variable on the RHS.

        This map ensures we only have to evaluate the relevant equations when computing
        the partial derivatives of the model equations when considering each RHS variable.
        """

        self._equations_map: dict[tuple[str, int], list[tuple[str, int]]] = dict()
        """
        This is a map from RHS variable identifiers to LHS equation identifiers.
        Each RHS and LHS identifier is a tuple: a string, identifying the vector
        name (eg: x1l or zer) and an integer, identifying the string index.
        """

        rows: pd.DataFrame = pd.read_csv(self.configuration.eqnmap_file, header=None)
        rows.columns = ['name', 'number']
        # Remove 'par' RHS entries - they are not needed.
        rows = rows.loc[~(rows.name == 'par'), :]

        lhs: tuple[str, int] = None
        rhs: tuple[str, int] = None

        equationCount = 0
        for row in rows.itertuples(index=False):
            if row[0].endswith('l'):
                equationCount = equationCount + 1
                lhs = (row[0], int(row[1]))
                rhs = None
                continue
            else:
                rhs = (row[0], int(row[1]))

            if rhs is None:
                continue

            if rhs in self._equations_map:
                self._equations_map[rhs].append(lhs)
            else:
                self._equations_map[rhs] = [lhs]

    def compute_partial_derivatives(self):
        """
        Generate the matrices that reflect the linear approximation
        to the model. The model is linearised around the data for 
        a specific year that is specified in the model configuration.

        Do not compute partial derivatives for any vectors with zero length.
        """

        # Create the dictionary where the partial derivative matrices will be stored.
        self._partial_derivatives: dict[tuple[str, str], np.ndarray] = dict()

        # Initialise the matrices of partial derivatives

        for lhs in self.sym_data.lhs_vector_names:
            lhs_length = self.sym_data.vector_length(vector_name=lhs)
            if lhs_length == 0:
                continue
            for rhs in self.sym_data.rhs_vector_names:
                rhs_length = self.sym_data.vector_length(vector_name=rhs)
                if rhs_length == 0:
                    continue
                self._partial_derivatives[(lhs, rhs)] = np.zeros(shape=(lhs_length, rhs_length), dtype=float)

        for rhs in self.sym_data.rhs_vector_names:
            rhs_length = self.sym_data.vector_length(vector_name=rhs)
            if rhs_length == 0:
                continue

            # Get the vector of RHS variables in the named rhs vector
            rhs_vector = self.get_vector_by_name(vector_name=rhs)
            
            for rhs_index in range(rhs_length):

                 if (rhs, rhs_index) in self._equations_map:

                    original_value: float = rhs_vector[rhs_index].copy()

                    # Compute the partial by incrementing by delta then restore original value.
                    rhs_vector[rhs_index] = original_value + self.delta

                    # Iterate all equations that use the RHS variable to compute the partial derivatives.
                    for (lhs, lhs_index) in self._equations_map[(rhs, rhs_index)]:

                        # logging.debug(f"Getting partial for {lhs_vector_name}[{lhs_index}] on {rhs_vector_name}[{rhs_index}]")

                        # Run the relevant function to evaluate the model equation at the adjusted
                        # RHS variable value.
                        func = getattr(self.equations, f"{lhs}_{lhs_index}")
                        func()

                        perturbed_value = self.get_vector_by_name(vector_name=lhs)[lhs_index]
                        base_value = self.get_base_lhs_vector_by_name(lhs_vector_name=lhs)[lhs_index]
                        partial_derivative: float = ((perturbed_value - base_value) / self.delta)

                        # Store the value of the derivative in the partial derivatives matrix at the
                        # appropriate row and column index.
                        self.get_partials(lhs_vector_name=lhs, rhs_vector_name=rhs)[lhs_index, rhs_index] = partial_derivative

                    rhs_vector[rhs_index] = original_value

        self._linear_model_is_available = True

    def __generate_nonlinear_equation_differences(self):
        """
        Generate a CSV report of the differences between observed values and 
        non-linear equation solutions used in model linearisation.
        """
        x1_diff: pd.DataFrame = pd.DataFrame(np.hstack((self._x1r,self._x1l, self._x1r - self._x1l)))
        x1_diff.index = self.model.sym_data.vector_variable_names(vector_name='x1l')
        x1_diff.columns = ['rhs', 'lhs', 'rhs_minus_lhs']
        j1_diff: pd.DataFrame = pd.DataFrame(np.hstack((self._j1r, self._j1l, self._j1r - self._j1l)))
        j1_diff.index = self.model.sym_data.vector_variable_names(vector_name='j1l')
        j1_diff.columns = ['rhs', 'lhs', 'rhs_minus_lhs']
        ze_diff: pd.DataFrame = pd.DataFrame(np.hstack((self._zer, self._zer, self._zer - self._zel)))
        ze_diff.index = self.model.sym_data.vector_variable_names(vector_name='zel')
        ze_diff.columns = ['rhs', 'lhs', 'rhs_minus_lhs']
        z1_diff: pd.DataFrame = pd.DataFrame(np.hstack((self._z1r, self._z1l, self._z1r - self._z1l)))
        z1_diff.index = self.model.sym_data.vector_variable_names(vector_name='z1l')
        z1_diff.columns = ['rhs', 'lhs', 'rhs_minus_lhs']
        exo_diff: pd.DataFrame = pd.DataFrame(index=self.model.sym_data.vector_variable_names(vector_name='exo'), columns=['rhs', 'lhs', 'rhs_minus_lhs'])
        exo_diff.loc[:,'rhs'] = self._exo
        exo_diff.loc[:, 'lhs'] = self._exo
        exo_diff.loc[:, 'rhs_minus_lhs'] = 0
        diffs = pd.concat([
            x1_diff,
            j1_diff,
            ze_diff,
            z1_diff,
            exo_diff])
        database_ordered_variable_list: pd.DataFrame = self._database.variables.name
        self._nonlinear_equation_differences = pd.concat([database_ordered_variable_list, diffs], axis=1)
        self._nonlinear_equation_differences.drop('name', inplace=True, axis=1)
        self._nonlinear_equation_differences.insert(loc=0, column='vector', value=self.sym_data.combined_variable_summary.loc[:, 'vector'])
        self._nonlinear_equation_differences = self._nonlinear_equation_differences.loc[self._nonlinear_equation_differences.vector != 'exo', :]

    @property
    def nonlinear_equation_differences(self) -> pd.DataFrame:
        return self._nonlinear_equation_differences

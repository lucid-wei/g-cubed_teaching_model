# ------------------------------------------------------------------
# Purpose: Base class for baseline projections and simulations
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
"""
Contains the base Projections class
"""
import logging
import pandas as pd
import numpy as np
from gcubed.constants import Constants
from gcubed.base import Base
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData
from gcubed.model import Model
from gcubed.model_parameters.parameters import Parameters
from gcubed.linearisation.state_space_form import StateSpaceForm
from gcubed.linearisation.stable_manifold import StableManifold

class Projections(Base):
    """
    Base class for Simulation Projections and for Baseline Projections.
    """

    @classmethod
    def get_differences_between_projections(cls, new_projections:pd.DataFrame, original_projections:pd.DataFrame) -> pd.DataFrame:
        """
       ### Arguments

        new_projections: A dataframe of projections

        original_projections: A second dataframe of projections

        Produce a dataframe of differences between two projections (new_projections - original_projections).

        Note that this can be used for raw, database, publishable and graphable projection types. However, the new 
        and original projections must be the same type for the results to be meaningful.

        Raises exceptions if the dataframes have different indexes or different columns.
        """

        if not new_projections.index.equals(original_projections.index):
            raise Exception("The two sets of projections are not for identical lists of variables. Make sure they are both for the same model.")
        if not new_projections.columns.equals(original_projections.columns):
            raise Exception("The two sets of projections are not for identical years so differences between them cannot be calculated.")
        
        return (new_projections - original_projections)

    def __init__(self, stable_manifold: StableManifold) -> None:

        # Update this to False for non-baseline projections subclasses.
        self._is_baseline_projections = True

        assert stable_manifold is not None
        assert stable_manifold.converged
        self._stable_manifold = stable_manifold
        self._first_projection_year = self.configuration.first_projection_year # can be overridden by subclasses.
        self.__validate()

    def __validate(self):
        """
        TODO:  Validate the projections: 
        1. check that they are available for the expected projection years.
        2. Check that the base year projections are equal to the base year data values.
        """
        pass

    @property
    def is_baseline_projections(self) -> bool:
        """
        True if the projections are baseline projections and False otherwise.

        This setting is used to determine whether constant adjustments to 
        long interest rates (nominal and real bond rates) are calculated to
        ensure first projection year long interest rates match the observed
        data for that year.
        """
        return self._is_baseline_projections

    @property
    def stable_manifold(self) -> StableManifold:
        """
        The stable manifold used for projecting the model.
        """
        return self._stable_manifold

    @property
    def state_space_form(self) -> StateSpaceForm:
        """
        The state-space form of the linearised model.
        """
        return self.stable_manifold.ssf

    @property
    def model(self) -> Model:
        """
        The model being used to generate the projections.
        """
        return self.stable_manifold.model

    @property
    def sym_data(self) -> SymData:
        """
        The SYM processor data generated from the SYM model definition.
        """
        return self.model.sym_data

    @property
    def parameters(self) -> Parameters:
        """
        The calibrated parameters of the model.
        """
        return self.model.parameters

    @property
    def configuration(self) -> ModelConfiguration:
        """
        The model configuration.
        """
        return self.model.configuration

    @property
    def first_projection_year(self) -> int:
        """
        The first projection year for this projection.
        """
        return self._first_projection_year

    @property
    def last_projection_year(self) -> int:
        """
        The last year of projections
        """
        return self.configuration.last_projection_year

    @property
    def projection_years(self) -> list[int]:
        """
        Returns the list of years for projections from the event year through to 
        and including the projection end year.
        """
        return range(self.first_projection_year, self.last_projection_year+1)

    @property
    def projection_years_count(self) -> list[int]:
        return (self.last_projection_year - self.first_projection_year + 1)

    @property
    def projection_years_column_labels(self) -> list[str]:
        """
        Returns the ordered list of 4 digit (YYYY) year 
        column labels for the projections.
        """
        return [str(x) for x in self.projection_years]

    @property
    def projections(self) -> pd.DataFrame:
        """
        Returns the dataframe of projections for all variables in the model that are part of the 
        4 vectors specified. There still need to be additional variable projected that are computed
        outside of the system to take non-linearity into account (eg long-term interest rates.)
        """
        if hasattr(self, '_projections'):
            return self._projections
        raise Exception(f"The projections for all variables are not yet available.")

    @property
    def database_projections(self) -> pd.DataFrame:
        """
        Returns the dataframe of projections for all variables in the model in forms that are consistent with
        the values contained in the original model database.
        """
        if hasattr(self, '_database_projections'):
            return self._database_projections
        raise Exception(f"The database projections for all variables are not yet available.")

    @property
    def publishable_projections(self) -> pd.DataFrame:
        """
        Returns the dataframe of projections for all variables in the model.
        """
        if hasattr(self, '_publishable_projections'):
            return self._publishable_projections
        raise Exception(f"The publishable projections for all variables are not yet available.")

    @property
    def yxr_initial_values(self) -> pd.DataFrame:
        """
        Get yxr initial values to start the projections process.
        """
        if hasattr(self, '_yxr_initial_values'):
            return self._yxr_initial_values
        raise Exception(f"The initial values for the period t state variable projections (yxr) are not yet available.")


    @property
    def yxr_projections_as_dataframe(self) -> pd.DataFrame:
        """
        Get yxr variable projection values
        of the projection years as a dataframe.
        """
        if hasattr(self, '_yxr_projections'):
            return self._yxr_projections
        raise Exception(f"The period t state variable projections (yxr) are not yet available.")

    @property
    def yxr_projections(self) -> np.ndarray:
        """
        Get yxr variable projection values
        of the projection years.
        """
        if hasattr(self, '_yxr_projections'):
            return self._yxr_projections.to_numpy()
        raise Exception(f"The period t state variable projections are not yet available.")

    @property
    def yjr_projections_as_dataframe(self) -> pd.DataFrame:
        """
        Get yjr variable projection values
        of the projection years as a dataframe.
        """
        if hasattr(self, '_yjr_projections'):
            return self._yjr_projections
        raise Exception(f"The period t costate variable projections (yjr) are not yet available.")

    @property
    def yjr_projections(self) -> np.ndarray:
        """
        Get yjr variable projection values
        of the projection years.
        """
        if hasattr(self, '_yjr_projections'):
            return self._yjr_projections.to_numpy()
        raise Exception(f"The period t costate variable projections (yjr) are not yet available.")

    @property
    def exz_projections_as_dataframe(self) -> pd.DataFrame:
        """
        Get exz variable projection values
        of the projection years as a dataframe.
        """
        if hasattr(self, '_exz_projections'):
            return self._exz_projections
        raise Exception(f"The period t expected values for t+1 variables projections (exz) are not yet available.")

    @property
    def exz_projections(self) -> np.ndarray:
        """
        Get exz variable projection values
        of the projection years.
        """
        if hasattr(self, '_exz_projections'):
            return self._exz_projections.to_numpy()
        raise Exception(f"The period t expected values for t+1 variables projections (exz) are not yet available.")

    @property
    def zel_projections_as_dataframe(self) -> pd.DataFrame:
        """
        Get zel variable projection values
        of the projection years as a dataframe.
        """
        if hasattr(self, '_zel_projections'):
            return self._zel_projections
        raise Exception(f"The period t ZEL projections are not yet available.")

    @property
    def zel_projections(self) -> np.ndarray:
        """
        Get zel variable projection values
        of the projection years.
        """
        if hasattr(self, '_zel_projections'):
            return self._zel_projections.to_numpy()
        raise Exception(f"The period t ZEL projections are not yet available.")

    @property
    def z1l_projections_as_dataframe(self) -> pd.DataFrame:
        """
        Get z1l variable projection values
        of the projection years as a dataframe.
        """
        if hasattr(self, '_z1l_projections'):
            return self._z1l_projections
        raise Exception(f"The period t Z1L projections are not yet available.")

    @property
    def z1l_projections(self) -> np.ndarray:
        """
        Get z1l variable projection values
        of the projection years.
        """
        if hasattr(self, '_z1l_projections'):
            return self._z1l_projections.to_numpy()
        raise Exception(f"The period t Z1L projections are not yet available.")

    @property
    def exo_projections_as_dataframe(self) -> pd.DataFrame:
        """
        Get exogenous variable projection values
        of the projection years as a dataframe.
        """
        if hasattr(self, '_exo_projections'):
            return self._exo_projections
        raise Exception(f"The exogenous variable projections are not yet available.")

    @property
    def exo_projections(self) -> np.ndarray:
        """
        Get exogenous variable projection values
        of the projection years.
        """
        if hasattr(self, '_exo_projections'):
            return self._exo_projections.to_numpy()
        raise Exception(f"The exogenous variable projections are not yet available.")

    def _longrate_calculation(self, term: int, rates: pd.DataFrame) -> pd.DataFrame:
        """
        Utility method that returns the compounding long rates given the yearly rates.

        Rates are provided as decimal values so 1% is 0.01.
 
       ### Arguments

        term: the number of years of the term of the instrument. 2 for a 2 year bond.

        rates: the projections of the 1 year interest rates, (nominal or real).

        Returns the long rates that can be computed from the one year rates. This series is shorter
        than the series of one year rates because the required data is not available for 
        the last (term-1) observations. It is padded with NaN values in the returned projection.
        """
        shortrates = rates.copy()
        name_suffix = str(shortrates.index[0]).split('(')[1]
        longrates_columns = shortrates.iloc[:, 0:(len(shortrates.columns)-term+1)].columns
        preceding_year: int = int(shortrates.columns[0])-1
        shortrates = shortrates + 1

        shortrates = shortrates.cumprod(axis='columns')
        shortrates.insert(0, str(preceding_year), 1.0)

        longrates: pd.DataFrame = pd.DataFrame(np.power(shortrates.iloc[:, term:].to_numpy() / shortrates.iloc[:, 0:-term:1].to_numpy(), 1/term) - 1.0)
        longrates.columns = longrates_columns
        match str(rates.index[0]).split('(')[0]:
            case 'INTN':
                match term:
                    case 2:
                        long_rate_name = 'NB02'
                    case 5:
                        long_rate_name = 'NB05'
                    case 10:
                        long_rate_name = 'NB10'
                    case _:
                        raise Exception(f"Invalid nominal bond term specified: {term}")
            case "INTR":
                match term:
                    case 2:
                        long_rate_name = 'RB02'
                    case 5:
                        long_rate_name = 'RB05'
                    case 10:
                        long_rate_name = 'RB10'
                    case _:
                        raise Exception(f"Invalid real bond term specified: {term}")
            case _:
                raise Exception(f"Invalid variable used to compute bond rates: {str(rates.index[0])}. Use a 1 year interest rate.")
        longrates.index = [ f"{long_rate_name}({name_suffix}" ]
        return longrates.astype(float)

    @property
    def long_rate_constants(self):
        """
        The constant adjustments to long bond rates 
        (real and nominal) in the base projection year 
        to ensure projections equal observed values.
        """
        return self._long_rate_constants

    def _compute_functions_of_future_exogenous_variables(self):
        """
        The rules governing the dynamic behaviour of variables depend on functions of the current and future exogenous variables.
        These functions are evaluated and the results are stored in numpy matrices that match the number of rows
        for the related vector of variables and that have a column for each year from the base projection year to the
        last year in the projections.
        """

        # Set up the arrays that will be populated and initialise them to zeros.

        # // setup for baseline with optimization
        # decl id=invert(unit(nez)-c4n);
        # c4t=id*cz5;

        # decl mu2t=id*c6n;

        # id=invert(unit(njm)-ff-we*mu2t);
        # c6t=id*(cz4+we*c4t);

        # c4t=c4t+mu2t*c6t;
        # c4t=ones(rows(c4t),nobs).*c4t;
        # c6t=ones(rows(c6t),nobs).*c6t;
        # c2t=h2t*exog+c6t+bt2t*gam3t;

        # This is equivalent to h3t in the newsetsymbl.ox script (j by 1 dimensions)
        h3t: np.ndarray = np.zeros(shape=(self.sym_data.vector_length(vector_name='j1l'), self.projection_years_count))

        # Populate for period T.

    	# c4t=invert(unit(nez)-zel_exz_ssf)*cz5   (r by 1 dimensions)
        interim_calculation = self.stable_manifold.Gamma_rT @ self.ze_constants

        # c6t = invert(unit(j)-j1l_yjr_ssf-j1l_exz_ssf*mu2t) * (cz4+j1l_exz_ssf*c4t)
        #     = Gamma_jT (cz4+j1l_exz_ssf*interim_calculation)
        c6T_column = self.stable_manifold.Gamma_jT @ (self.j1_constants + self.state_space_form.delta('j1l', 'exz') @ interim_calculation)

    	# c4t = c4t + mu2t * c6t (r by 1 dimensions)
        c4T_column = interim_calculation + self.stable_manifold.psi_rj @ c6T_column

        # c4t=ones(rows(c4t),nobs).*c4t (r by T dimensions)
        c4t: np.ndarray = np.tile(c4T_column, (1, self.projection_years_count))

        # c6t=ones(rows(c6t),nobs).*c6t (j by T dimensions)
        c6t: np.ndarray = np.tile(c6T_column, (1, self.projection_years_count))

        # c2t=h2t*exog+c6t    (j by T dimensions)
        c2t: np.ndarray = self.stable_manifold.H2 @ self.exo_projections + c6t

        # (s by T dimensions)
        c5t: np.ndarray = np.zeros(shape=(self.sym_data.vector_length(vector_name='x1l'), self.projection_years_count))

        # (j by T dimensions)
        c2t_lead: np.ndarray = c2t.copy()
        c4t_lead: np.ndarray = c4t.copy()

        # Populate for earlier periods.
        j = self.projection_years_count-1
        for k in range(self.projection_years_count-1, -1, -1):

            # c5t[][k] = wvi*(x1l_exz_ssf*c4tl[][j] + cz2)          (s by 1 : note no need for T columns)
            c5t: np.ndarray = self.stable_manifold.Gamma_st @ (self.state_space_form.delta('x1l', 'exz') @ c4t_lead[:, [j]] + self.x1_constants)

            # c6t[][k] = fdeltinv*(th6t*c5t[][k] - j1l_exz_ssf*c4tl[][j] + c2tl[][j] - cz4)         (j rows)
            c6t[:, [k]] = self.stable_manifold.Gamma_jt @ (self.stable_manifold.common_factor @ c5t - self.state_space_form.delta(
                'j1l', 'exz') @ c4t_lead[:, [j]] + c2t_lead[:, [j]] - self.j1_constants)

            # c5t[][k] = c5t[][k] + th2t*c6t[][k]
            c5t = c5t + self.stable_manifold.tau_sjt @ c6t[:, [k]]

            # c4t[][k] = mu1tl*c5t[][k] + c4tl[][j]
            c4t[:, [k]] = self.stable_manifold.M1_lead @ c5t + c4t_lead[:, [j]]

            # h3t[][k] = c6t[][k]
            h3t[:, [k]] = c6t[:, [k]].copy()

            # c2t[][k] = h2t*exog[][k] + h3t[][k]
            c2t[:, [k]] = self.stable_manifold.H2 @ self.exo_projections[:, [k]] + h3t[:, [k]]

            # c4tl[][k] = nmu4t*exog[][k] + zel_yjr_ssf*h3t[][k] + zel_exz_ssf*c4t[][k] + cz5
            c4t_lead[:, [k]] = self.stable_manifold.M2 @ self.exo_projections[:, [k]] + \
                self.state_space_form.delta('zel', 'yjr') @ h3t[:, [k]] + \
                self.state_space_form.delta('zel', 'exz') @ c4t[:, [k]] + \
                self.ze_constants

            c2t_lead = c2t.copy()

            j = k

        # Store the functions of future exogenous variables to access when doing projections.
        self._h3t = h3t.copy()
        self._c4t = c4t.copy()

    @property
    def h3t(self) -> np.ndarray:
        """
        Equivalent to h3t in the Ox implementation
        
        Returns constants and the functions of current and future exogenous variables affecting J1.
        """
        return self._h3t

    @property
    def c4t(self) -> np.ndarray:
        """
        Equivalent to c4t in the Ox implementation
        
        Returns constants and the functions of current and future exogenous variables affecting ZE.
        """
        return self._c4t

    def _generate_projections(self):
        """
        Implements the projection logic in msgsimBL.ox. This runs the various equations
        to project variables based on the starting state vector and the values of
        exogenous variables in all years. The steps are as follows:

        Step 1.
        Recalculate the functions of future exogenous variables, incorporating 
        the updated exogenous variable projections and all constant adjustments: 
        the intertemporal constants and the other constants  capturing the difference 
        between the SSF equation results in the base year and the observed 
        values in the base year.
        
        Step 2.
        Project the state vector. (x_t+1 as a function of x_t and exogenous variables and constant adjustments)
        This uses the Anew and Znew matrices computed as part of getting the stable manifold.

        Step 3. 
        Combine all variable projections into a single data frame.

        Step 4.
        Sort the variables in the projection dataframe into the same order as the original database.
        """

        # Step 1.
        self._compute_functions_of_future_exogenous_variables()

        # Step 2.
        self._constantBL: pd.DataFrame = pd.DataFrame(
            self.stable_manifold.Znew @ self.exo_projections +
            self.state_space_form.delta('x1l', 'yjr') @ self.h3t +
            self.state_space_form.delta('x1l', 'exz') @ self.c4t +
            self.x1_constants)
        self._constantBL.columns = self.projection_years_column_labels
        self._constantBL.index = self.sym_data.vector_variable_names(vector_name='yxr')
        yxr: pd.DataFrame = pd.DataFrame(index=self.sym_data.vector_variable_names(vector_name='yxr'), columns=self.projection_years_column_labels)
        yxr.loc[:, [str(self.first_projection_year)]] = self.yxr_initial_values
        previous_year_label = str(self.first_projection_year)
        assert previous_year_label == yxr.columns[0]
        for year in yxr.columns[1:]: # omit the first year - it should be the previous year label.
            yxr.loc[:, [year]] = self.stable_manifold.Anew @ yxr.loc[:, [previous_year_label]].to_numpy() + self.constantBL.loc[:, [previous_year_label]].to_numpy()
            previous_year_label = year

        # Project J1
        # er = h1t*x + h2t*exog[][1:nobs] + h3t
        yjr: pd.DataFrame = pd.DataFrame(self.stable_manifold.H1 @ (yxr.to_numpy()) + self.stable_manifold.H2 @ self.exo_projections + self._h3t)
        yjr.columns = self.projection_years_column_labels
        yjr.index = self.sym_data.vector_variable_names(vector_name='j1l')
        self._yjr_projections = yjr

        # Project time t expected value of ZE in period t+1 (EXZ)
        # Project time t expected value of ZE in period t+1 (EXZ)
        # tzl = mu1t*x + mu4t*exog[][1:nobs] + c4t
        exz: pd.DataFrame = pd.DataFrame(
            self.stable_manifold.mu1 @ yxr.to_numpy() +
            self.stable_manifold.mu2 @ self.exo_projections +
            self._c4t
        )
        exz.columns = self.projection_years_column_labels
        exz.index = self.sym_data.vector_variable_names(vector_name='zer')
        self._exz_projections = exz

        # Project time t values of ZE using the SSF equation (this should be done with M1 and M2?)
        # What about the functions of future exogenous variables and the constant adjustments
        zel: pd.DataFrame = pd.DataFrame(
            self.state_space_form.delta('zel', 'yxr') @ yxr +
            self.state_space_form.delta('zel', 'exz') @ exz +
            self.state_space_form.delta('zel', 'yjr') @ yjr +
            self.state_space_form.delta('zel', 'exo') @ self.exo_projections)
        zel.columns = self.projection_years_column_labels
        zel.index = self.sym_data.vector_variable_names(vector_name='zel')
        self._zel_projections = zel + self.ze_constants

        # Project Z1 using the SSF equation
        z1l: pd.DataFrame = pd.DataFrame(
            self.state_space_form.delta('z1l', 'yxr') @ yxr +
            self.state_space_form.delta('z1l', 'exz') @ exz +
            self.state_space_form.delta('z1l', 'yjr') @ yjr +
            self.state_space_form.delta('z1l', 'exo') @ self.exo_projections)
        z1l.columns = self.projection_years_column_labels
        z1l.index = self.sym_data.vector_variable_names(vector_name='z1l')
        self._z1l_projections = z1l + self.z1_constants

        # timeshift forward the special state variables by 1 period.
        for variable_name_prefix in Constants().STATE_LEAD_VARIABLES:
            matching_variables = yxr.index.str.startswith(variable_name_prefix)
            yxr.iloc[matching_variables, 0:-2] = yxr.iloc[matching_variables, 1:-1]
            yxr.iloc[matching_variables, -1] = 0  # TODO: Once we are past benchmarking against Ox, set this equal to NaN.

        self._yxr_projections = yxr

        # Combine the projections into a single dataframe in the same order as the database
        self._projections = pd.concat([
            self.yxr_projections_as_dataframe,
            self.z1l_projections_as_dataframe,
            self.zel_projections_as_dataframe,
            self.yjr_projections_as_dataframe,
            self.exo_projections_as_dataframe])
        database_ordered_variable_list: pd.DataFrame = self.database.variables.name
        self._projections = pd.concat([database_ordered_variable_list, self._projections], axis=1)
        self._projections.drop('name', inplace=True, axis=1)

        self._projections = self._projections.astype(float)

    @property
    def constantBL(self) -> pd.DataFrame:
        return self._constantBL

    def _generate_database_projections(self):
        """
        Converts the raw projections into projections that are consistent with the database being used
        by the model. These projections can be spliced on to the original database (as opposed to the
        GDP scaled database) that was loaded with the model used to produce the projections.

        Implements the first parts of the projection conversion logic in datamsymbl.ox.

        Step 1.
        Get a copy of the raw projections.

        Step 2b.
        Divide the projections by YRATR in the projection base year for every variable that has units of:
            gdp
            mmtgdp
            btugdp
            gwhgdp
        This ensures that the resulting values are comparable to the original database aside from scaling by 100.
        for mmtgdp, in models from version 170 onwards, multiply mmtgdp by 100 also because of a change in the 
        definition of the units.

        # Step 3.
        At this stage the interest rates are expressed as decimals so 0.02 is a 2% interest rate.
        Adjust the interest rate variables using the intcons adjustment, adding the difference between 
        the base-projection year interest rate and the assumed neutral real interest rate to each of the interest 
        rate variables.
        This ensures that the result short interest rates are comparable to the original database, aside from scaling by 100.

        # Step 4.
        Generate long rates from short rates
        This ensures that the long interest rates are derived from the short rates.
         
        # Step 5.
        Adjust long rate projections by adding long rate constants that
        are calculated to ensure that the long rates are equal to the 
        observed values in the base projection year.
        This ensures that the long interest rates are comparable to the original database aside from scaling by 100.

        Step 6.
        Get LGDPR (real GDP level) data in the projection base year for each 
        region and grow over projection years at rate given by 'labgrow' parameter.
        Store the LGDPR projections in the publishable projections dataset.

        Step 7.
        Multiply projection values by 100
        This ensures that the projections are scaled in the same way as the original database.


        Saves the result in the _database_projections property.

        These database projections should be associated with the publication_units of measurement
        available from the sym_data variable summary.
        """

        # Step 1.
        database_projections: pd.DataFrame = self.projections.copy() 

        # Step 2.
        yratr_data: pd.DataFrame = self.database.get_data(name_regular_expression=f"^{Constants().US_REAL_GDP_RATIO_PREFIX}\(", years=[self.configuration.original_first_projection_year])
        yratr_data.index = self.sym_data.regions_members
        for variable_name, variable_projection in database_projections.iterrows():
            units: str = str(self.database.variables.loc[variable_name,'units'])
            match units:
                case 'gdp' | 'btugdp' | 'gwhgdp':
                    variable_region: str = str(self.database.variables.loc[variable_name, 'region'])
                    factor: float = float(yratr_data.loc[variable_region].values[0])
                    database_projections.loc[[variable_name], :] /= factor
                case 'mmtgdp':
                    variable_region: str = str(self.database.variables.loc[variable_name, 'region'])
                    factor: float = float(yratr_data.loc[variable_region].values[0])
                    # Warwick changed the definition of mmt by a scale factor of 100 
                    # for all models from # 169 onwards.
                    if self.configuration.build_number >= 169:
                        database_projections.loc[[variable_name], :] /= factor / 100
                    else:
                        database_projections.loc[[variable_name], :] /= factor / 100

        # Step 3.
        # Make the adjustment to convert back to actual interest rates from the neutral real interest rate.
        for prefix in Constants().INTEREST_RATE_PREFIXES:
            variable_names = self.database.variables.loc[self.database.variables.name.str.startswith(f"{prefix}("), 'name']
            for variable_name in variable_names:
                database_projections.loc[[variable_name], :] += (float(self.database.data.loc[variable_name, str(self.configuration.original_first_projection_year)] - self.configuration.neutral_real_interest_rate))

        # Step 4.
        # Calculate the long rates.
        real_interest_rates: pd.DataFrame = database_projections.loc[database_projections.index.str.startswith(f"{Constants().REAL_INTEREST_RATE_PREFIX}("), str(self.first_projection_year):].copy()
        for variable_name in real_interest_rates.index:
            rb10: pd.DataFrame = self._longrate_calculation(term=10, rates=real_interest_rates.loc[[variable_name], :])
            database_projections.loc[[str(rb10.index[0])], :] = rb10
        nominal_interest_rates: pd.DataFrame = database_projections.loc[database_projections.index.str.startswith(f"{Constants().NOMINAL_INTEREST_RATE_PREFIX}("), str(self.first_projection_year):].copy()
        for variable_name in nominal_interest_rates.index:
            nb02: pd.DataFrame = self._longrate_calculation(term=2, rates=nominal_interest_rates.loc[[variable_name], :])
            database_projections.loc[[str(nb02.index[0])], :] = nb02
            nb05: pd.DataFrame = self._longrate_calculation(term=5, rates=nominal_interest_rates.loc[[variable_name], :])
            database_projections.loc[[str(nb05.index[0])], :] = nb05
            nb10: pd.DataFrame = self._longrate_calculation(term=10, rates=nominal_interest_rates.loc[[variable_name], :])
            database_projections.loc[[str(nb10.index[0])], :] = nb10

        # Step 5.
        # Only if doing baseline projections:
        # Determine the constants to add to the long rates to match 
        # the original base projection year observed and projected values.
        if (self.is_baseline_projections):
            self._long_rate_constants: pd.DataFrame = None
            for prefix in Constants().BOND_RATE_PREFIXES:
                observed_values: pd.DataFrame = self.database.data.loc[self.database.variables.name.str.startswith(f"{prefix}("), [str(self.first_projection_year)]].copy()
                projected_values: pd.DataFrame = database_projections.loc[database_projections.index.str.startswith(f"{prefix}("), [str(self.first_projection_year)]].copy()
                constants: pd.DataFrame = observed_values - projected_values
                constants.columns = [str(self.first_projection_year)]
                constants.index = observed_values.index
                if self._long_rate_constants is None:
                    self._long_rate_constants = constants
                else:
                    self._long_rate_constants = pd.concat([self._long_rate_constants, constants], axis=0)

        # For all projections, baseline and otherwise:
        # Add the baseline projection long-rate constants to the long rate projections 
        # to line the long rate projections up with observed data in the base projection year.
        for variable_name in self.long_rate_constants.index:
            database_projections.loc[[variable_name], :] += self.long_rate_constants.loc[variable_name, str(self.configuration.original_first_projection_year)]

        # Step 6.
        rows_containing_LGDPR_data = self.database.variables.name.str.startswith(f"{Constants().REAL_GDP_PREFIX}(")
        lgdpr_data: pd.DataFrame = self.database.data.loc[rows_containing_LGDPR_data, [str(self.configuration.original_first_projection_year)]]
        us_longrun_effective_labour_productivity_index: pd.DataFrame = self.model.effective_labour_productivity.us_longrun_effective_labour_index.loc[:,self.projection_years_column_labels]
        lgdpr_longrun_projections: pd.DataFrame = pd.DataFrame(lgdpr_data.values * us_longrun_effective_labour_productivity_index.values)
        lgdpr_longrun_projections.columns = self.projection_years_column_labels
        lgdpr_longrun_projections.index = lgdpr_data.index # Index with the LGDPR full variable names
        database_projections.loc[rows_containing_LGDPR_data, :] = lgdpr_longrun_projections

        # Step 7.
        database_projections *= 100.0

        # Splice on the actual data from the model database
        for column in self.model.database.data.columns[::-1]:
            if not (column in database_projections.columns):
                if int(column) < int(database_projections.columns[0]):
                    database_projections.insert(0, column, self.model.database.data.loc[:,column], True)
                else:
                    break

        # Save the results for use later.
        self._database_projections = database_projections.astype(float)

    def _generate_publishable_projections(self):
        """

        Uses the real GDP trend growth projections to adjust 
        the projections of all variables with units equal to 
        'usgdp' or 'gdp'.

        Implements the real GDP scaling part of the projection conversion logic in datamsymbl.ox.

        Step 1.
        For all projections with units equal to usgdp, multiply the projection 
        by the US LGDPR projection computed in step 4 when producing the database projections.

        Step 2.
        For all projections with units equal to 'gdp', multiply the projection by the associated
        region's LGDPR projection computed in step 4 when producing the database projections.

        These publishable projections should be associated with the publication_units of measurement
        available from the sym_data variable summary.

        Saves the result in the _publishable_projections property.
        """

        publication_projections: pd.DataFrame = self.database_projections.copy()

        # Real GDP scaling

        # Get the LGDPR projections. 
        # There will be one row per region.
        lgdpr_database_projections: pd.DataFrame = self.database_projections.loc[self.database_projections.index.str.startswith(f"{Constants().REAL_GDP_PREFIX}("), :]
        lgdpr_database_projections.index = self.model.sym_data.regions_members
        for variable_name in publication_projections.index:
            variable_units: str = str(self.database.variables.loc[variable_name,'units'])
            match variable_units:
                case 'usgdp' | 'mmtusgdp' | 'btuusgdp':
                    publication_projections.loc[[variable_name], :] *= lgdpr_database_projections.loc[[Constants().USA_REGION_CODE],:].values / 100
                case 'gdp' | 'mmtgdp' | 'btugdp' | 'gwhgdp':
                    variable_region: str = str(self.database.variables.loc[variable_name, 'region'])
                    publication_projections.loc[[variable_name], :] *= lgdpr_database_projections.loc[[variable_region],:].values / 100

        # Save the results for use later.
        self._publishable_projections = publication_projections.astype(float)


    @property
    def graphable_projections(self) -> pd.DataFrame:
        """
        Produces publishable projections in a format suitable 
        for loading into graphing systems such as R.

        The publishable projections are transposed so there is 
        a column for each variable and a row for each year.
        """
        result: pd.DataFrame = self.publishable_projections.copy().transpose()
        return result


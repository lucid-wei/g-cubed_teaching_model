# ------------------------------------------------------------------
# Purpose: Compute and provide access to relinearisation projections.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
"""
Contains the RelinearisationProjections class, for doing projections
after relinearising a model, and making adjustments for any simulation layers
that impact on the relinearisation year.
"""
import logging
import os
from gcubed import baseline
import pandas as pd
import numpy as np
from gcubed.constants import Constants
from gcubed.sym_data import SymData
from gcubed.model_parameters.parameters import Parameters
from gcubed.model_configuration import ModelConfiguration
from gcubed.model import Model
from gcubed.linearisation.linear_model import LinearModel
from gcubed.linearisation.stable_manifold import StableManifold
from gcubed.linearisation.state_space_form import StateSpaceForm
from gcubed.data.gdp_scaled_database import GDPScaledDatabase
from gcubed.projections.model_updater import ModelUpdater
from gcubed.projections.projections import Projections
from gcubed.projections.baseline_projections import BaselineProjections
from gcubed.projections.simulation_layer_definitions import SimulationLayerDefinitions
from gcubed.projections.simulation_layer_definition import SimulationLayerDefinition

class RelinearisationProjections(Projections):
    """
    Compute the relinearisation model projections over the projection horizon 
    from the base projection year (the last year with available data)
    through to the last projection year.
    """

    def __init__(self, baseline_projections: BaselineProjections, previous_projections: Projections, relinearisation_year: int, simulation_layer_definitions: SimulationLayerDefinitions = []) -> None:
        """

        ### Constructor

        Creates relinearisation projections for the specified new base year.

        ### Arguments

        baseline_projections: The baseline projections.

        previous_projections: The previous projections.

        relinearisation_year: The year that the relinearisation is being done.

        simulation_layer_definitions: 
        An optional input that provides an ordered list of simulation layer 
        definitions that can be used to augment the initial state vector and 
        the exogenous variable projections that underpin the projections. 
        The simulation layers are ignored if they have an event year that 
        is not equal to the base projection year.
        """

        # Store the baseline projections
        assert baseline_projections is not None
        self._baseline_projections = baseline_projections

        # Store the simulation layer definitions (if any were provided.)
        self._simulation_layer_definitions = simulation_layer_definitions

        # Update the model from the old projections, changing the model configuration's projection base year.
        # and augmenting the database for the model to include values from the old projections for each 
        # of the projection years.
        self._old_projections: Projections = previous_projections if previous_projections is not None else baseline_projections
        new_model: Model = ModelUpdater.get_updated_model(projections=self.previous_projections, new_first_projection_year=relinearisation_year)

        assert new_model.configuration.first_projection_year == relinearisation_year
        assert new_model.configuration.linearisation_year == relinearisation_year

        self._long_rate_constants = self.baseline_projections.long_rate_constants

        # Relinearise the updated model around the new projection base year to get the revised stable manifold.
        linear_model: LinearModel = LinearModel(model=new_model)
        state_space_form: StateSpaceForm = StateSpaceForm(linear_model=linear_model)
        stable_manifold: StableManifold = StableManifold(state_space_form=state_space_form)
        super().__init__(stable_manifold=stable_manifold)
        self._is_baseline_projections = False

        self._database = GDPScaledDatabase(database=new_model.database, base_year=self.configuration.base_year)

        self.populate_exogenous_projections_and_initial_state_vector()

        self._generate_projections()

        self._generate_database_projections()

        self._generate_publishable_projections()

        self.__validate()

    def __validate(self):
        """
        TODO:  Validate the relinearised projections
        """
        logging.info(f"The {self.first_projection_year} relinearised projections have been generated.")
    
    @property
    def stable_manifold(self) -> StableManifold:
        """
        The stable manifold after doing the relinearisation.
        """
        return self._stable_manifold

    @property
    def state_space_form(self) -> StateSpaceForm:
        """
        The state-space form after doing the relinearisation.
        """
        return self.stable_manifold.ssf

    @property
    def model(self) -> Model:
        """
        The model to relinearise.
        """
        return self.state_space_form.model

    @property
    def sym_data(self) -> SymData:
        """
        The SYM generated data about the model.
        """
        return self.model.sym_data

    @property
    def parameters(self) -> Parameters:
        """
        The calibrated model parameters.
        """
        return self.model.parameters

    @property
    def configuration(self) -> ModelConfiguration:
        """
        The model configuration.
        """
        return self.sym_data.configuration

    @property
    def database(self) -> GDPScaledDatabase:
        """
        The database used for the relinearisation and projections.
        """
        return self._database

    @property
    def baseline_projections(self) -> BaselineProjections:
        """
        The baseline projections that this relinearisation projections builds upon.
        """
        return self._baseline_projections
    
    @property
    def previous_projections(self) -> Projections:
        """
        Returns the previous projections.
        """
        return self._old_projections

    @property
    def simulation_layer_definitions(self) -> SimulationLayerDefinitions:
        """
        The list of simulation layer definitions, in their appropriate order
        from the first to be applied to the last to be applied.
        """
        return self._simulation_layer_definitions
    
    @property
    def simulation_variables(self) -> pd.DataFrame:
        """
        The variable summary information for the simulation data.
        """
        return self._simulation_variables

    @property
    def simulation_data(self) -> pd.DataFrame:
        """
        The simulation data.
        """
        return self._simulation_data

    def populate_exogenous_projections_and_initial_state_vector(self):
        """
        Load exogenous variable projections and initial state vector values
        from the previous projections.

        For any simulation layer definition with its event year equal to the base
        year for this projections, augment the exogenous variables and state
        vector with supplied simulation layer data.
        """

        self._exo_projections = self.previous_projections.exo_projections_as_dataframe.loc[:, self.projection_years_column_labels]

        self._yxr_initial_values: pd.DataFrame = self.previous_projections.yxr_projections_as_dataframe.loc[:, [str(self.first_projection_year)]].copy()

        for simulation_layer_definition in self.simulation_layer_definitions:
            self.__apply_simulation_layer(simulation_layer_definition=simulation_layer_definition)

    def __apply_simulation_layer(self, simulation_layer_definition: SimulationLayerDefinition):
        """
        Apply adjustments to exogenous variables and any state variables for the given simulation layer
        """
        if simulation_layer_definition.event_year != self.first_projection_year:
            return

        filename: str = simulation_layer_definition.data_filename
        assert os.path.isfile(filename)
        (self._simulation_variables, self._simulation_data) = self.load_data(filename)
        self._simulation_variables.columns = ['name']
        self._simulation_variables.index = self._simulation_variables.name
        self._simulation_data = self._simulation_data.astype(float)
        self._simulation_data.index = self._simulation_variables.name
        try:
            self._simulation_data = self._simulation_data.loc[:, self.configuration.projection_years_column_labels]
        except:
            raise Exception(f"The simulation data in {self.simulation_file} should have data from {self.first_projection_year} to {self.last_projection_year}")
        yratr: pd.DataFrame = self.baseline_projections.database.get_data(name_regular_expression=f"^{Constants().US_REAL_GDP_RATIO_PREFIX}\(", years=[self.configuration.original_first_projection_year])
        yratr.index = self.sym_data.regions_members

        for variable_name in self._simulation_variables.index:
            variable_region: str = str(self.database.variables.loc[variable_name, 'region'])
            variable_units: str = str(self.sym_data.combined_variable_summary.loc[variable_name, 'units'])
            data: pd.DataFrame = self._simulation_data.loc[[variable_name], :] / 100
            vector_name = self.sym_data.projection_vector_for_variable(variable_name=variable_name)
            yratr_for_region: float = float(yratr.loc[variable_region, :].values[0])
            match variable_units:
                case 'gdp' | 'mmgdp' | 'btugdp' | 'gwhgdp':
                    data *= yratr_for_region
                case _:
                    pass

            match vector_name:
                case 'exo':
                    self._exo_projections.loc[[variable_name], self.projection_years_column_labels] += data
                    pass

                case 'x1l':
                    self._yxr_initial_values.loc[[variable_name], [str(self.first_projection_year)]] += float(data[0])
                    pass

    @property
    def x1_constants(self) -> np.ndarray:
        """
        The constant adjustments to X1 to ensure projections equal observed values
        in the original base projection year.
        """
        return self.baseline_projections.x1_constants

    @property
    def j1_constants(self) -> np.ndarray:
        """
        The constant adjustments to J1 to ensure projections equal observed values
        in the original base projection year.
        """
        return self.baseline_projections.j1_constants

    @property
    def ze_constants(self) -> np.ndarray:
        """
        The constant adjustments to ZE to ensure projections equal observed values
        in the original base projection year.
        """
        return self.baseline_projections.ze_constants

    @property
    def z1_constants(self) -> np.ndarray:
        """
        The constant adjustments to Z1 to ensure projections equal observed values
        in the original base projection year.
        """
        return self.baseline_projections.z1_constants

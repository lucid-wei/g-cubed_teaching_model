# ------------------------------------------------------------------
# Purpose: Base equations class providing boilerplate
# code that is inherited by the SYM processor generated equations 
# class.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
"""
Contains the BaseEquations class
"""

import numpy as np
from gcubed.base import Base


class BaseEquations(Base):

    """

    ### Overview

    Provides GCubed equations class boilerplate.
    
    The Python class created by the SYM processor 
    subclasses this class.
    """

    def __init__(self, 
        x1l: np.ndarray, 
        j1l: np.ndarray, 
        zel: np.ndarray, 
        z1l: np.ndarray, 
        x1r: np.ndarray, 
        j1r: np.ndarray, 
        z1r: np.ndarray, 
        zer: np.ndarray, 
        yjr: np.ndarray, 
        yxr: np.ndarray, 
        exo: np.ndarray, 
        exz: np.ndarray, 
        par: np.ndarray) -> None:
        
        self._X1L = x1l
        self._J1L = j1l
        self._ZEL = zel
        self._Z1L = z1l
        
        self._X1R = x1r
        self._J1R = j1r
        self._Z1R = z1r
        self._ZER = zer
        self._YJR = yjr
        self._YXR = yxr
        self._EXO = exo
        self._EXZ = exz
        self._PAR = par

        self.validate()

    def equation(identifier:tuple[str, int]):
        """
        Return the equation function identified by the identifier.
        This equation function will have a name in the format 'vectorName_index'.
        The equation function will have been declared in the SYM processor output.
        """
        pass

    @property
    def x1l(self) -> np.ndarray:
        return self._X1L

    @property
    def j1l(self) -> np.ndarray:
        return self._J1L

    @property
    def zel(self) -> np.ndarray:
        return self._ZEL

    @property
    def z1l(self) -> np.ndarray:
        return self._Z1L

    @property
    def x1r(self) -> np.ndarray:
        return self._X1R

    @property
    def j1r(self) -> np.ndarray:
        return self._J1R

    @property
    def z1r(self) -> np.ndarray:
        return self._Z1R

    @property
    def zer(self) -> np.ndarray:
        return self._ZER

    @property
    def yjr(self) -> np.ndarray:
        return self._YJR

    @property
    def yxr(self) -> np.ndarray:
        return self._YXR

    @property
    def exo(self) -> np.ndarray:
        return self._EXO

    @property
    def exz(self) -> np.ndarray:
        return self._EXZ

    @property
    def par(self) -> np.ndarray:
        return self._PAR

    def validate(self):
        assert self.x1l is not None
        assert self.j1l is not None
        assert self.zel is not None
        assert self.z1l is not None
        assert self.x1r is not None
        assert self.j1r is not None
        assert self.zer is not None
        assert self.yjr is not None
        assert self.yxr is not None
        assert self.exo is not None
        assert self.exz is not None
        assert self.par is not None

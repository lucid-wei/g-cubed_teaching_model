# ------------------------------------------------------------------
# Purpose: Define a set of global constants.
# Author: Geoff Shuetrim
#
# Most of these constants should be produced by the SYM processor
# from model attributes rather than hard coded into the Python
# implementation of the model.
# ------------------------------------------------------------------
"""
Defines a singleton class the provides access to all constants.
"""
class Constants:

    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super().__new__(cls, *args, **kwargs)
        return cls._instance

    DELTA = 0.00000001
    @property
    def DELTA(self) -> float:
        """
        The delta used to compute numeric derivatives.
        """
        return __class__.DELTA
    
    USA_REGION_CODE: str = "UU"
    @property
    def USA_REGION_CODE(self) -> str:
        """
        The region code for the USA.
        """
        return __class__.USA_REGION_CODE

    # 
    PRID_PREFIX: str = "PRID"
    @property
    def PRID_PREFIX(self) -> str:
        """
        The PRID (weighted price of domestic output) variable prefix.
        """
        return __class__.PRID_PREFIX
        
    WAGE_PREFIX: str = "WAGE"
    @property
    def WAGE_PREFIX(self) -> str:
        """
        The wage variable prefix.
        """
        return __class__.WAGE_PREFIX
    


    NOMINAL_GDP_PREFIX = "LGDPN"
    @property
    def NOMINAL_GDP_PREFIX(self) -> str:
        """
        The nominal GDP variable prefix.
        """
        return __class__.NOMINAL_GDP_PREFIX


    REAL_GDP_PREFIX = "LGDPR"
    @property
    def REAL_GDP_PREFIX(self) -> str:
        """
        The real GDP variable prefix.
        """
        return __class__.REAL_GDP_PREFIX

    US_REAL_GDP_RATIO_PREFIX = "YRATR"
    @property
    def US_REAL_GDP_RATIO_PREFIX(self) -> str:
        """
        The ratio of regional real GDP to USA real GDP variable prefix.
        """
        return __class__.US_REAL_GDP_RATIO_PREFIX

    REAL_INTEREST_RATE_PREFIX = "INTR"
    @property
    def REAL_INTEREST_RATE_PREFIX(self) -> str:
        """
        The real interest rate variable prefix.
        """
        return __class__.REAL_INTEREST_RATE_PREFIX

    NOMINAL_INTEREST_RATE_PREFIX = "INTN"
    @property
    def NOMINAL_INTEREST_RATE_PREFIX(self) -> str:
        """
        The nominal interest rate variable prefix.
        """
        return __class__.NOMINAL_INTEREST_RATE_PREFIX

    INTEREST_RATE_PREFIXES: list[str] = ["INPL", "INPN", "INTF", "INTL", "INTN", "INTR"]
    @property
    def INTEREST_RATE_PREFIXES(self) -> list[str]:
        """
        The interest rate variable prefixes.
        """
        return __class__.INTEREST_RATE_PREFIXES


    BOND_RATE_PREFIXES: list[str] = ["NB02", "NB05", "NB10", "RB10"]
    @property
    def BOND_RATE_PREFIXES(self) -> list[str]:
        """
        The long bond rate (real and nominal) variable prefixes.
        """
        return __class__.BOND_RATE_PREFIXES

    STATE_LEAD_VARIABLES: list[str] = ["INTN", "EXCH", "INPN", "REXB"]
    @property
    def STATE_LEAD_VARIABLES(self) -> list[str]:
        """
        The state vector lead (stl variable types in SYM) variable prefixes.
        """
        return __class__.STATE_LEAD_VARIABLES
    
    # These are used along with wage and prid prefixes to do projections
    JUMPING_VARIABLE_PREFIXES_FOR_REGIONS = ["REXC", "WELH", "LAMY", "LAMZ", "EYGR", "EPRC"]
    @property
    def JUMPING_VARIABLE_PREFIXES_FOR_REGIONS(self) -> list[str]:
        """
        The costate/jumping variable prefixes that have variables for each region.
        """
        return __class__.JUMPING_VARIABLE_PREFIXES_FOR_REGIONS

    JUMPING_VARIABLE_PREFIXES_FOR_REGIONS_AND_SECTORS = ["LAM"]
    @property
    def JUMPING_VARIABLE_PREFIXES_FOR_REGIONS_AND_SECTORS(self) -> list[str]:
        """
        The costate/jumping variable prefixes that have variables for each region and sector.
        """
        return __class__.JUMPING_VARIABLE_PREFIXES_FOR_REGIONS_AND_SECTORS

    # Constants relevant to database rebasing operations.
    LOG_INDEX_PREFIXES = ["PRCT", "PRID", "PRIM", "PRIX", "PRIE", "PRII", "PRKY", "PRKZ",
                        "WAGE", "PGDP", "EXCH", "REXC", "NEER", "PRCE", "PRCO", "REER", 
                        "MONE", "PRGT", "PROI", "PRDX", "PRY", "PRD", 
                        "PIM", "PRE", "POI", "PRK", "PRP", "WAG", "PMR", "PMQ", "PRX"]
    @property
    def LOG_INDEX_PREFIXES(self) -> list[str]:
        """
        The log index prefixes.

        These are used for database rebasing operations.
        """
        return __class__.LOG_INDEX_PREFIXES

    LEAD_LOG_INDEX_PREFIXES = ["EXCL"]
    @property
    def LEAD_LOG_INDEX_PREFIXES(self) -> list[str]:
        """
        The lead-log index prefixes.

        These are used for database rebasing operations.
        """
        return __class__.LEAD_LOG_INDEX_PREFIXES

    LAG_LOG_INDEX_PREFIXES = ["PRCL", "PRDL"]
    @property
    def LAG_LOG_INDEX_PREFIXES(self) -> list[str]:
        """
        The lag-log index prefixes.

        These are used for database rebasing operations.
        """
        return __class__.LAG_LOG_INDEX_PREFIXES
    
    INDEX_PREFIXES = ["GDPN"]
    @property
    def INDEX_PREFIXES(self) -> list[str]:
        """
        The index prefixes.

        These are used for database rebasing operations.
        """
        return __class__.INDEX_PREFIXES

    # Constants used as part of finding intertemporal constant values.
    NON_STANDARD_INTERTEMPORAL_CONSTANT_VARIABLE_PREFIXES = [
        ('EPRC', 'z1l'),
        ('EYGR', 'z1l'),
        ('WAGE', 'x1l')]
    @property
    def NON_STANDARD_INTERTEMPORAL_CONSTANT_VARIABLE_PREFIXES(self) -> list[tuple[str,str]]:
        """
        The identifications of non-standard variables with intertemporal constants.
        The prefixes include the variable name prefix and the vector name.
        """
        return __class__.NON_STANDARD_INTERTEMPORAL_CONSTANT_VARIABLE_PREFIXES

    NON_STANDARD_VARIABLES_ADJUSTED_BY_INTERTEMPORAL_CONSTANTS_PREFIXES = [
        ('EPRC', 'z1l'),
        ('EYGR', 'z1l'),
        ('PRID', 'zel')]
    @property
    def NON_STANDARD_VARIABLES_ADJUSTED_BY_INTERTEMPORAL_CONSTANTS_PREFIXES(self) -> list[tuple[str,str]]:
        """
        The identifications of non-standard variables that are adjusted by intertemporal constants.
        The prefixes include the variable name prefix and the vector name.
        """
        return __class__.NON_STANDARD_VARIABLES_ADJUSTED_BY_INTERTEMPORAL_CONSTANTS_PREFIXES

    REXC_FOR_USA = 'REXC(UU)'
    @property
    def REXC_FOR_USA(self) -> str:
        """
        The full REXC variable name for the USA.
        """
        return __class__.REXC_FOR_USA
    
    # Pick out the variables of interest to report.
    REPORTING_VARIABLES:list[str] = ['INFX(UU)', 'INFL(UU)', 'INTN(UU)', 'NB10(UU)', 'INTR(UU)', 'RB10(UU)', 'GDPN(UU)', 'GDPR(UU)', 'INVT(UU)']
    @property
    def REPORTING_VARIABLES(self) -> list[str]:
        """
        The full names of the variables to be reported, typically for debugging purposes.
        """
        return __class__.REPORTING_VARIABLES

    # Pick out the years of interest to report
    REPORTING_YEARS: list[str] = [str(x) for x in range(2018, 2026)]
    @property
    def REPORTING_YEARS(self) -> list[str]:
        """
        The years to report from projections, typically for debugging purposes.
        """
        return __class__.REPORTING_YEARS


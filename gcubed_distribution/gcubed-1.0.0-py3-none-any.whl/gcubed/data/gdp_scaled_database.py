# ------------------------------------------------------------------
# Purpose: Manage loading and provision of linearisation database.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
import logging
import pandas as pd
import numpy as np
from gcubed.base import Base
from gcubed.data.database import Database
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData


class GDPScaledDatabase(Database):
    """
    Encapsulates all of the information about the linearisation data used by a Model.

    Note that this data differs from that used for model calibration in that the data
    for gdp unit variables has been scaled by the GDP ratio for each region to the US.

    Additional properties:

        database: the database that this calibration database was derived from.
        base_year: the base year for the database.

    """

    def __init__(self, database:Database, base_year:int) -> None:

        assert database is not None
        assert isinstance(database, Database)
        self._sym_data = database.sym_data
        self._configuration = self.sym_data.configuration
        self._variables = database.variables.copy() # save memory by not taking a copy?
        self._data = database.data.copy()

        if database.base_year != base_year:
            super().rebase(new_base_year=base_year)
        else:
            self._base_year = base_year
        self._data = self.data / 100
        self.__multiply_data_by_gdp_ratio()

        self.__validate()

    @property
    def sym_data(self) -> SymData:
        return self._sym_data

    @property
    def configuration(self) -> ModelConfiguration:
        return self._configuration

    def __multiply_data_by_gdp_ratio(self):
        """
        Scale 'gdp' units data for each region by the ratio of 
        that region's real GDP to US real GDP, in the database's base year.
        Perform this function before using the database for linearisation or
        for projections.

        TODO: Should we apply this scaling factor using the ratio 
        for the same year as the data being scaled rather than using 
        the one ratio from the base year for all years in the database?
        """

        regions: list[str] = self._sym_data.regions_members

        # Get the GDP ratios for all regions
        yratr_data = self.data.loc[self.variables.name.str.startswith("YRATR("), str(self.base_year)].copy()
        yratr_data.index = regions

        # Iterate over regions, selecting the data to scale by each region
        # This will scale all variables with units equal to gdp, mmtgdp, btugdp, or gwhgdp but not the usgdp unit vars that are all the YRAT variables.
        variables_to_scale = (~(self.variables.name.str.contains("^YRAT.\(")) & self.variables.units.str.contains("gdp"))
        for region in regions:
            scale_ratio = yratr_data.loc[region]
            regions_to_scale = self.variables.loc[:, "region"] == region
            rows_to_scale = (variables_to_scale & regions_to_scale)
            self.data.loc[rows_to_scale, :] = self.data.loc[rows_to_scale, :] * scale_ratio

    def __validate(self):
        """
        Raise an exception if the calibration data is invalid.
        """
        pass

    def rebase(self):
        raise Exception("Rebasing operations cannot be performed on a subclass of database. Rebase the original database instead.")

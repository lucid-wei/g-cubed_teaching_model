# ------------------------------------------------------------------
# Purpose: Define a set of global constants.
# Author: Geoff Shuetrim
#
# Most of these constants should be produced by the SYM processor
# from model attributes rather than hard coded into the Python
# implementation of the model.
# ------------------------------------------------------------------
"""
Defines a singleton class the provides access to all constants.
"""
class Constants:

    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super().__new__(cls, *args, **kwargs)
        return cls._instance

    _DELTA = 0.00000001
    @property
    def DELTA(self) -> float:
        """
        The delta used to compute numeric derivatives.
        """
        return __class__._DELTA
    
    _USA_REGION_CODE: str = "UU"
    @property
    def USA_REGION_CODE(self) -> str:
        """
        The region code for the USA.
        """
        return __class__._USA_REGION_CODE

    _INFX_PREFIX: str = "INFX"
    @property
    def INFX_PREFIX(self) -> str:
        """
        The INFX (inflation rate target) variable prefix.
        """
        return __class__._INFX_PREFIX

    _PRID_PREFIX: str = "PRID"
    @property
    def PRID_PREFIX(self) -> str:
        """
        The PRID (weighted price of domestic output) variable prefix.
        """
        return __class__._PRID_PREFIX
        
    _WAGE_PREFIX: str = "WAGE"
    @property
    def WAGE_PREFIX(self) -> str:
        """
        The wage variable prefix.
        """
        return __class__._WAGE_PREFIX
    


    _NOMINAL_GDP_PREFIX = "LGDPN"
    @property
    def NOMINAL_GDP_PREFIX(self) -> str:
        """
        The nominal GDP variable prefix.
        """
        return __class__._NOMINAL_GDP_PREFIX


    _REAL_GDP_PREFIX = "LGDPR"
    @property
    def REAL_GDP_PREFIX(self) -> str:
        """
        The real GDP variable prefix.
        """
        return __class__._REAL_GDP_PREFIX

    _US_REAL_GDP_RATIO_PREFIX = "YRATR"
    @property
    def US_REAL_GDP_RATIO_PREFIX(self) -> str:
        """
        The ratio of regional real GDP to USA real GDP variable prefix.
        """
        return __class__._US_REAL_GDP_RATIO_PREFIX

    _REAL_INTEREST_RATE_PREFIX = "INTR"
    @property
    def REAL_INTEREST_RATE_PREFIX(self) -> str:
        """
        The real interest rate variable prefix.
        """
        return __class__._REAL_INTEREST_RATE_PREFIX

    _NOMINAL_INTEREST_RATE_PREFIX = "INTN"
    @property
    def NOMINAL_INTEREST_RATE_PREFIX(self) -> str:
        """
        The nominal interest rate variable prefix.
        """
        return __class__._NOMINAL_INTEREST_RATE_PREFIX

    # _INTEREST_RATE_PREFIXES: list[str] = ["INPN", "INPL", "INTF", "INTL", "INTN", "INTR"]
    # @property
    # def INTEREST_RATE_PREFIXES(self) -> list[str]:
    #     """
    #     The interest rate variable prefixes.

    #     These are the prefixes of the variables that are set equal to the neutral real interest
    #     rate (set in the model configuration, `ModelConfiguration.neutral_real_interest_rate`)
    #     when doing linearisation of the model and when determining the
    #     adjustments to make to equate projections to observed data when 
    #     doing the baseline projections.

    #     * `INPN` is the desired nominal short-run interest rate in the current period.
    #     * `INPL` is the desired nominal short-run interest rate, lagged by 1 period.
    #     * `INTF` is the real short-run interest rate.
    #     * `INTL` is the real short-run interest rate, lagged by 1 period.
    #     * `INTN` is the nominal short-run interest rate, controlled by the central bank.
    #     * `INTR` is the 'risk-adjusted' real short-run interest rate, controlled by the central bank,
    #     equal to INTF plus RISR - an exogenous risk-premium in the yield curve. Note that
    #     RISR is typically zero in the databases and would be used to run simulation experiments.

    #     """
    #     return __class__._INTEREST_RATE_PREFIXES


    _ALL_REAL_INTEREST_RATE_PREFIXES: list[str] = ["INTF", "INTL", "INTR"]
    @property
    def ALL_REAL_INTEREST_RATE_PREFIXES(self) -> list[str]:
        """
        The real interest rate variable prefixes.

        These are the prefixes of the variables that are set equal to the neutral real interest
        rate (set in the model configuration, `ModelConfiguration.neutral_real_interest_rate`)
        when doing linearisation of the model and when determining the
        adjustments to make to equate projections to observed data when 
        doing the baseline projections.

        * `INTF` is the real short-run interest rate.
        * `INTL` is the real short-run interest rate, lagged by 1 period.
        * `INTR` is the 'risk-adjusted' real short-run interest rate, controlled by the central bank,
        equal to INTF plus RISR - an exogenous risk-premium in the yield curve. Note that
        RISR is typically zero in the databases and would be used to run simulation experiments.

        """
        return __class__._ALL_REAL_INTEREST_RATE_PREFIXES


    _ALL_NOMINAL_INTEREST_RATE_PREFIXES: list[str] = ["INPN", "INPL", "INTN"]
    @property
    def ALL_NOMINAL_INTEREST_RATE_PREFIXES(self) -> list[str]:
        """
        The nominal interest rate variable prefixes.

        These are the prefixes of the variables that are set equal to the neutral real interest
        rate plus the target inflation rate
        when doing linearisation of the model and when determining the
        adjustments to make to equate projections to observed data when 
        doing the baseline projections.

        * `INPN` is the desired nominal short-run interest rate in the current period.
        * `INPL` is the desired nominal short-run interest rate, lagged by 1 period.
        * `INTN` is the nominal short-run interest rate, controlled by the central bank.

        """
        return __class__._ALL_NOMINAL_INTEREST_RATE_PREFIXES



    _BOND_RATE_PREFIXES: list[str] = ["NB02", "NB05", "NB10", "RB10"]
    @property
    def BOND_RATE_PREFIXES(self) -> list[str]:
        """
        The long bond rate (real and nominal) variable prefixes.
        """
        return __class__._BOND_RATE_PREFIXES

    _STATE_LEAD_VARIABLES: list[str] = ["INTN", "EXCH", "INPN", "REXB"]
    @property
    def STATE_LEAD_VARIABLES(self) -> list[str]:
        """
        The state vector lead (stl variable types in SYM) variable prefixes.
        """
        return __class__._STATE_LEAD_VARIABLES
    
    _JUMPING_VARIABLE_PREFIXES_FOR_REGIONS = ["REXC", "WELH", "LAMY", "LAMZ", "EYGR", "EPRC"]
    @property
    def JUMPING_VARIABLE_PREFIXES_FOR_REGIONS(self) -> list[str]:
        """
        The costate/jumping variable prefixes that have variables for each region.

        These are used along with wage and prid prefixes to do projections
        """
        return __class__._JUMPING_VARIABLE_PREFIXES_FOR_REGIONS

    _JUMPING_VARIABLE_PREFIXES_FOR_REGIONS_AND_SECTORS = ["LAM"]
    @property
    def JUMPING_VARIABLE_PREFIXES_FOR_REGIONS_AND_SECTORS(self) -> list[str]:
        """
        The costate/jumping variable prefixes that have variables for each region and sector.
        """
        return __class__._JUMPING_VARIABLE_PREFIXES_FOR_REGIONS_AND_SECTORS

    # Constants relevant to database rebasing operations.
    _LOG_INDEX_PREFIXES = ["PRCT", "PRID", "PRIM", "PRIX", "PRIE", "PRII", "PRKY", "PRKZ",
                        "WAGE", "PGDP", "EXCH", "REXC", "NEER", "PRCE", "PRCO", "REER", 
                        "MONE", "PRGT", "PROI", "PRDX", "PRY", "PRD", 
                        "PIM", "PRE", "POI", "PRK", "PRP", "WAG", "PMR", "PMQ", "PRX"]
    @property
    def LOG_INDEX_PREFIXES(self) -> list[str]:
        """
        The log index prefixes.

        These are used for database rebasing operations.
        """
        return __class__._LOG_INDEX_PREFIXES

    _LEAD_LOG_INDEX_PREFIXES = ["EXCL"]
    @property
    def LEAD_LOG_INDEX_PREFIXES(self) -> list[str]:
        """
        The lead-log index prefixes.

        These are used for database rebasing operations.
        """
        return __class__._LEAD_LOG_INDEX_PREFIXES

    _LAG_LOG_INDEX_PREFIXES = ["PRCL", "PRDL"]
    @property
    def LAG_LOG_INDEX_PREFIXES(self) -> list[str]:
        """
        The lag-log index prefixes.

        These are used for database rebasing operations.
        """
        return __class__._LAG_LOG_INDEX_PREFIXES
    
    _INDEX_PREFIXES = ["GDPN"]
    @property
    def INDEX_PREFIXES(self) -> list[str]:
        """
        The index prefixes.

        These are used for database rebasing operations.
        """
        return __class__._INDEX_PREFIXES

    # Constants used as part of finding intertemporal constant values.
    _NON_STANDARD_INTERTEMPORAL_CONSTANT_VARIABLE_PREFIXES:list[tuple[str,str]] = [
        ('EPRC', 'z1l'),
        ('EYGR', 'z1l'),
        ('WAGE', 'x1l')]
    @property
    def NON_STANDARD_INTERTEMPORAL_CONSTANT_VARIABLE_PREFIXES(self) -> list[tuple[str,str]]:
        """
        The identifications of non-standard variables with intertemporal constants.
        The prefixes include the variable name prefix and the vector name.
        """
        return __class__._NON_STANDARD_INTERTEMPORAL_CONSTANT_VARIABLE_PREFIXES

    _NON_STANDARD_VARIABLES_ADJUSTED_BY_INTERTEMPORAL_CONSTANTS_PREFIXES = [
        ('EPRC', 'z1l'),
        ('EYGR', 'z1l'),
        ('PRID', 'zel')]
    @property
    def NON_STANDARD_VARIABLES_ADJUSTED_BY_INTERTEMPORAL_CONSTANTS_PREFIXES(self) -> list[tuple[str,str]]:
        """
        The identifications of non-standard variables that are adjusted by intertemporal constants.
        The prefixes include the variable name prefix and the vector name.
        """
        return __class__._NON_STANDARD_VARIABLES_ADJUSTED_BY_INTERTEMPORAL_CONSTANTS_PREFIXES

    _REXC_FOR_USA = 'REXC(UU)'
    @property
    def REXC_FOR_USA(self) -> str:
        """
        The full REXC variable name for the USA.
        """
        return __class__._REXC_FOR_USA
    
    # Pick out the variables of interest to report.
    _REPORTING_VARIABLES:list[str] = ['TIX(g05,UU)', 'INFX(UU)', 'INFL(UU)', 'INTN(UU)', 'NB10(UU)', 'INTR(UU)', 'RB10(UU)', 'GDPN(UU)', 'GDPR(UU)', 'INVT(UU)']
    @property
    def REPORTING_VARIABLES(self) -> list[str]:
        """
        The full names of the variables to be reported, typically for debugging purposes.
        """
        return __class__._REPORTING_VARIABLES

    # Pick out the years of interest to report
    _REPORTING_YEARS: list[str] = [str(x) for x in range(2018, 2026)]
    @property
    def REPORTING_YEARS(self) -> list[str]:
        """
        The years to report from projections, typically for debugging purposes.
        """
        return __class__._REPORTING_YEARS


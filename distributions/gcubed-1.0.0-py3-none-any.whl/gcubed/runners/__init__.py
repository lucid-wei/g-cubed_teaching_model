"""
This package contains the Runner classes for G-Cubed.

Various Runner classes are used for different types of model experiments.

"""
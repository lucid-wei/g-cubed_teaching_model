"""

## This runner is still experimental 
    
Do not use it unless you are involved in its development.

Contains the advanced runner class - used to run advanced model experiments.
"""
import os
import logging
from datetime import datetime
from queue import Empty
from sre_constants import RANGE
from gcubed.base import Base
from gcubed.model_configuration import ModelConfiguration
from gcubed.model import Model
from gcubed.linearisation.linear_model import LinearModel
from gcubed.linearisation.state_space_form import StateSpaceForm
from gcubed.linearisation.stable_manifold import StableManifold
from gcubed.projections.projections import Projections
from gcubed.projections.baseline_projections import BaselineProjections
from gcubed.projections.simulation_layer_definitions import SimulationLayerDefinitions
from gcubed.projections.simulation_layer import SimulationLayer
from gcubed.projections.relinearisation_projections import RelinearisationProjections

class AdvancedRunner(Base):
    """

    ### Overview


    The AdvancedRunner class runs a simulation experiment 
    with G-Cubed that incorporates relinearisation in chosen years while
    allowing for strict or non-strict choice of points to linearise around
    and supporting simulation experiments using or not using relinearisation
    in their event years.

    1. The model is loaded and used to generate baseline projections.
    2. The experiment design is loaded, setting out each of the events being
    simulated as a separate simulation layer.
    3. The simulation layers are loaded and applied to the model to generate 
    projection updates. 
    
    Projections based on any of the simulation layers can be compared to projections
    from the baseline or from other simulation layers associated with the experiment.

    #### Note: Determine behaviour with regard to neutral real interest rates
    by setting the `AdvancedRunner.linearise_around_the_neutral_real_interest_rate` and
    the `AdvancedRunner.start_projections_from_the_neutral_real_interest_rate` and the
    `AdvancedRunner.relinearise_around_the_neutral_real_interest_rate` properties
    before triggering the model run by calling `AdvancedRunner.run`. The default
    behaviour is to:
    
    * use neutral real interest rates for linearisation
    * start the projections from the neutral real interest rate and
    * relinearise around the neutral real interest rate.

    """

    def __init__(self, working_directory:str, configuration_file: str, relinearisation_years: list[int] = None, experiment_design_file: str = None):
        """
        ### Overview

        When the constructor is called, the runner loads the configuration 
        and the model, ready for running. Call the run method
        when you are ready to start model linearisation etc. after having set 
        properties for the runner to determine its behaviour, for example, how
        linearisation is done in relation to the neutral real interest rate.

        The relinearisation of the model is done for each event year associated with
        a simulation layer and for each year nominated for relinearisation.

        After a successful run, if `AdvancedRunner.save_results` = `True`,
        you will see the results generated in a new timestamped results subdirectory 
        of the directory that you ran the command from.
        
        The results directory contains three CSV files and a log file:

        * `baseline_projections.csv` 
        * `deviation_projections.csv`
        * `final_projections.csv`
        * `run.log`

        The log file is a text file that contains messages 
        about the progress of the model run and any problems that arose.
        
        ### Arguments
        
        `working_directory`: The directory where the results 
        and logs are to be stored.

        `configuration_file`: The location of the configuration 
        file, as an absolute path or relative to the 
        specified working directory.

        `relinearisation_years`: The list of years where a 
        relinearisation is required. This list can be empty
        in which case the model is not relinearised. To generate a 
        list of years, from 2018 to say, 2030, you can supply the
        following as as this parameter value:
        `list(range(2018, 2031))`. (Note that the upper bound is not
        included in the range.)

        `experiment_design_file`: The optional location of the 
        experiment design CSV file, as a relative path directory
        to the experiment design file from the simulations directory 
        within the model directory (the model directory contains
        the configuration file).
        """

        self._all_projections: list[Projections] = []

        self.save_results = False

        self.start_projections_from_the_neutral_real_interest_rate = True
        self.linearise_around_the_neutral_real_interest_rate = True
        self.relinearise_around_the_neutral_real_interest_rate = True

        self.relinearise_in_event_years = False

        self._completed_successfully: bool = False

        if not os.path.isdir(working_directory):
            raise Exception(f"{working_directory} is not a directory.")
        
        if not os.access(working_directory, os.W_OK):
            raise Exception(f"You need write access to {working_directory} but that permission has not been granted to you.")

        if self.save_results:
            # Set up directory where results will be stored
            self.timestamp: str = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            self.results_directory: str = os.path.join(working_directory, f"results_{self.timestamp}")
            if not os.path.exists(self.results_directory):
                os.mkdir(self.results_directory)
            if not os.path.isdir(self.results_directory):
                raise Exception(f"Results are to be stored in the directory {self.results_directory} but it is a file, not a directory.")

        # Get the absolute path to the model configuration file.
        if os.path.isabs(configuration_file):
            self.filename:str = configuration_file
        else:
            self.filename: str = os.path.join(working_directory, configuration_file)
        if not os.path.isfile(self.filename):
            raise Exception(f"There is no model configuration file at {self.filename}.")
        logging.info(f"The model configuration will be loaded from {self.filename}.")

        # Load the model
        model_configuration: ModelConfiguration = ModelConfiguration(configuration_file=self.filename)
        self._model: Model = Model(model_configuration)

        # Validate and save the list of relinearisation years.
        if not relinearisation_years:
            self._relinearisation_years = []
        else:
            if not isinstance(relinearisation_years, list):
                raise Exception("You must specify a list of years in which the model is to be relinearised.")
            for year in relinearisation_years:
                if not isinstance(year, int):
                    raise Exception("The list of relinearisation years must contain YYYY formatted integers.")
            if len(relinearisation_years) != len(set(relinearisation_years)):
                raise Exception("There must not be duplicate relinearisation years.")
            if relinearisation_years != sorted(relinearisation_years):
                raise Exception("The list of relinearisation years must be in ascending order.")
            if relinearisation_years[0] <= model_configuration.original_first_projection_year:
                raise Exception("The relinearisation years must be after the first projection year.")
            if relinearisation_years[-1] >= model_configuration.last_projection_year:
                raise Exception("The relinearisation years must be before the last projection year.")
            self._relinearisation_years = relinearisation_years

        # Save the experiment design file for later use.
        self._experiment_design_file = experiment_design_file

    @property
    def model(self) -> ModelConfiguration:
        """
        The model being run.
        """
        return self._model

    @property
    def relinearisation_years(self) -> list[int]:
        """
        The (possibly empty) list of relinearisation years (all in YYYY format).
        """
        return self._relinearisation_years

    @property
    def event_years(self) -> list[int]:
        """
        The (possibly empty) list of event years (all in YYYY format).
        """
        return self._event_years

    @property
    def all_projections(self) -> list[Projections]:
        """
        A list of all projections generated by the 
        runner or an empty list if no projections
        have been generated by the runner when this 
        property is requested. The first projections are the baseline projections
        and then the following projections are the projections generated due 
        to simulation layers or relinearisations etc. added to the list as they 
        are generated.

        This method will return the empty list if the runner has
        not started. If the runner is partway through the run, 
        then the projections that have been produced will be available.
        """
        if not hasattr(self,'_all_projections'):
            raise Exception("The list of all projections does not exist but it should. There is a bug in this runner.")
        return self._all_projections

    @property
    def baseline_projections(self) -> BaselineProjections:
        """
        The baseline projections.
        """
        if self._all_projections is Empty:
            raise Exception("The baseline projections are not yet available. Make sure you run the model before accessing them.")
        return self.all_projections[0]

    @property
    def most_recently_generated_projections(self) -> Projections:
        """
        The projections most recently generated in the run.
        """
        if self._all_projections is Empty:
            raise Exception("Projections are not yet available. Make sure you run the model before accessing them.")
        return self.all_projections[-1]

    @property
    def final_projections(self) -> Projections:
        """
        The final projections which can be the baseline
        projections if there was no simulation experiment to do.
        """
        if not self.completed_successfully:
            raise Exception("The run has not yet completed so the final projections are not yet available.")
        if self._all_projections is Empty:
            raise Exception("The final projections are not yet available. Make sure you run the model before accessing them.")
        return self.all_projections[-1]
        
    @property
    def experiment_design_file(self) -> str:
        """
        The experiment design file name or `None` if no experiment is to be 
        run.
        """
        if not hasattr(self, "_experiment_design_file"):
            return None
        return self._experiment_design_file

    @property
    def simulation_layer_definitions(self) -> SimulationLayerDefinitions:
        """
        The simulation layer definitions documented in the experiment design.
        """
        if not hasattr(self, "_simulation_layer_definitions"):
            raise Exception("The simulation layer definitions have not been loaded yet.")
        return self._simulation_layer_definitions

    @property
    def save_results(self) -> bool:
        """
        `True` if the results are to be saved to a results directory automatically at the end of the
        run and `False` otherwise. 
        
        Defaults to False.

        If necessary, modify this setting once the runner is instantiated but 
        before the experiment is run.
        """
        return self._save_results

    @save_results.setter
    def save_results(self, value: bool) -> bool:
        """
        ### Overview
        
        Set the value to `True` if the results are to be saved to a 
        results directory automatically at the end of the run and `False` otherwise.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._save_results = value

    @property
    def linearise_around_the_neutral_real_interest_rate(self) -> bool:
        """
        `True` if the baseline linearisation is around the neutral real interest rate
        and `False` if it is around database values.
        """
        return self._linearise_around_the_neutral_real_interest_rate
    
    @linearise_around_the_neutral_real_interest_rate.setter
    def linearise_around_the_neutral_real_interest_rate(self, value: bool):
        """
        Set to `True` if the baseline linearisation is around the neutral real interest rate
        and `False` if it is around database values.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._linearise_around_the_neutral_real_interest_rate = value

    @property
    def relinearise_around_the_neutral_real_interest_rate(self) -> bool:
        """
        `True` if  relinearisations are around the neutral real interest rate
        and `False` if they are around previous projection values
        in the relinearisation year.
        """
        return self._relinearise_around_the_neutral_real_interest_rate
    
    @relinearise_around_the_neutral_real_interest_rate.setter
    def relinearise_around_the_neutral_real_interest_rate(self, value: bool):
        """
        Set to `True` if the relinearisations are around the neutral real interest rate
        and `False`  if they are around previous projection values
        in the relinearisation year.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._relinearise_around_the_neutral_real_interest_rate = value

    @property
    def start_projections_from_the_neutral_real_interest_rate(self) -> bool:
        """
        `True` if the baseline linearisation is around neutral real interest rates
        and `False` if they are around database values.
        """
        return self._start_projections_from_the_neutral_real_interest_rate
    
    @start_projections_from_the_neutral_real_interest_rate.setter
    def start_projections_from_the_neutral_real_interest_rate(self, value: bool):
        """
        Set to `True` if the baseline projections start with neutral real interest rate
        and `False` if they start with database values.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._start_projections_from_the_neutral_real_interest_rate = value


    @property
    def relinearise_in_event_years(self) -> bool:
        """
        `True` if the runner is to relinearise the model in all event years
        as well as the years specified and `False` if the runner is to relinearise the model only
        in the years specified.
        
        Defaults to `False`.

        If necessary, modify this setting once the running is instantiated but 
        before the experiment is run.
        """
        return self._relinearise_in_event_years

    @relinearise_in_event_years.setter
    def relinearise_in_event_years(self, value: bool) -> bool:
        """
        ### Overview
        
        Set the value to `True` if the runner is to relinearise the model in all event years
        as well as the years specified and `False` if the runner is to relinearise the model only
        in the years specified.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._relinearise_in_event_years = value

    @property
    def completed_successfully(self) -> bool:
        """
        `True` if the runner has completed all projections successfully and `False` otherwise.
        """
        return self._completed_successfully

    def run(self):
        """
        ### Overview

        Do the actual work of running the model and performing 
        the experiment.
        
        Call this method after creating a Runner instance.

        Once the experiment has run, you can retrieve projections from
        the simulation layer(s) of interest and the baseline for comparison and
        analysis purposes.
        """
        if self.save_results:
            log_file: str = os.path.join(self.results_directory, "run.log")
            fh = logging.FileHandler(log_file, mode='w')
            logging.basicConfig(level=logging.DEBUG,
                                format='%(asctime)s %(levelname)s %(message)s',
                                handlers=[
                                    fh,
                                    logging.StreamHandler()
                                ])
            logging.info(f"Saving results and logs to {self.results_directory}.")
        else:
            logging.basicConfig(level=logging.DEBUG,
                                format='%(asctime)s %(levelname)s %(message)s',
                                handlers=[
                                    logging.StreamHandler()
                                ])
            logging.info(f"Only logging to the console. No results being saved to files.")

        # Get the model stable manifold and related results for the baseline projections
        linear_model: LinearModel = LinearModel(
            model=self.model,
            use_neutral_real_interest_rate=self.linearise_around_the_neutral_real_interest_rate)
        state_space_form: StateSpaceForm = StateSpaceForm(linear_model=linear_model)
        stable_manifold: StableManifold = StableManifold(state_space_form=state_space_form)

        # Generate and store the baseline projections
        self.all_projections.append(BaselineProjections(
            stable_manifold=stable_manifold,
            start_from_neutral_real_interest_rate=self.start_projections_from_the_neutral_real_interest_rate))

        # Generate the CSV file containing baseline projections
        if self.save_results:
            self.baseline_projections.publishable_projections.to_csv(f"{self.results_directory}/baseline_projections.csv")
            logging.info(f"Baseline publication projections have been saved to a CSV file in {self.results_directory}")

        # Load the simulation layer definitions from the experiment design file.
        self._simulation_layer_definitions = SimulationLayerDefinitions(sym_data=self.baseline_projections.sym_data)
        if self.experiment_design_file is not None:
            self.simulation_layer_definitions.load_from_csv_file(design_file=self.experiment_design_file)
        
        self._event_years = self.simulation_layer_definitions.all_event_years_in_ascending_order

        if self.relinearise_in_event_years and self.experiment_design_file is not None:
            # Augment the list of relinearisation years.
            self.relinearisation_years = sorted(set(self.relinearisation_years).union(set(self.event_years)))
            logging.debug(f"The combined event and relinearisation years are:\n{self.relinearisation_years}")

        # Step forward through the projection years and for each step check if we need to do 
        # a simulation or relinearisation.
        for year in range(self.baseline_projections.first_projection_year, self.baseline_projections.last_projection_year):
            
            # Do a relinearisation and add any relevant simulation layers while we are at it.
            if year in self.relinearisation_years:

                self.all_projections.append(
                    RelinearisationProjections(
                        baseline_projections=self.baseline_projections, 
                        previous_projections=self.most_recently_generated_projections,
                        relinearisation_year=year, 
                        simulation_layer_definitions=self.simulation_layer_definitions,
                        relinearise_around_the_neutral_real_interest_rate=self.relinearise_around_the_neutral_real_interest_rate)
                    )

                logging.info(f"Generated relinearised projections from {self.most_recently_generated_projections.first_projection_year}.")
                continue

            if year in self.event_years:
                # Apply each simulation layer with this event year, one after the other.
                for simulation_layer_definition in self.simulation_layer_definitions.get_simulation_layer_definitions(event_year=year):

                    self.all_projections.append(
                        SimulationLayer(
                            simulation_layer_definition=simulation_layer_definition,
                            previous_projections=self.most_recently_generated_projections
                            )
                        )
                    
                    logging.info(f"Added {simulation_layer_definition.name} simulation layer to projections from {self.most_recently_generated_projections.first_projection_year}.")
                
                continue

        self._completed_successfully = True

        if self.save_results:
            # Generate the CSV file containing simulation projections
            self.final_projections.publishable_projections.to_csv(f"{self.results_directory}/final_projections.csv")
            # Generate the CSV file containing the simulation deviation from baseline projections
            Projections.get_differences_between_projections(new_projections=self.final_projectionsl.publishable_projections, original_projections=self.baseline_projections.publishable_projections).to_csv(f"{self.results_directory}/deviation_projections.csv")
            logging.info(f"The simulation experiment results have been saved as CSV files in {self.results_directory}")
        else:
            logging.info(f"The simulation experiment has run.")


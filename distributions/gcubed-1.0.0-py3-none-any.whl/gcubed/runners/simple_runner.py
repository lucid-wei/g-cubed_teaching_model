"""
Contains the Runner class - used to run simple model experiments.
"""
import os
import logging
from datetime import datetime
from gcubed.base import Base
from gcubed.model_configuration import ModelConfiguration
from gcubed.model import Model
from gcubed.linearisation.linear_model import LinearModel
from gcubed.linearisation.state_space_form import StateSpaceForm
from gcubed.linearisation.stable_manifold import StableManifold
from gcubed.projections.projections import Projections
from gcubed.projections.baseline_projections import BaselineProjections
from gcubed.projections.simulation_experiment import SimulationExperiment
from gcubed.projections.simulation_layer import SimulationLayer


class SimpleRunner(Base):
    """
    ### Overview

    The Runner class runs a simulation experiment 
    with G-Cubed.

    1. The model is loaded and used to generate baseline projections.
    2. The experiment design is loaded, setting out each of the events being
    simulated as a separate simulation layer.
    3. The simulation layers are loaded and applied to the model to generate 
    projection updates. 
    
    Projections based on any of the simulation layers can be compared to projections
    from the baseline or from other simulation layers associated with the experiment.

    #### Example code to use the simple runner

    Assuming your current working directory is the model root directory, the simple runner
    can be used with the following code.

    ```
    from gcubed.runners.simple_runner import SimpleRunner
    runner: SimpleRunner = SimpleRunner(
        working_directory=".",
        configuration_file="configuration2R164.csv", 
        experiment_design_file="experiment1/design.csv"
        )
    runner.save_results = True
    runner.run()
    ```

    This assumes that the model configuration file is
    called `configuration2R164.csv`. It also assumes that the simulation experiment is 
    described by the `design.csv` file that is located in the `simulations/experiment1`
    subdirectory of the model's root directory.

    Note that `experiment_design_file` should be in the format of "`EXPERIMENT_NAME`/`DESIGN_FILE_NAME`",
    so that results can be saved in the corresponding experiment directory.

    After a successful run, if the `SimpleRunner.save_results` is set to `True` beforehand,
    you will see the results generated in a new timestamped results 
    subdirectory of the directory that you ran the command from.
    
    The results directory contains three CSV files and a log file:

    * `baseline_projections.csv` 
    * `deviation_projections.csv`
    * `final_projections.csv`
    * `run.log`

    #### Note: Determine behaviour with regard to neutral real interest rates
    by setting the `SimpleRunner.linearise_around_the_neutral_real_interest_rate` and
    the `SimpleRunner.start_projections_from_the_neutral_real_interest_rate` properties
    before triggering the model run (calling `SimpleRunner.run`). The default
    behaviour is to:
    
    * use neutral real interest rates for linearisation and
    * start the projections from the neutral real interest rate.

    """

    def __init__(self, working_directory: str, configuration_file: str, experiment_design_file: str = None):
        """

        ### Overview

        Loads the configuration and the model, ready for running. Call the run method
        when you are ready to start model linearisation etc.

        ### Arguments
        
        `working_directory`: The directory where the results and logs are to be stored.

        `configuration_file`: The location of the configuration file, as an absolute path or relative to the 
        specified working directory.

        `experiment_design_file`: The optional location of the experiment design CSV file, as a relative path directory
        to the experiment design file from the simulations directory within the model directory (the model directory contains
        the configuration file). If the experiment design file is not specified then the run just produces baseline 
        projections.

        use_neutral_real_interest_rate: If `True` then the neutral real interest rate is used in the model, otherwise
        the real interest rates are based on the database values. This parameter is optional and defaults to
        a value of `True`.

        """

        self.save_results = False
        self.annotate_results = False

        if not os.path.isdir(working_directory):
            raise Exception(f"{working_directory} is not a directory.")

        if not os.access(working_directory, os.W_OK):
            raise Exception(
                f"You need write access to {working_directory} but that permission has not been granted to you.")

        # Set up defaults for the linearisation and the starting projection values for interest rates.
        self.linearise_around_the_neutral_real_interest_rate = True
        self.start_projections_from_the_neutral_real_interest_rate = True

        # Get the absolute path to the model configuration file.
        if os.path.isabs(configuration_file):
            self.filename: str = configuration_file
        else:
            self.filename: str = os.path.join(working_directory, configuration_file)
        if not os.path.isfile(self.filename):
            raise Exception(f"There is no model configuration file at {self.filename}.")
        logging.info(f"The model configuration will be loaded from {self.filename}.")

        # Load the model
        model_configuration: ModelConfiguration = ModelConfiguration(configuration_file=self.filename)
        self._model: Model = Model(model_configuration)

        # Save the working directory for later use.
        self._working_directory = working_directory

        # Save the experiment design file for later use.
        self._experiment_design_file = experiment_design_file

    @property
    def model(self) -> ModelConfiguration:
        """
        The model being run.
        """
        return self._model

    @property
    def baseline_projections(self) -> BaselineProjections:
        """
        The baseline projections.
        """
        if not hasattr(self, "_baseline_projections"):
            raise Exception(
                "The baseline projections are not yet available. Make sure you run the model before accessing them.")
        return self._baseline_projections

    @property
    def final_projections(self) -> Projections:
        """
        The final projections or `None` if there was no simulation experiment to do.
        """
        if not hasattr(self, "_experiment"):
            logging.warning("The final projections are not yet available. Make sure you run the model to completion before accessing them.")
            return None
        return self.experiment.final_projections

    @property
    def experiment(self) -> SimulationExperiment:
        """
        The simulation experiment.
        """
        if not hasattr(self, "_experiment"):
            raise Exception("The simulation experiment results are not yet available. Make sure you run the model before accessing them.")
        return self._experiment

    @property
    def save_results(self) -> bool:
        """
        True if the results are to be saved to a results directory automatically at the end of the
        run and false otherwise. 
        
        Defaults to False.

        If necessary, modify this setting once the running is instantiated but 
        before the experiment is run.
        """
        return self._save_results

    @save_results.setter
    def save_results(self, value: bool):
        """
        Corresponding setter function to enable such usages:
        e.g. runner.save_results = True
        """
        assert value is not None
        assert isinstance(value, bool)
        self._save_results = value

    @property
    def annotate_results(self) -> bool:
        """
        True if you want the saved results to contain description and units as columns.

        Defaults to False.

        If necessary, modify this setting once the running is instantiated but
        before the experiment is run.
        """
        return self._annotate_results

    @annotate_results.setter
    def annotate_results(self, value: bool):
        """
        Corresponding setter function to enable such usages:
        e.g. runner.annotate_results = True
        """
        assert value is not None
        assert isinstance(value, bool)
        self._annotate_results = value

    @property
    def linearise_around_the_neutral_real_interest_rate(self) -> bool:
        """
        `True` if the baseline linearisation is around the neutral real interest rate
        and `False` if it is around database values.
        """
        return self._linearise_around_the_neutral_real_interest_rate

    @linearise_around_the_neutral_real_interest_rate.setter
    def linearise_around_the_neutral_real_interest_rate(self, value: bool):
        """
        Set to `True` if the baseline linearisation is around the neutral real interest rate
        and `False` if it is around database values.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._linearise_around_the_neutral_real_interest_rate = value

    @property
    def start_projections_from_the_neutral_real_interest_rate(self) -> bool:
        """
        `True` if the baseline linearisation is around neutral real interest rates
        and `False` if they are around database values.
        """
        return self._start_projections_from_the_neutral_real_interest_rate

    @start_projections_from_the_neutral_real_interest_rate.setter
    def start_projections_from_the_neutral_real_interest_rate(self, value: bool):
        """
        Set to `True` if the baseline projections start with neutral real interest rate
        and `False` if they start with database values.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._start_projections_from_the_neutral_real_interest_rate = value

    def run(self):
        """
        ### Overview

        Do the actual work of running the model and performing 
        the experiment.
        
        Call this method after creating a Runner instance.

        Once the experiment has run, you can retrieve projections from
        the simulation layer(s) of interest and the baseline for comparison and
        analysis purposes.
        """

        if self.save_results:
            # Set up directory where results will be stored
            self._timestamp: str = self.now
            experiment_name = os.path.dirname(self._experiment_design_file)
            self.results_directory: str = os.path.join(self._working_directory, "simulations", experiment_name,
                                                       f"results_{self._timestamp}")
            if not os.path.exists(self.results_directory):
                os.mkdir(self.results_directory)
            if not os.path.isdir(self.results_directory):
                raise Exception(
                    f"Results are to be stored in the directory {self.results_directory} but it is a file, not a directory.")

        if self.save_results:
            log_file: str = os.path.join(self.results_directory, "run.log")
            fh = logging.FileHandler(log_file, mode='w')
            logging.basicConfig(level=logging.DEBUG,
                                format='%(asctime)s %(levelname)s %(message)s',
                                handlers=[
                                    fh,
                                    logging.StreamHandler()
                                ])
            logging.info(f"Saving results and logs to {self.results_directory}.")
        else:
            logging.basicConfig(level=logging.DEBUG,
                                format='%(asctime)s %(levelname)s %(message)s',
                                handlers=[
                                    logging.StreamHandler()
                                ])
            logging.info(f"Only logging to the console. No results being saved to files.")

        # Get the model stable manifold and related results
        linear_model: LinearModel = LinearModel(
            model=self.model,
            use_neutral_real_interest_rate=self.linearise_around_the_neutral_real_interest_rate)
        state_space_form: StateSpaceForm = StateSpaceForm(linear_model=linear_model)
        stable_manifold: StableManifold = StableManifold(state_space_form=state_space_form)

        # Generate the baseline projections
        self._baseline_projections: BaselineProjections = BaselineProjections(
            stable_manifold=stable_manifold,
            start_from_neutral_real_interest_rate=self.start_projections_from_the_neutral_real_interest_rate)

        # Generate the CSV file containing baseline projections
        if self.save_results:
            if self.annotate_results:
                self.baseline_projections.annotated_publishable_projections.to_csv(
                    f"{self.results_directory}/baseline_projections.csv")
            else:
                self.baseline_projections.publishable_projections.to_csv(
                    f"{self.results_directory}/baseline_projections.csv")
            logging.info(f"Baseline publication projections have been saved to a CSV file in {self.results_directory}")

        if self._experiment_design_file is not None:

            # Run the simulation experiment
            self._experiment = SimulationExperiment(baseline_projections=self.baseline_projections,
                                                    design_file=self._experiment_design_file)

            if self.save_results:
                if self.annotate_results:
                    # Generate the CSV file containing simulation projections
                    self.final_projections.annotated_publishable_projections.to_csv(f"{self.results_directory}/final_projections.csv")
                    # Generate the CSV file containing the simulation deviation from baseline projections
                    Projections.get_differences_between_projections(
                        new_projections=self.final_projections.annotated_publishable_projections,
                        original_projections=self.baseline_projections.annotated_publishable_projections).to_csv(
                        f"{self.results_directory}/deviation_projections.csv")
                else:
                    # Generate the CSV file containing simulation projections
                    self.final_projections.publishable_projections.to_csv(f"{self.results_directory}/final_projections.csv")
                    # Generate the CSV file containing the simulation deviation from baseline projections
                    Projections.get_differences_between_projections(
                        new_projections=self.final_projections.publishable_projections,
                        original_projections=self.baseline_projections.publishable_projections).to_csv(
                        f"{self.results_directory}/deviation_projections.csv")
                logging.info(
                    f"The simulation experiment results have been saved as CSV files in {self.results_directory}")
            else:
                logging.info(f"The simulation experiment has run.")

# ------------------------------------------------------------------
# Purpose: Load and provide access to the data
# produce by using SYM to process the model sym
# definition.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
"""
Contains the SymData class
"""
import logging
import os
from gcubed.constants import Constants
from gcubed.model_configuration import ModelConfiguration
import pandas as pd
import regex as re


class SymData:
    """

    #### Overview

    The model equations are expressed in terms of various vectors of variables.
    Each vector is a different type of variable.
    Note the naming conventions for the lefthand side (LHS) variable vectors:

    a. X1L (the vector of state variables) X=S=State
    b. J1L (the vector of costate or jump variables) J=C=Costate
    c. ZEL (the endogenous variables LOGY, PRCT, PRID) 
    d. Z1L (the other endogenous variables)

    These 4 vectors of variables are functions of:

    1. X1R is right hand side (RHS) state variables
    2. J1R is RHS costate or jump variables
    3. ZER is RHS endogenous variables LOGY, PRCT, PRID
    4. EXZ is RHS the lead expected ze variables
    5. YXR is RHS state variables lagged by 1 period
    6. YJR is RHS costate variables lagged by 1 period
    7. EXO is exogenous variables (by definition only appearing on RHS)
    8. Z1R is RHS other endogenous variables.

    """

    # Class properties reducing the need to instantiate these lists on each call.
    _lhs_vector_names: list[str] = ["x1l", "j1l", "zel", "z1l"]
    _rhs_vector_names: list[str] = ["x1r", "j1r", "zer", "exz", "yxr", "yjr", "exo", "z1r"]

    _ssf_rhs_vector_names: list[str] = ["exz", "yxr", "yjr", "exo"]

    # Those vectors that are projected forward using the model
    _projection_vector_names: list[str] = ["x1l", "j1l", "zel", "z1l", "exo"]

    def __init__(self, configuration: ModelConfiguration) -> None:
        """

        ### Constructor

        Loads and provides access to all of the information about the model contained
        in the SYM model definition.
        
        ### Arguments

        `configuration`: The configuration details for the model.

        """
        
        assert isinstance(configuration, ModelConfiguration)
        self._configuration = configuration

        logging.info("Loading the model equation details produced by the SYM processor.")
        logging.info("Loading the model varinfo.")
        self.__load_varinfo()
        logging.info("Loading the model varmap.")
        self.__load_varmap()
        logging.info("Loading the model optmap.")
        self.__load_optmap()
        logging.info("Loading the model summary.")
        self.__load_model_summary()
        logging.info("Loading the model sym summary.")
        self.__summarise_sym_information()
        logging.info("Loading varinfo/varmap combination.")
        self.__combine_varinfo_varmap()
        self.__validate()

    @property
    def configuration(self):
        """
        The configuration details for the model.
        """
        return self._configuration

    @property
    def var_info(self) -> pd.DataFrame:
        """
        The dataframe of information about the model variables, loaded from the var_info file
        produced by processing the SYM model definition with the SYM processor.
        """
        # TODO: Make sure parameter attributes in SYM appear in this dataset in the last column.
        return self._variable_information

    @property
    def var_map(self) -> pd.DataFrame:
        """
        The dataframe containing the map of the model variables, loaded from the var_map file
        produced by processing the SYM model definition with the SYM processor.
        """
        return self._variable_map

    @property
    def opt_map(self) -> pd.DataFrame:
        """
        The dataframe containing the opt map of the model variables, loaded from the optmap file
        produced by processing the SYM model definition with the SYM processor.

        This information is not used by the Python implementation.
        """
        return self._optmap

    def matching_rhs_vector_name(self, lhs_vector_name: str) -> str:
        """
        
       ### Arguments

        `lhs_vector_name`: the name of the LHS vector.

       ### Returns 
        
        the matching RHS vector name, replacing the last character, l, with an r.
        """
        return f"{lhs_vector_name[0:2]}r"

    def varmap_variable_type(self, vector_name: str):
        """
        Convert a vector name in the model to the varmap file variable type to lookup for
        the varmap information associated with the vector.
        """
        match vector_name:
            case "x1r" | "x1l":
                return "x1l"
            case "yxr":
                return "x1l"
            case "j1r" | "j1l":
                return "j1l"
            case "yjr":
                return "j1l"
            case "zer" | "zel":
                return "zel"
            case "exz":
                return "zel"
            case "z1r" | "z1l":
                return "z1l"
            case "exo":
                return "exo"
            case _:  # LHS vector names.
                raise Exception(f"Requested varmap variable type for a vector {vector_name} that is not defined by the SYM processor.")

    def projection_vector_for_variable(self, variable_name: str) -> str:
        """
       ### Arguments

        `vector_name`: The fully qualified name of the variable
        
        ### Returns
        
        The string ID of the projection vector that the variable is in.
        """
        var_types: pd.Series = self.var_map.loc[[variable_name], 'var_type']
        if len(var_types) == 0:
            raise Exception(f"{variable_name} is not declared in the SYM model.")
        vector_name = var_types.values[0]
        return self.varmap_variable_type(vector_name=vector_name)


    @property
    def sym_sets(self) -> dict[str, list[str]]:
        """
        A dictionary mapping from the name of the SYM model definition of the set 
        to the SYM members of the set, contained in a list of strings.
        """
        return self._sym_sets

    def __set_members(self, set_name: str) -> list[str]:
        """
        ### Arguments

        `set_name`: The name of the SYM model definition set of interest, e.g. 'region'.

        ### Returns

        The members of the named set, as a list of strings, or the empty list if
        the named set is not part of the SYM model definition.
        """
        if set_name in self.sym_sets:
            return self.sym_sets[set_name].copy()
        else:
            return list()

    def __set_members_count(self, set_name: str) -> int:
        """
        ### Arguments

        `set_name`: The name of the SYM model definition set of interest, e.g. 'region'.

        ### Returns

        The number of members of the named set.
        
        """
        members = self.__set_members(set_name)
        if members:
            return len(members)
        return 0

    @property
    def goods_members(self) -> list[str]:
        """
        The list of goods produced in the economy. These are the members of the
        `goods` set, that is a part of every G-Cubed model SYM definition.
        """
        return self.__set_members('goods')

    @property
    def goods_count(self) -> int:
        """
        The number of goods produced in the economy. These are the members of the
        `goods` set, that is a part of every G-Cubed model SYM definition.
        """
        return self.__set_members_count('goods')

    @property
    def energy_goods_members(self) -> list[str]:
        """
        The list of energy goods produced in the economy. These are the outputs 
        of the energy producing sectors in the economy.

        They are identified by being  members of the `goods_e` set, that is a part of 
        every G-Cubed model SYM definition.
        """
        return self.__set_members("goods_e")

    @property  # numener # g01 for version R of the model
    def energy_goods_count(self) -> int:
        """
        The number of energy goods produced in the economy. These are the outputs 
        of sectors in the economy that deal with extraction and value addition for
        fuel sources (e.g.coal, gas, oil, petroleum refining etc) as well as the 
        electricity distribution sector.

        They are identified by being members of the `goods_e` set, that is a part of 
        every G-Cubed model SYM definition.
        """        
        return self.__set_members_count('goods_e')

    @property
    def electricity_generation_goods_members(self) -> list[str]:
        """
        The list of goods in the economy that are produced by electricity generation sectors. 
        All of those sectors produce electricity, so their output is the same in some sense. However,
        the output of each industry is identified by its own 'good' identifier.

        They are identified by being  members of the `goods_g` set.
        """
        return self.__set_members("goods_g")

    @property
    def electricity_generation_goods_count(self) -> int:
        """
        The number of goods in the economy that are produced by electricity generation sectors. 
        All of those sectors produce electricity, so their output is the same in some sense. However,
        the output of each industry is identified by its own 'good' identifier.

        They are identified by being  members of the `goods_g` set.
        """
        return self.__set_members_count('goods_g')

    @property
    def non_energy_goods_members(self) -> list[str]:
        """
        The list of goods in the economy that are not 
        energy goods (those that are members of the `goods_e` set).
        """
        all_goods_members = self.goods_members
        energy_members = self.energy_goods_members
        result = [x for x in all_goods_members if x not in energy_members]
        return result

    @property
    def non_energy_goods_count(self) -> int:
        """
        The number of goods in the economy that are not 
        energy goods (those that are members of the `goods_e` set).
        """
        return len(self.non_energy_goods_members)

    @property
    def non_electricity_generation_goods_members(self) -> list[str]:
        """
        The list of goods in the economy that are not 
        electricity generation goods (those that are members of the `goods_g` set).
        """
        all_goods_members = self.goods_members
        generation_members = self.electricity_generation_goods_members
        result = [x for x in all_goods_members if x not in generation_members]
        return result

    @property
    def non_electricity_generation_goods_count(self) -> int:
        """
        The number of goods in the economy that are not 
        electricity generation goods (those that are members of the `goods_g` set).
        """
        return len(self.non_electricity_generation_goods_members)

    @property
    def non_energy_or_generation_goods_members(self) -> list[str]:
        """
        The list of goods in the economy that are not energy goods or
        electricity generation goods.
        """
        result = [
            x for x in self.goods_members if x not in self.energy_goods_members]
        result = [
            x for x in result if x not in self.electricity_generation_goods_members]
        return result

    @property
    def non_energy_or_generation_goods_count(self) -> int:
        """
        The number of goods in the economy that are not energy goods or
        electricity generation goods.
        """
        return len(self.non_energy_or_generation_goods_members)

    @property
    def capital_sectors_members(self) -> list[str]:
        """
        The capital sectors that are part of all G-Cubed models. There are two of them:

        1. sector Y, the sector that produces capital for firms.

        2. sector Z, the sector that produces capital for households.

        """
        return ["Y", "Z"]

    @property
    def all_sectors_members(self) -> list[str]:
        """
        The list of all sectors defined in the SYM model definition plus the
        two capital producing sectors that are common to all model versions.
        """
        result = self.__set_members("sectors")
        for capital_sector in self.capital_sectors_members:
            result.append(capital_sector)
        return result

    @property  # numsect # a01,a02, Y and Z for version R of the model
    def all_sectors_count(self) -> int:
        """
        The number of sectors defined in the SYM model definition plus the
        two capital producing sectors that are common to all model versions.
        """
        return len(self.all_sectors_members)
    
    @property
    def sectors_members(self) -> list[str]:
        """
        The list of sectors that are explicitly defined in the SYM model definition. 
        These are the members of the `sectors` set.

        The list does not include the two capital producing sectors 
        that are common to all model versions.
        """
        return self.__set_members("sectors")

    @property  # numsect # a01,a02 for version R of the model
    def sectors_count(self) -> int:
        """
        The number of sectors that are explicitly defined in the SYM model definition. 
        These are the members of the `sectors` set.

        The number does not include the two capital producing sectors 
        that are common to all model versions.
        """
        return self.__set_members_count('sectors')

    @property
    def non_energy_or_generation_sectors_members(self) -> list[str]:
        """
        The list of sectors explicitly defined in the SYM model definition except
        for sectors that are involved in electricity generation or energy.
        """
        return self.sectors_producing(self.non_energy_or_generation_goods_members)

    @property
    def energy_distribution_sectors_members(self) -> list[str]:
        """
        The number of sectors explicitly defined in the SYM model definition except
        for sectors that are involved in electricity generation or energy.

        This is typically just the first sector, in those models that include such a sector.

        """
        return self.__set_members('sec_ed')

    @property
    def electricity_distribution_sectors_count(self) -> int:
        """
        The list of sectors explicitly defined in the SYM model definition that are
        responsible for electricity distribution.
        """        
        return self.__set_members_count('sec_ed')

    @property
    def non_electricity_distribution_sectors_members(self) -> list[str]:
        """
        The list of sectors explicitly defined in the SYM model definition that are
        not responsible for electricity distribution.
        """
        return self.__set_members('sec_std')

    # Note that if there is no electricity distribution sectors, then distribution is lumped in with
    # the more broadly defined energy sector(s).
    @property  # numsecstd
    def non_electricity_distribution_sectors_count(self) -> int:
        """
        The number of sectors explicitly defined in the SYM model definition that are
        not responsible for electricity distribution.
        """
        return self.__set_members_count('sec_std')

    @property
    def regions_members(self) -> list[str]:
        """
        The list of regions explicitly defined in the SYM model definition as part
        of the `regions` set.
        """
        return self.__set_members(
            "regions")

    @property  # countopt
    def regions_count(self) -> int:
        """
        The number of regions explicitly defined in the SYM model definition as part
        of the `regions` set.
        """
        return self.__set_members_count('regions')

    @property
    def us_region(self) -> str:
        """
        The string identifier of the USA region. This must always be the first region
        defined in the SYM `regions` set and it will be the first region in the list
        of region members.
        """
        return self.regions_members[0]

    @property
    def gas_sector_good(self) -> str:
        """
        The string identifier of the good , `g02`, produced by the sector that 
        includes gas extraction and gas utilities. This is the sector associated 
        with gas-related carbon emissions.

        Model versions with more than 2 sectors typically include a gas sector.
        That sector must be the second member of the `sectors` set in the
        model's SYM definition.

        Model version R has 2 sectors, the first is energy, and it is 
        associated with gas, oil and coal. It has no explicit gas sector so it
        has no good associated with such a sector.

        TODO: Add SYM attributes to this good to identify it appropriately so it
        is not order dependent in the SYM definitions.
        """
        match self.configuration.version:
            case '2R':
                return None
            case '20R' |'20J' | '20C' | '6G':
                return self.goods_members[1]
            case _:
                raise Exception(f"GCubed does not yet support model version {self.configuration.version}.")

    @property
    def oil_sector_good(self) -> str:
        """
        The string identifier of the good , `g03`, produced by the petroleum sector. 
        This is the sector associated with oil-related carbon emissions.

        Model that include a petroleum sector must have that sector 
        as the third member of the `sectors` set in the
        model's SYM definition.

        Model version R has 2 sectors, the first is energy, and it is 
        associated with gas, oil and coal. It has no explicit petroleum sector so it
        has no good associated with such a sector.

        TODO: Add SYM attributes to this good to identify it appropriately so it
        is not order dependent in the SYM definitions.
        """
        match self.configuration.version:
            case '2R':
                return None
            case '20R' |'20J' | '20C' | '6G':
                return self.goods_members[2]
            case _:
                raise Exception(f"GCubed does not yet support model version {self.configuration.version}.")

    @property
    def coal_sector_good(self) -> str:
        """
        The string identifier of the good , `g04`, produced by the petroleum sector. 
        This is the sector associated with oil-related carbon emissions.

        Model that include a coal sector must have that sector 
        as the fourth member of the `sectors` set in the
        model's SYM definition.

        Model version R has 2 sectors, the first is energy, and it is 
        associated with gas, oil and coal. It has no explicit coal sector so it
        has no good associated with such a sector.

        TODO: Add SYM attributes to this good to identify it appropriately so it
        is not order dependent in the SYM definitions.
        """        
        match self.configuration.version:
            case '2R':
                return None
            case '20R' |'20J' | '20C' | '6G':
                return self.goods_members[3]
            case _:
                raise Exception(f"GCubed does not yet support model version {self.configuration.version}.")

    @property
    def sector_prefix(self) -> str:
        """
        The first letter of the first sector identifier.
        This is typically `a`.
        """
        return self.sectors_members[0][0]

    @property
    def good_prefix(self) -> str:
        """
        The first letter of the first good identifier.
        This is typically `g`.
        """
        return self.goods_members[0][0]

    def sector_producing(self, good: str) -> str:
        """
        ### Arguments

        `good`: The identifier of the good produced by the sector of interest.

        ### Returns

        the sector identifier for the sector that produces the
        specified good.
        """
        return (self.sector_prefix + good[1:])

    def sectors_producing(self, goods: list[str]) -> str:
        """
        ### Arguments

        `goods`: The list of identifiers of the goods produced by the sectors of interest.

        ### Returns

        the list of sector identifiers for the sectors that produces the
        goods in the supplied list.
        """
        return [self.sector_producing(x) for x in goods]

    def good_produced_by(self, sector: str) -> str:
        """
        ### Arguments

        `sector`: The identifier of the sector that produces the good of interest.

        ### Returns

        the good identifier produced by the specified sector.
        """
        return (self.good_prefix + sector[1:])

    def goods_produced_by(self, sectors: list[str]) -> str:
        """
        ### Arguments

        `sectors`: The list of identifiers of the sectors that produce 
        the goods of interest.

        ### Returns

        the list of good identifiers for the goods produced by the 
        specified sectors.
        """
        return [self.good_produced_by(x) for x in sectors]

    def __vector_length(self, vector_name: str) -> int:
        """
        ### Arguments
        `vector_name`: The name of a LHS or RHS vector in the model.
        
        One of:

        1. x1l or x1r or yxr (all equal to the number of state variables in the model)
        2. j1l or j1r or yjr (all equal to the number of costate variables in the model)
        3. zel or zer or exz (all equal to the number of expected endogenous variables in the model)
        4. z1l or z1r (all equal to the number of other endogenous variables in the model)
        5. exo (equal to the number of exogenous variables in the model)

        ### Returns
        The lengths of various vectors used to express the model equations. 
        These vector lengths are determined from the SYM definition of the model.
        """
        return self._vector_length[vector_name]

    @property  # nxg
    def exogenous_variable_count(self):
        """
        The number of exogenous variables in the model (The length of the EXO vector).
        """
        return self.__vector_length("exogenous_variables")

    @property  # nz and nz1
    def endogenous_variable_count(self):
        """
        The number of endogenous variables in the model (The length of the Z1L, Z1R vectors).
        """
        return self.__vector_length("endogenous_variables")

    @property  # nez
    def expected_endogenous_variable_count(self):
        """
        The number of expected endogenous variables in the model 
        (The length of the ZEL, ZER and EXZ vectors).
        """
        return self.__vector_length("expected_endogenous_variables")

    @property  # njm
    def jump_variable_count(self):
        """
        The number of costate or jump variables in the model 
        (The length of the J1L, J1R and YJR vectors).
        """
        return self.__vector_length("jump_variables")

    @property  # nst
    def state_variable_count(self):
        """
        The number of state variables in the model 
        (The length of the X1L, X1R and XJR vectors).
        """
        return self.__vector_length("state_variables")

    @property  # npar
    def parameter_count(self):
        """
        The number of parameters in the model.
        """
        return self.__vector_length("parameters")

    @property
    # TODO: Consider adding these factors of production (K,L,E,M) to the
    # SYM model definition so they are not hard-coded.
    def factors_of_production_members(self) -> list[str]:
        """
        The four string identifiers of the factors of production:

        1. `K` for capital
        1. `L` for labour
        1. `E` for energy
        1. `M` for material
        """
        return ("K", "L", "E", "M")

    @property
    def factors_of_production_count(self) -> int:
        """
        The number of factors of production (4).
        """
        return len(self.factors_of_production_members)

    @property
    def lhs_vector_names(self) -> list[str]:
        """
        A list of the model's LHS vector names.

        Note the lowercase naming conventions for the lefthand side (LHS) variable vectors:

        1. `x1l` (the vector of state variables) X=S=State
        2. `j1l` (the vector of costate or jump variables) J=C=Costate
        3. `zel` (the endogenous variables LOGY, PRCT, PRID) 
        4. `z1l` (the other endogenous variables)
        """
        return SymData._lhs_vector_names

    @property
    def rhs_vector_names(self) -> list[str]:
        """
        1. S - state - x1r is right hand side (RHS) state variables
        2. J - jump - j1r is RHS costate or jump variables
        3. R - ? - zer is special RHS endogenous variables LOGY, PRCT, PRID that also appear as expected next-period values on the RHS of the equations.
        4. exz is RHS the lead expected R (Expected value in next period of R)
        5.  S_{t-1} yxr is RHS state variables lagged by 1 period
        6. yjr is RHS costate variables lagged by 1 period
        7. exo is exogenous variables (by definition only appearing on RHS)
        8. z1r is RHS other endogenous variables.
        """
        return SymData._rhs_vector_names

    @property
    def ssf_rhs_vector_names(self) -> list[str]:
        """
        4. exz is RHS the lead expected endogenous variables (Expected value in next period of a subset of the endogenous variables)
        5. yxr is RHS state variables lagged by 1 period
        6. yjr is RHS costate variables lagged by 1 period
        7. exo is exogenous variables (by definition only appearing on RHS)
        """
        return SymData._ssf_rhs_vector_names

    @property
    def projection_vector_names(self) -> list[str]:
        return SymData._projection_vector_names

    def vector_length(self, vector_name: str) -> int:
        """
        Argument:

        vector_name: The 3 character acronym identifying the LHS or RHS vector in the model.

        Returns the integer length of the specified vector.
        """
        match vector_name:

            case "z1l" | "z1r":
                return self.endogenous_variable_count

            case "x1l" | "x1r" | "yxr":
                return self.state_variable_count

            case "j1l" | "j1r" | "yjr":
                return self.jump_variable_count

            case "zel" | "zer" | "exz":
                return self.expected_endogenous_variable_count

            case "exo":
                return self.exogenous_variable_count

            case _:
                raise Exception(f"No vector length available for the {vector_name} vector.")

    def vector_variable_names(self, vector_name: str) -> list[str]:
        """
       ### Arguments
        vector_name: the name of the vector

        Returns the SYM ordered fully articulated variable names for the
        variables in the given model vector.

        This is useful for labelling the rows/columns of dataframes containing 
        linear model partial derivatives, and SSF matrices.
        """
        variable_type: str = self.varmap_variable_type(vector_name=vector_name)
        matching_var_type: pd.Series = self.var_map.var_type == variable_type
        result: pd.DataFrame = self.var_map.loc[matching_var_type, ['name', 'sequence']].sort_values('sequence')
        return result.name.to_list()

    @property
    def no_exogenous_variables(self) -> bool:
        """
        Used in place of the swtch variable in the Ox implementation.
        """
        return self.vector_length("exo") == 0

    @property
    def no_jump_variables(self) -> bool:
        """
        Used in place of the swtch variable in the Ox implementation.
        """
        return self.vector_length("j1r") == 0

    @property
    def no_expected_exogenous_variables(self) -> bool:
        """
        Used in place of the swtch variable in the Ox implementation.
        """
        return self.vector_length("zer") == 0

    def __load_varmap(self):
        filename: str = self.configuration.varmap_file
        if not os.path.isfile(filename):
            raise Exception("Could not load parameter listing from " +
                            filename + " because the file does not exist.")
        data: pd.DataFrame = pd.read_csv(filename, header=None)
        data.columns = ['name', 'code', 'var_type', 'sequence', 'name_with_no_punctuation']
        data.index = data.name
        self._variable_map = data

    def __load_varinfo(self):
        filename: str = self.configuration.variables_info_file
        if not os.path.isfile(filename):
            raise Exception("Could not load varinfo from " +
                            filename + " because the file does not exist.")
        data: pd.DataFrame = pd.read_csv(filename, header=None)
        data.columns = ["name", "size", "var_type",
                        "units", "description", "attributes"]
        data.index = data.iloc[:, 0]
        self._variable_information = data

    def __load_optmap(self):
        # TODO: What are the columns of optmap csv file? See column names
        # set below to determine which ones are not yet understood.
        filename: str = self.configuration.opt_map_file
        if not os.path.isfile(filename):
            raise Exception("Could not load optmap from " +
                            filename + " because the file does not exist.")
        data: pd.DataFrame = pd.read_csv(filename, header=None)
        data.columns = ["some_integer", "name_index_combo", "vector_name",
                        "vector_index", "variable_base_name"]
        self._optmap = data

    def __load_model_summary(self):

        # Initialise this dictionary.
        self._sym_sets: dict[str, list[str]] = dict()

        filename: str = self.configuration.model_summary_file
        if not os.path.isfile(filename):
            raise Exception("Could not load model summary from " +
                            filename + " because the file does not exist.")

        # Find all sets and store their name and members in a dictionary of lists,
        # where each list of set members is in the same order as specified in the
        # SYM model definition.
        file = open(filename, 'r')
        lines = file.readlines()

        processing_sets = False
        set_name = None
        set_members = None

        for line in lines:

            if line.isspace():
                set_name = None
                set_members = None

            if 'Parameters:' in line:
                break

            if 'Sets:' in line:
                processing_sets = True
                continue

            if processing_sets:
                stripped_line = line.strip()
                if stripped_line:
                    if set_name is None:
                        set_name = stripped_line
                        continue
                    else:
                        if not line.startswith("         "):
                            continue
                        if set_members is None:
                            set_members: list[str] = stripped_line.split(
                                ',')
                        else:
                            set_members.extend(stripped_line.split(','))
                        if set_members:
                            set_members = [x for x in set_members if x.strip()]
                        self._sym_sets[set_name] = set_members
                        continue

    def __summarise_sym_information(self):
        """
        Analyses the data loaded from the files produced by SYM to populate
        a variety of constants that determine model dimensions etc.
        """
        data: dict[str, any] = dict()
        data["parameters"] = self.__get_vector_size_by_type(
            ["par"])  # npar in Ox
        data["state_variables"] = self.__get_vector_size_by_type(
            ["sta", "stl"])  # nst in Ox
        data["jump_variables"] = self.__get_vector_size_by_type([
            "cos"])  # njm in Ox: for costate variables
        data["expected_endogenous_variables"] = self.__get_vector_size_by_type([
            "ets"])  # nez in Ox
        data["exogenous_variables"] = self.__get_vector_size_by_type([
            "exo"])  # nxg in Ox
        data["endogenous_variables"] = self.__get_vector_size_by_type([
            "end"])  # nz and nz1 in Ox

        self._vector_length = data

    @property
    def parameter_name_prefixes(self) -> list[str]:
        full_parameter_names = (self._variable_information.loc[self._variable_information["var_type"].isin(
            ["par"]), "name"]).to_list()
        parameter_name_prefixes = [re.sub(r'^([^\(]+)($|\(.+$)', '\g<1>', full_parameter_name)
                                   for full_parameter_name in full_parameter_names]
        return parameter_name_prefixes

    def __get_vector_size_by_type(self, types: list[str]):
        """
        TODO: Write unit tests for this functionality.
        Determine the length of various vectors used by the model.

       ### Arguments

        self: The model

        types: a list of types of variables (or parameters)

        Return the sum of the size of each entry in the variable information table with a type matching any of
        the members of the types list.
        """
        return self._variable_information.loc[self._variable_information["var_type"].isin(types), "size"].sum()

    def __validate(self):
        """
        Validates the SYM data about the model.
        """
        # Validate regions
        if self.regions_count < 2:
            raise Exception("The model needs to include at least 2 regions.")
        for region in self.regions_members:
            if not (region[0] == region[1] and region[0].isupper()):
                raise Exception(
                    "The region code must be a pair of identical upper-case letters, not " + region)

        # Validate goods
        if self.goods_count < 2:
            raise Exception("The model needs to include at least 2 goods.")

        # Validate sectors
        if self.sectors_count < 2:
            raise Exception("The model needs to include at least 2 sectors.")
        if self.goods_count != self.sectors_count:
            logging.error(f"The goods are:\n{self.goods_members}")
            logging.error(f"The sectors are:\n{self.sectors_members}")
            raise Exception(f"The number of 'goods', {self.goods_count}, must be equal to the number of sectors, {self.sectors_count}.")

        match self.configuration.version:
            case "2R":
                assert self.sectors_count == 2
            case "6G":
                assert self.sectors_count == 6
            case "20J" | "20C" | "20R":
                assert self.sectors_count == 20
            case _:
                assert self.sectors_count > 6

        # Validate equation vector lengths for LHS and RHS vectors
        assert len(self.lhs_vector_names) == 4
        assert len(self.rhs_vector_names) == 8

    def has_variables(self, variable_name_prefix: str) -> bool:
        """

        ### Overview

        Used to check whether the model includes variables with names that start with the
        supplied prefix. The prefix is matched as a string rather than a regular expression.
        
        ### Arguments

        `variable_name_prefix`: The variable name prefix string.

        ### Returns

        True iff the SYM model definition includes a variable with the given root name.

        """
        return self.var_map.name.str.startswith(variable_name_prefix).any()

    def has_variable(self, variable_name: str) -> bool:
        """

        ### Overview

        Used to check whether the model includes the named variable.
        
        ### Arguments

        `variable_name`: The complete variable name including
        the set qualifier in round brackets (e.g. `INFL(UU)`).

        ### Returns

        True if the SYM model definition includes 
        a variable with the given complete name.

        """
        return (self.var_map.name == variable_name).any()

    def variable_index(self, vector_name: str, variable_name: str) -> int:
        """

        ### Overview

        Used to get the integer index of a variable  in the specified vector.
        
        ### Arguments

        `variable_name`: The complete variable name including
        the set qualifier in round brackets (e.g. `INFL(UU)`).

        ### Returns
        
        The integer indicating the row index of the variable in the given vector.
        Indexing starts from `0`.

        ### Throws

        An exception is thrown if the variable is not in the SYM model.

        An exception is thrown if the named variable is not unique within the SYM model
        though that should not be possible once the SYM processor has run without problems.

        """
        variable_type: str = self.varmap_variable_type(vector_name=vector_name)
        type_matches: list[bool] = self.var_map.var_type == variable_type
        name_matches: list[bool] = self.var_map.name == variable_name
        result = self.var_map.loc[type_matches & name_matches, 'sequence']
        if len(result) == 0:
            raise Exception(
                f"The variable name, {variable_name} is not defined in the SYM model as part of vector {vector_name}.")
        if len(result) != 1:
            raise Exception(
                f"The variable name, {variable_name} must be unique within the SYM model to retrieve its unique index.")
        return int(result.values[0])

    def units_for_variables_with_given_name_prefix(self, vector_name: str, variable_name_prefix: str) -> str:
        """
        ### Arguments

        vector_name: The name of the vector that contains the variable.
        
        variable_name_prefix: The prefix is the set of characters up to but not including the 
        round bracket that starts the full qualification of the variable based on the sets it is
        defined over.

        e.g. use SHL for SHL(region,sector)

        ### Returns
        
        The units of measurement for the variables that match the given name prefix 
        and that are of the variable type associated with the given vector name.
        """
        variable_type: str = self.varmap_variable_type(vector_name=vector_name)
        type_matches: list[bool] = self.var_info.var_type == variable_type
        name_matches: list[bool] = self.var_info.name.str.startswith(f"{variable_name_prefix}(")
        result = self.var_info.loc[type_matches & name_matches, 'units']
        if len(result) == 0:
            raise Exception(
                f"The variable name prefix, {variable_name_prefix}, is not defined in the SYM model as part of vector {vector_name}.")
        if len(result) != 1:
            raise Exception(
                f"The variable name prefix, {variable_name_prefix}, must be unique within the SYM model to retrieve its unique index.")
        return str(result)

    @property
    def intertemporal_constant_variables(self) -> pd.DataFrame:
        """

        ### Overview

        Provides access to the information about the variables that are associated with intertemporal constants.

        The intertemporal constants are used to ensure that jump variables equal to their observed values in the year
        where there is available data (typically the base projection year, one year before the start of projections).

        An intertemporal constant is also used in each WAGE equation to ensure that real interest rates align with nominal 
        interest rates less expected inflation in the next year.

        ### Returns 
        
        A dataframe containing a row per variable that has an intertemporal constant in its equation.
        The dataframe has the following columns:
        * `name` variable name (complete with set identifiers for region/sector etc.)
        * `var_type` variable type (the associated LHS vector name)
        * `sequence` the index of the variable in the associated vector

        """
        if hasattr(self, '_intertemporal_constant_variables'):
            return self._intertemporal_constant_variables

        matches: pd.Series = self.var_map.var_type == 'j1l'
        result: pd.DataFrame = self.var_map.loc[matches, ['name', 'var_type', 'sequence']]

        # Check for the existence of any variables with the given name prefixes and add them 
        # to the results if they are defined in the SYM model.

        for (prefix, vector_name) in Constants().NON_STANDARD_INTERTEMPORAL_CONSTANT_VARIABLE_PREFIXES:
            matches: pd.Series = self.var_map.name.str.startswith(f"{prefix}(") & (self.var_map.var_type == vector_name)
            result: pd.DataFrame = pd.concat([result, self.var_map.loc[matches, ['name', 'var_type', 'sequence']]])            

        result = result.loc[result.name != Constants().REXC_FOR_USA, :]

        result.index = result.name

        self._intertemporal_constant_variables = result
        return self._intertemporal_constant_variables

    @property
    def variables_adjusted_by_intertemporal_constants(self) -> pd.DataFrame:
        """
        ### Overview

        Provides access to the information about the variables that have their values adjusted 
        by the intertemporal constants. Note that this list is slightly different from the 
        list of variables that have intertemporal constants added to their equations in the model
        to match up model projections with observed values at the start of the projections because
        a constant is added to the WAGE equation but it is used to adjust the WAGE equation in a way
        that leads to the required expected price inflation rate.

        ### Returns
        
        A dataframe containing a row per variable that has an intertemporal constant in its equation.
        The dataframe has the following columns:

        * `name` variable name (complete with set identifiers for region/sector etc.)
        * `var_type` variable type (the associated LHS vector name)
        * `sequence` the index of the variable in the associated vector
        """

        if hasattr(self, '_variables_adjusted_by_intertemporal_constants'):
            return self._variables_adjusted_by_intertemporal_constants

        matches: pd.Series = self.var_map.var_type == 'j1l'
        result: pd.DataFrame = self.var_map.loc[matches, ['name', 'var_type', 'sequence']]

        # Check for the existence of any variables with the given name prefixes and add them
        # to the results if they are defined in the SYM model.
        for (prefix, vector_name) in Constants().NON_STANDARD_VARIABLES_ADJUSTED_BY_INTERTEMPORAL_CONSTANTS_PREFIXES:
            matches: pd.Series = self.var_map.name.str.startswith(f"{prefix}(") & (self.var_map.var_type == vector_name)
            result: pd.DataFrame = pd.concat([result, self.var_map.loc[matches, ['name', 'var_type', 'sequence']]])

        result = result.loc[result.name != Constants().REXC_FOR_USA, :]

        result.index = result.name

        result.index = result.name

        self._variables_adjusted_by_intertemporal_constants = result
        return self._variables_adjusted_by_intertemporal_constants

    def __combine_varinfo_varmap(self):
        """

        ### Overview

        Combines the information in the varmap and in the varinfo files generated by sym so that
        we have a single dataframe, indexed by variable name and with a column for each of:

        - Variable name with all set identifiers e.g. GDPN(UU)
        - Variable name prefix e.g. GDPN
        - Variable units as specified in the varinfo. 
        - 'publication_units' - the units code to use when publishing variable projections.
        - Variable description
        - Projection vector that the variable is associated with (j1l, x1l, z1l, zel or exo).
        - Index of the variable in its projection vector (the sequence number accessible from the varmap).
        - Column indicating if it has an intertemporal constant in its equation. Column should be a missing value if not
            and the index of the intertemporal constant if it is.
        - Column indicating if it is the target of an intertemporal constant adjustment. Column should be a missing value if not
            and the index of the intertemporal constant if it is.
        """

        # Get the variable name prefix (everything up to the set specifiers in round brackets - if it exists)
        prefix = self.var_info['name'].apply(lambda x: x.split("(")[0]) # Remove everything from first ( onwards in the variable name.
        dict_units = dict(zip(prefix, self.var_info['units']))
        dict_desc = dict(zip(prefix, self.var_info['description']))
        dict_var_type = dict(zip(prefix, self.var_info['var_type']))
        self._combined_variable_summary = pd.DataFrame(index=self.var_map.index, columns=['prefix', 'units', 'description', 'var_type', 'is_intertemp', 'is_adjusted'])
        self._combined_variable_summary[['name', 'vector_code', 'vector', 'sequence']] = self.var_map[['name', 'code', 'var_type', 'sequence']]
        self._combined_variable_summary.loc[:, 'prefix'] = self._combined_variable_summary['name'].apply(lambda x: x[:x.find('(')])
        self._combined_variable_summary.loc[:, 'units'] = self._combined_variable_summary['prefix'].apply(lambda x: dict_units[x])
        self._combined_variable_summary.loc[:, 'description'] = self._combined_variable_summary['prefix'].apply(lambda x: dict_desc[x])
        self._combined_variable_summary.loc[:, 'var_type'] = self._combined_variable_summary['prefix'].apply(lambda x: dict_var_type[x])
        self._combined_variable_summary.reset_index(drop=True, inplace=True)  # avoid duplicate index

        # Eliminate the parameter entries - we are only interested in the variables.
        self._combined_variable_summary = self._combined_variable_summary.loc[self._combined_variable_summary.var_type != 'par',:]

        # Eliminate redundant vector types
        self._combined_variable_summary = self._combined_variable_summary.loc[self._combined_variable_summary.vector != 'x1r', :]
        self._combined_variable_summary = self._combined_variable_summary.loc[self._combined_variable_summary.vector != 'z1r', :]
        self._combined_variable_summary = self._combined_variable_summary.loc[self._combined_variable_summary.vector != 'j1r', :]
        self._combined_variable_summary = self._combined_variable_summary.loc[self._combined_variable_summary.vector != 'zer', :]
        self._combined_variable_summary = self._combined_variable_summary.loc[self._combined_variable_summary.vector != 'yjr', :]
        self._combined_variable_summary = self._combined_variable_summary.loc[self._combined_variable_summary.vector != 'yxr', :]
        self._combined_variable_summary = self._combined_variable_summary.loc[self._combined_variable_summary.vector != 'exz', :]

        # Set the index of the combined variable summary dataframe to be the variable names (with set specifiers)
        self._combined_variable_summary.index = self._combined_variable_summary.name

        # Add a boolean column that is true iff the variable has an intertemporal constant
        self._combined_variable_summary['is_intertemp'] = False
        self._combined_variable_summary.loc[self.intertemporal_constant_variables.index, 'is_intertemp'] = True

        # Add a boolean column that is true iff the variable has its initial value adjusted to observed value by an intertemporal constant
        self._combined_variable_summary['is_adjusted'] = False
        self._combined_variable_summary.loc[self.variables_adjusted_by_intertemporal_constants.index, 'is_adjusted'] = True

        # Create the publication units column
        self._combined_variable_summary['publication_units'] = self._combined_variable_summary.loc[:, 'units']
        self._combined_variable_summary.loc[self._combined_variable_summary.units == 'usgdp', 'publication_units'] = '$US Bil'
        self._combined_variable_summary.loc[self._combined_variable_summary.units == 'gdp', 'publication_units'] = '$US Bil'
        self._combined_variable_summary.loc[self._combined_variable_summary.units == 'mmtusgdp', 'publication_units'] = 'mmt'
        self._combined_variable_summary.loc[self._combined_variable_summary.units == 'mmtgdp', 'publication_units'] = 'mmt'
        self._combined_variable_summary.loc[self._combined_variable_summary.units == 'btuusgdp', 'publication_units'] = 'btu'
        self._combined_variable_summary.loc[self._combined_variable_summary.units == 'btugdp', 'publication_units'] = 'btu'
        self._combined_variable_summary.loc[self._combined_variable_summary.units == 'gwhgdp', 'publication_units'] = 'gwh'
        self._combined_variable_summary.loc[self._combined_variable_summary.units == 'del', 'publication_units'] = 'del'
        self._combined_variable_summary.loc[self._combined_variable_summary.units == 'pct', 'publication_units'] = 'pct'

    @property
    def combined_variable_summary(self) -> pd.DataFrame:
        """

        ### Overview

        This summary dataframe of the SYM information about variables 
        should be used to drive a lot of the 
        variable filtering during model processing.

        The rows of the dataframe are the variable names.

        The columns of the dataframe are:

        * `name` - the full name of the variable
        * `prefix` - the name prefix - up to the open bracket.
        * `units` - the units code.
        * `publication_units` - the units code to use when publishing variable projections.
        * `description` - the description
        * `var_type` - one of:
            - `par` = parameter
            - `ets` = expected next-period value of an endogenous variable
            - `end` = endogenous
            - `sta` = state
            - `stl` = lead state variable
            - `exo` = exogenous
            - `cos` = costate or jump
        * `vector` - the vector name e.g. `z1l`, `yxr`, `exo` etc.
        * `vector_code` - the vector name and index combination - e.g. `exo[3]`.
        * `sequence` - the index in the vector that corresponds to the variable - e.g `3`.
        * `is_intertemp` - the index of the variable in the vector of intertemporal constants (or NaN)
        * `is_adjusted` - the index of the variable in the vector of variables being adjusted by intertemporal constants (or NaN)

        ### Returns
        
        The combined variable summary dataframe.

        """
        return self._combined_variable_summary
    
    def variable_units(self, variable_name: str) -> int:
        """
        ### Arguments

        variable_name: The full name of the variable.

        ### Returns
         
        The units of measurement for the variable with the given name.

        ### Throws

        Exception if the named variable is not in the model.

        """
        try:
            return self.combined_variable_summary.loc[[variable_name], 'units']
        except:
            raise Exception(f"{variable_name} does not appear to be the full name of a variable in the model.")

    def variable_publication_units(self, variable_name: str) -> int:
        """
        ### Arguments

        variable_name: The full name of the variable.

        ### Returns
         
        The publication units of measurement for the variable with the given name.

        ### Throws

        Exception if the named variable is not in the model.

        """
        try:
            return self.combined_variable_summary.loc[[variable_name], 'publication_units']
        except:
            raise Exception(f"{variable_name} does not appear to be the full name of a variable in the model.")
        

    def variable_var_type(self, variable_name: str) -> int:
        """
        ### Arguments

        variable_name: The full name of the variable.

        ### Returns
         
        The variable type of the vector that the variable is in. One of:
        
        - `par` = parameter
        - `ets` = expected next-period value of an endogenous variable
        - `end` = endogenous
        - `sta` = state
        - `stl` = lead state variable
        - `exo` = exogenous
        - `cos` = costate or jump

        ### Throws

        Exception if the named variable is not in the model.

        """
        try:
            return str(self.combined_variable_summary.loc[[variable_name], 'var_type'].values[0])
        except:
            raise Exception(f"{variable_name} does not appear to be the full name of a variable in the model.")
        
    def is_exogenous(self, variable_name: str) -> int:
        """
        ### Arguments

        variable_name: The full name of the variable.

        ### Returns
         
        `True` if the variable is exogenous and `False` otherwise.

        ### Throws

        Exception if the named variable is not in the model.

        """
        try:
            return self.variable_var_type(variable_name=variable_name) == 'exo'
        except:
            raise Exception(f"{variable_name} does not appear to be the full name of a variable in the model.")
        
    def is_state(self, variable_name: str) -> int:
        """
        ### Arguments

        variable_name: The full name of the variable.

        ### Returns
         
        `True` if the variable is a state or lead state variable and `False` otherwise.

        ### Throws

        Exception if the named variable is not in the model.

        """
        try:
            match self.variable_var_type(variable_name=variable_name):
                case 'sta' | 'stl':
                    return True
                case _:
                    return False
        except:
            raise Exception(f"{variable_name} does not appear to be the full name of a variable in the model.")

    def is_adjustable_in_simulations(self, variable_name: str) -> int:
        """
        ### Arguments

        variable_name: The full name of the variable.

        ### Returns
         
        `True` if the variable can be adjusted in a simulation layer
        and `False` otherwise.

        ### Throws

        Exception if the named variable is not in the model.

        """
        try:
            match self.variable_var_type(variable_name=variable_name):
                case 'sta' | 'stl' | 'exo':
                    return True
                case _:
                    return False
        except:
            raise Exception(f"{variable_name} does not appear to be the full name of a variable in the model.")

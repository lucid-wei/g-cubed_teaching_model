"""
Projection functionality package.
"""
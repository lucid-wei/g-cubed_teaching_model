"""
Projection functionality package.
"""
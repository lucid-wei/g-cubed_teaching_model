# ------------------------------------------------------------------
# Purpose: Compute and provide access to simulations that overlay
# baseline projections and possibly other simulation layers.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
"""
Contains the SimulationLayer class, for doing 
projections for a single simulation layer.
"""
import logging
import os
import pandas as pd
import numpy as np
from gcubed.constants import Constants
from gcubed.data.database import Database
from gcubed.projections.projections import Projections
from gcubed.projections.baseline_projections import BaselineProjections
from gcubed.projections.simulation_layer_definition import SimulationLayerDefinition

class SimulationLayer(Projections):
    """
    TODO: Complete the simulations implementation
    Compute model simulations over the projection horizon.
    """

    def __init__(self, simulation_layer_definition: SimulationLayerDefinition, previous_projections: Projections) -> None:
        """

        ### Constructor

        Use this constructor for any simulation that is the first simulation layer applied to baseline projections.

        ### Arguments

        simulation_layer_definition: The definition of this simulation layer

        previous_projections: The projections that this simulation layer builds upon, baseline or another type.

        """
        assert previous_projections is not None
        self._baseline_projections = previous_projections if isinstance(previous_projections, BaselineProjections) else previous_projections.baseline_projections

        super().__init__(stable_manifold=self.baseline_projections.stable_manifold)
        self._is_baseline_projections = False
        self._previous_projections = previous_projections

        assert simulation_layer_definition is not None
        self._simulation_layer_definition = simulation_layer_definition

        if self.previous_projections is not None:
            assert self.first_projection_year >= self.previous_projections.first_projection_year
        else:
            assert self.first_projection_year >= self.baseline_projections.first_projection_year
        self._first_projection_year = self.definition.event_year

        assert os.path.isfile(self.definition.data_filename)
        self.__load_simulation_data()

        self._generate_projections()

        # Store long rate adjustment constants to use in creating the database projections
        self._long_rate_constants = self.baseline_projections._long_rate_constants
        self._generate_database_projections()

        self._generate_publishable_projections()

        self.__validate()

    def __validate(self):
        """
        TODO:  Validate the simulations: 
        """
        logging.info(f"The {self.definition.name} projections have been generated.")

    @property
    def baseline_projections(self) -> BaselineProjections:
        """
        The baseline projections.
        """
        return self._baseline_projections

    @property
    def definition(self) -> SimulationLayerDefinition:
        """
        The definition for this simulation layer, giving access to the information
        about the simulation being done in this layer.
        """
        return self._simulation_layer_definition

    @property
    def baseline_projections(self) -> BaselineProjections:
        """
        Returns the baseline projections underpinning this simulation
        """
        return self._baseline_projections

    @property
    def database(self) -> Database:
        """
        Returns the database associated with the baseline projections.
        """
        return self.baseline_projections.database

    @property
    def simulation_variables(self) -> pd.DataFrame:
        """
        Returns the variable summary information for the simulation data.
        """
        return self._simulation_variables

    @property
    def simulation_data(self) -> pd.DataFrame:
        """
        Returns the simulation data.
        """
        return self._simulation_data

    def __load_simulation_data(self):
        """        
        Load and apply the simulation data that affect exogenous variables. 

        Load and apply the simulation data that affect state variables initial values.

        TODO: Check if there are simulations where shocks to state variable initial values are not allowed.

        When a variable has data in the simulation file, load that into the appropriate 
        SYM-specified row of the exogenous variable projections, from the start projection year onwards.

        When a variable has data in the simulation file (control.csv by default), load that into the appropriate 
        SYM-specified row of the state variable projection start year vector and ignore
        data in the control file for all years after that projection start year.

        Adjust the simulation data as follows, depending on the units of the variable:
            gdp - multiply by (projection base year YRATR / 100).
            mmgdp - same as gdp
            btugdp - same as gdp 
            gwhgdp - same as gdp
            usgdp - divide the value in the control file by 100.
            All other units - divide the value in the control file by 100.
        """

        # Load the simulation data.
        filename: str = self.definition.data_filename
        assert os.path.isfile(filename)
        (self._simulation_variables, self._simulation_data) = self.load_data(filename)
        if len(self._simulation_variables.index) == 0:
            logging.warn(f"The '{self.definition.name}' simulation layer has no data. This will run but is not doing anything useful.")
        self._simulation_variables.columns = ['name']
        self._simulation_variables.index = self._simulation_variables.name
        self._simulation_data = self._simulation_data.astype(float)
        self._simulation_data.index = self._simulation_variables.name

        try:
            self._simulation_data = self._simulation_data.loc[:, self.projection_years_column_labels]
        except:
            raise Exception(f"The simulation data in {self.definition.data_file} should include data values from {self.first_projection_year} to {self.last_projection_year}")

        # Iterate the shocks, allocating the shocks
        yratr: pd.DataFrame = self.database.get_data(name_regular_expression=f"^{Constants().US_REAL_GDP_RATIO_PREFIX}\(", years=[self.configuration.original_first_projection_year])
        yratr.index = self.sym_data.regions_members

        self._exo_projections = self.previous_projections.exo_projections_as_dataframe.loc[:, self.projection_years_column_labels]
        
        self._yxr_initial_values: pd.DataFrame = self.previous_projections.yxr_projections_as_dataframe.loc[:, [str(self.first_projection_year)]].copy()

        for variable_name in self._simulation_variables.index:
            variable_region: str = str(self.baseline_projections.database.variables.loc[variable_name, 'region'])
            variable_units: str = str(self.sym_data.combined_variable_summary.loc[variable_name, 'units'])
            data: pd.DataFrame = self._simulation_data.loc[[variable_name], :] / 100
            vector_name = self.sym_data.projection_vector_for_variable(variable_name=variable_name)
            yratr_for_region: float = float(yratr.loc[variable_region, :].values[0])
            match variable_units:
                case 'gdp' | 'mmgdp' | 'btugdp' | 'gwhgdp':
                    data *= yratr_for_region
                case _:
                    pass

            match vector_name:
                case 'exo':
                    logging.info(f"Augmenting exogenous variables, {variable_name}, from {self.first_projection_year} on.")
                    self._exo_projections.loc[[variable_name], self.projection_years_column_labels] += data
                    pass

                case 'x1l':
                    logging.info(f"Augmenting initial state variables, {variable_name}, in {self.first_projection_year}")
                    self._yxr_initial_values.loc[[variable_name], [str(self.first_projection_year)]] += float(data[0])
                    pass

    @property
    def h3t(self) -> np.ndarray:
        """
        Equivalent to h3t in the Ox implementation
        Functions of current and future exogenous variables affecting J1.
        """
        return self._h3t

    @property
    def c4t(self) -> np.ndarray:
        """
        Equivalent to c4t in the Ox implementation
        Functions of current and future exogenous variables affecting ZE.
        """
        return self._c4t


    @property
    def x1_constants(self) -> np.ndarray:
        """
        The constant adjustments to X1 to ensure projections equal observed values
        in the original base projection year.
        """
        return self.baseline_projections.x1_constants

    @property
    def j1_constants(self) -> np.ndarray:
        """
        The constant adjustments to J1 to ensure projections equal observed values
        in the original base projection year.
        """
        return self.baseline_projections.j1_constants

    @property
    def ze_constants(self) -> np.ndarray:
        """
        The constant adjustments to ZE to ensure projections equal observed values
        in the original base projection year.
        """
        return self.baseline_projections.ze_constants

    @property
    def z1_constants(self) -> np.ndarray:
        """
        The constant adjustments to Z1 to ensure projections equal observed values
        in the original base projection year.
        """
        return self.baseline_projections.z1_constants

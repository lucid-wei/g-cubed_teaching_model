# ------------------------------------------------------------------
# Purpose: Description of a simulation layer
# Author: Geoff Shuetrim
# ------------------------------------------------------------------

import logging
import os
import os.path
from gcubed.base import Base
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData


class SimulationLayerDefinition(Base):
    """
    Sets up and checks metadata about a simulation layer
    """

    def __init__(self, sym_data: SymData, name: str, event_year: int, data_filename: str, description: str) -> None:
        """
       ### Arguments

        baseline_projections: The baseline projections that this simulation layer will be applied to.
        
        name: the name of the simulation layer
        
        event_year: YYYY format integer that is the year that the simulation layer details became
        known to the agents in the model.
        
        filename: The full filename of the file containing the simulation layer data.
        
        description: The text explanation of the simulation layer.
        
        """

        assert sym_data is not None
        self._sym_data = sym_data

        assert name is not None
        self._name = name

        assert description is not None
        self._description = description

        assert event_year is not None
        self._event_year = event_year
        assert self.event_year >= self.configuration.original_first_projection_year
        assert self.event_year <= 9999

        assert data_filename is not None
        self._data_filename = data_filename
        if not os.path.isfile(self.data_filename):
            raise Exception(f"Simulation data file {self.data_filename} does not exist.")

        # The next simulation layer definition in the ordered list of simulation layer definitions.
        # Initialise to None and update when this simulation layer definition is added to the list.
        self.next = None

        (variables, data) = self.load_data(self.data_filename)
        data.index = variables.name
        data_first_year: int = int(data.columns[0])

        if self.event_year < self.configuration.first_projection_year:
            raise Exception(f"The '{self.name}' simulation layer event year, {self.event_year}, must not be less than the first projection year {self.configuration.first_projection_year} of the baseline projections.")

        if not self.event_year == data_first_year:
            logging.warning(f"The data for simulation {self.name} does not start with the specified event year, {self.event_year}. It starts at {data_first_year}")

        data_last_year: int = int(data.columns[-1])
        if self.configuration.last_projection_year > data_last_year:
            raise Exception(f"The data for simulation {self.name} does not extend to the end projection year, {self.configuration.last_projection_year}. It ends at {data_last_year}")
        if not self.configuration.last_projection_year == data_last_year:
            logging.warning(f"The data for '{self.name}' does not end at the end projection year, {self.configuration.last_projection_year}. It ends at {data_last_year}.")

        for variable_name in variables.name:
            if not self.sym_data.has_variable(variable_name=variable_name):
                raise Exception(f"The data for simulation {self.name} includes a variable {variable_name} that is not in the model.")

    def __str__(self):
        return f"Simulation layer {self.name} with event year {self.first_projection_year}: {self.description}.\nData is in {self.data_filename}"

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return self._description

    @property
    def event_year(self) -> str:
        return self._event_year

    @property
    def data_filename(self) -> str:
        return self._data_filename

    @property
    def sym_data(self) -> SymData:
        return self._sym_data

    @property
    def configuration(self) -> ModelConfiguration:
        return self.sym_data.configuration

# ------------------------------------------------------------------
# Purpose: Compute and provide access to relinearisation projections.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
"""
Contains the RelinearisationProjections class, for doing projections
after relinearising a model, and making adjustments for any simulation layers
that impact on the relinearisation year.

The adjustments are made to fit constants based on the original projection first year.
"""
import logging
import os
import pandas as pd
import numpy as np
from gcubed.constants import Constants
from gcubed.sym_data import SymData
from gcubed.model_parameters.parameters import Parameters
from gcubed.model_configuration import ModelConfiguration
from gcubed.model import Model
from gcubed.linearisation.linear_model import LinearModel
from gcubed.linearisation.stable_manifold import StableManifold
from gcubed.linearisation.state_space_form import StateSpaceForm
from gcubed.data.gdp_scaled_database import GDPScaledDatabase
from gcubed.projections.model_updater import ModelUpdater
from gcubed.projections.projections import Projections
from gcubed.projections.baseline_projections import BaselineProjections
from gcubed.projections.simulation_layer_definitions import SimulationLayerDefinitions
from gcubed.projections.simulation_layer_definition import SimulationLayerDefinition

class RelinearisationProjections(Projections):
    """
    Compute the relinearisation model projections over the projection horizon 
    from the base projection year (the last year with available data)
    through to the last projection year.
    """

    def __init__(self, 
                 baseline_projections: BaselineProjections, 
                 previous_projections: Projections, 
                 relinearisation_year: int, 
                 simulation_layer_definitions: SimulationLayerDefinitions = [],
                 relinearise_around_the_neutral_real_interest_rate:bool = True) -> None:
        """

        ### Constructor

        Creates relinearisation projections for the specified new base year.

        ### Arguments

        baseline_projections: The baseline projections.

        previous_projections: The previous projections.

        relinearisation_year: The year that the relinearisation is being done.

        simulation_layer_definitions: 
        An optional input that provides an ordered list of simulation layer 
        definitions that can be used to augment the initial state vector and 
        the exogenous variable projections that underpin the projections. 
        The simulation layers are ignored if they have an event year that 
        is not equal to the base projection year. This parameter defaults to
        an empty list.

        relinearise_around_neutral_real_interest_rate: `True` if the relinearisation
        is done around the neutral real interest rate and `False` if it is done around
        previous projection values in the relinearisation year. 
        This parameter defaults to `True`.
        """

        logging.info(f"Relinearising the model starting from {relinearisation_year}.")

        # Store the baseline projections
        assert baseline_projections is not None
        self._baseline_projections = baseline_projections

        # Store the simulation layer definitions (if any were provided.)
        self._simulation_layer_definitions = simulation_layer_definitions

        self._relinearise_around_the_neutral_real_interest_rate = relinearise_around_the_neutral_real_interest_rate

        # Update the model from the old projections, changing the model 
        # configuration's first projection year and augmenting the database 
        # for the model to include values from the old projections for each 
        # of the projection years out to the last projection year.
        my_previous_projections: Projections = previous_projections if previous_projections is not None else baseline_projections
        new_model: Model = ModelUpdater.get_updated_model(projections=my_previous_projections, new_first_projection_year=relinearisation_year)
        assert new_model.configuration.first_projection_year == relinearisation_year
        assert new_model.configuration.linearisation_year == relinearisation_year

        # Copy across the long rate constants from the baseline projections.
        self._long_rate_constants: pd.DataFrame = self.baseline_projections.long_rate_constants

        # Relinearise the updated model around the new projection base year to get the revised stable manifold.
        linear_model: LinearModel = LinearModel(
            model=new_model, 
            use_neutral_real_interest_rate=self.relinearise_around_the_neutral_real_interest_rate)
        state_space_form: StateSpaceForm = StateSpaceForm(linear_model=linear_model)
        stable_manifold: StableManifold = StableManifold(state_space_form=state_space_form)
        super().__init__(stable_manifold=stable_manifold)
        self._is_baseline_projections = False
        self._previous_projections: Projections = my_previous_projections

        self._database = GDPScaledDatabase(database=new_model.database, base_year=self.configuration.base_year)

        self.populate_exogenous_projections_and_initial_state_vector()

        # Relinearisation constants calculation process done in this section
        self.__compute_constant_adjustments()

        self._generate_projections()

        self._generate_database_projections()

        self._generate_publishable_projections()

        self.__validate()

    def __validate(self):
        """
        ### Overview

        Perform any necessary validations on the relinearised projections.
        """
        logging.info(f"The {self.first_projection_year} relinearised projections have been generated.")
    
    @property
    def stable_manifold(self) -> StableManifold:
        """
        The stable manifold after doing the relinearisation.
        """
        return self._stable_manifold

    @property
    def state_space_form(self) -> StateSpaceForm:
        """
        The state-space form after doing the relinearisation.
        """
        return self.stable_manifold.ssf

    @property
    def model(self) -> Model:
        """
        The model to relinearise.
        """
        return self.state_space_form.model

    @property
    def sym_data(self) -> SymData:
        """
        The SYM generated data about the model.
        """
        return self.model.sym_data

    @property
    def parameters(self) -> Parameters:
        """
        The calibrated model parameters.
        """
        return self.model.parameters

    @property
    def configuration(self) -> ModelConfiguration:
        """
        The model configuration.
        """
        return self.sym_data.configuration

    @property
    def database(self) -> GDPScaledDatabase:
        """
        The database used for the relinearisation and projections.
        """
        return self._database

    @property
    def baseline_projections(self) -> BaselineProjections:
        """
        The baseline projections that this relinearisation projections builds upon.
        """
        return self._baseline_projections

    @property
    def simulation_layer_definitions(self) -> SimulationLayerDefinitions:
        """
        The list of simulation layer definitions, in their appropriate order
        from the first to be applied to the last to be applied.
        """
        return self._simulation_layer_definitions

    @property
    def relinearise_around_the_neutral_real_interest_rate(self) -> bool:
        """
        `True` if  relinearisations are around the neutral real interest rate
        and `False` if they are around previous projection values
        in the relinearisation year.
        """
        return self._relinearise_around_the_neutral_real_interest_rate
    
    def populate_exogenous_projections_and_initial_state_vector(self):
        """

        ### Overview

        Load exogenous variable projections and initial state vector values
        from the previous projections.

        For any simulation layer definition with its event year equal to the base
        year for this projections, augment the exogenous variables and state
        vector with supplied simulation layer data.
        """

        self._exo_projections = self.previous_projections.exo_projections.copy()

        self._yxr_initial_values: pd.DataFrame = self.previous_projections.yxr_projections_as_dataframe.loc[:, [str(self.first_projection_year)]].copy()

        for simulation_layer_definition in self.simulation_layer_definitions:
            self.__apply_simulation_layer(simulation_layer_definition=simulation_layer_definition)

    def __apply_simulation_layer(self, simulation_layer_definition: SimulationLayerDefinition):
        """
        ### Overview

        Applies adjustments to exogenous variables and any state 
        variables for the given simulation layer.
        """
        if simulation_layer_definition.event_year != self.first_projection_year:
            return

        filename: str = simulation_layer_definition.data_filename
        assert os.path.isfile(filename)
        (simulation_variables, simulation_data) = self.load_data(filename)
        simulation_data = simulation_data.astype(float)
        simulation_variables.columns = ['name']
        simulation_variables.index = simulation_variables.name
        simulation_data.index = simulation_variables.name
        try:
            simulation_data = simulation_data.loc[:, self.configuration.projection_years_column_labels]
        except:
            raise Exception(f"The simulation data in {self.simulation_file} should have data from {self.first_projection_year} to {self.last_projection_year}")
        yratr: pd.DataFrame = self.baseline_projections.database.get_data(name_regular_expression=f"^{Constants().US_REAL_GDP_RATIO_PREFIX}\(", years=[self.configuration.original_first_projection_year])
        yratr.index = self.sym_data.regions_members

        for variable_name in self._simulation_variables.index:
            variable_region: str = str(self.database.variables.loc[variable_name, 'region'])
            units_for_variables_with_given_name_prefix: str = str(self.sym_data.combined_variable_summary.loc[variable_name, 'units'])
            data: pd.DataFrame = simulation_data.loc[[variable_name], :] / 100
            vector_name = self.sym_data.projection_vector_for_variable(variable_name=variable_name)
            yratr_for_region: float = float(yratr.loc[variable_region, :].values[0])
            match units_for_variables_with_given_name_prefix:
                case 'gdp' | 'mmgdp' | 'btugdp' | 'gwhgdp':
                    data *= yratr_for_region
                case _:
                    pass

            match vector_name:
                case 'exo':
                    self._exo_projections.loc[[variable_name], self.projection_years_column_labels] += data
                    pass

                case 'x1l':
                    self._yxr_initial_values.loc[[variable_name], [str(self.first_projection_year)]] += float(data[0])
                    pass

    @property
    def x1_constants(self) -> np.ndarray:
        """
        The constant adjustments to X1 to ensure projections equal observed values
        in the original base projection year.
        """
        return self.baseline_projections.x1_constants

    @property
    def j1_constants(self) -> np.ndarray:
        """
        The constant adjustments to J1 to ensure projections equal observed values
        in the original base projection year.
        """
        return self.baseline_projections.j1_constants

    @property
    def ze_constants(self) -> np.ndarray:
        """
        The constant adjustments to ZE to ensure projections equal observed values
        in the original base projection year.
        """
        return self.baseline_projections.ze_constants

    @property
    def z1_constants(self) -> np.ndarray:
        """
        The constant adjustments to Z1 to ensure projections equal observed values
        in the original base projection year.
        """
        return self.baseline_projections.z1_constants
    
    #####################################################################################
    # Constant calculation functionality after here
    #####################################################################################

    def __compute_constant_adjustments(self):
        """
        ### Overview

        We already have the original first projection year database values
        for all vectors and for the variables that are adjusted by intertemporal 
        variables. They are all accessible from the baseline projections.

        Step 1.
        Compute SSF raw projections in the original first projection year minus
        the values for those projected variable vectors in the database for
        that original first projection year. These will differ from those produced
        in the baseline because the relinearisation will have changed the 
        state space form of the model.

        Step 2.
        Compute the intertemporal constants.

        """

        # Step 1.
        self.__compute_original_first_projection_year_ssf_deviations_from_observed_values()

        # Step 2.
        self.__calculate_intertemporal_constants()

    def __compute_original_first_projection_year_ssf_deviations_from_observed_values(self):
        """
        ### Overview

        Step 1.
        Calculate the  values for the LHS vectors  in  the
        original first projection year using the relinearised
        state space form of the model. This uses the RHS vectors
        for the first projection year associated with the 
        baseline projections (NOT THESE RELINEARISED PROJECTIONS.)

        and 

        Step 2.
        Calculate the differences between the database values for the RHS vectors
        `x1r`, `j1r`, `zer`, and `z1r` and the values computed in Step 1. Store these
        as properties of the class instance. They become constant adjustments that are
        used in the projection process to ensure that the database values in 
        the first projection year match the baseline projections of those values.

        The differences are preserved as the database values minus projections.
        """

        # Step 1.
        x1l_ssf_calculations_using_first_projection_year_data = self.state_space_form.delta('x1l', 'yxr') @ self.baseline_projections.first_projection_year_yxr + \
            self.state_space_form.delta('x1l', 'yjr') @ self.baseline_projections.first_projection_year_yjr + \
            self.state_space_form.delta('x1l', 'exz') @ self.baseline_projections.first_projection_year_exz + \
            self.state_space_form.delta('x1l', 'exo') @ self.baseline_projections.first_projection_year_exo

        j1l_ssf_calculations_using_first_projection_year_data = self.state_space_form.delta('j1l', 'yxr') @ self.baseline_projections.first_projection_year_yxr + \
            self.state_space_form.delta('j1l', 'yjr') @ self.baseline_projections.first_projection_year_yjr + \
            self.state_space_form.delta('j1l', 'exz') @ self.baseline_projections.first_projection_year_exz + \
            self.state_space_form.delta('j1l', 'exo') @ self.baseline_projections.first_projection_year_exo

        zel_ssf_calculations_using_first_projection_year_data = self.state_space_form.delta('zel', 'yxr') @ self.baseline_projections.first_projection_year_yxr + \
            self.state_space_form.delta('zel', 'yjr') @ self.baseline_projections.first_projection_year_yjr + \
            self.state_space_form.delta('zel', 'exz') @ self.baseline_projections.first_projection_year_exz + \
            self.state_space_form.delta('zel', 'exo') @ self.baseline_projections.first_projection_year_exo

        z1l_ssf_calculations_using_first_projection_year_data = self.state_space_form.delta('z1l', 'yxr') @ self.baseline_projections.first_projection_year_yxr + \
            self.state_space_form.delta('z1l', 'yjr') @ self.baseline_projections.first_projection_year_yjr + \
            self.state_space_form.delta('z1l', 'exz') @ self.baseline_projections.first_projection_year_exz + \
            self.state_space_form.delta('z1l', 'exo') @ self.baseline_projections.first_projection_year_exo

        # Step 2.
        self._x1r_difference_from_ssf = self.baseline_projections.first_projection_year_x1r - x1l_ssf_calculations_using_first_projection_year_data  # t+1 = year after base year
        self._j1r_difference_from_ssf = self.baseline_projections.first_projection_year_j1r - j1l_ssf_calculations_using_first_projection_year_data  # t+1 = year after base year
        self._zer_difference_from_ssf = self.baseline_projections.first_projection_year_zer - zel_ssf_calculations_using_first_projection_year_data  # t = base year
        self._z1r_difference_from_ssf = self.baseline_projections.first_projection_year_z1r - z1l_ssf_calculations_using_first_projection_year_data  # t = base year

    @property
    def x1r_difference_from_ssf(self):
        """
        The original first projection year 
        difference between the database values of `x1r`
        and the raw baseline projections of those values,
        without making any constant adjustments at all.

        These differences are added to the constants that
        are used in the baseline projections to ensure that
        the projections in the first projection year match
        the database values in that year.
        """
        return self._x1r_difference_from_ssf

    @property
    def j1r_difference_from_ssf(self):
        """
        The original first projection year 
        difference between the database values of `j1r`
        and the raw baseline projections of those values,
        without making any constant adjustments at all.

        These differences are added to the constants that
        are used in the baseline projections to ensure that
        the projections in the first projection year match
        the database values in that year.

        """
        return self._j1r_difference_from_ssf

    @property
    def zer_difference_from_ssf(self):
        """
        The original first projection year 
        difference between the database values of `zer`
        and the raw baseline projections of those values,
        without making any constant adjustments at all.

        These differences are added to the constants that
        are used in the baseline projections to ensure that
        the projections in the first projection year match
        the database values in that year.
        """
        return self._zer_difference_from_ssf

    @property
    def z1r_difference_from_ssf(self):
        """
        The original first projection year 
        difference between the database values of `z1r`
        and the raw projections of those values,
        without making any constant adjustments at all.

        These differences are added to the constants that
        are used in the baseline projections to ensure that
        the projections in the first projection year match
        the database values in that year.
        """
        return self._z1r_difference_from_ssf
    

    def __evaluate_first_projection_year_vector_projections(self):
        """
        Computes the values of the model equation vectors in the original 
        first projection year, using the functions of future exogenous variables, 
        the stable manifold, etc based on the relinearised model.
        """

        self._exo_first_year_projections: np.ndarray = self.exo_projections.loc[:, [str(self.first_projection_year)]].to_numpy()

        self._yxr_first_year_projections: np.ndarray = self.yxr_initial_values.to_numpy().copy()

        # er = h1t*x[][1] + h2t*exog[][1] + h3t[][1];
        self._yjr_first_year_projections: np.ndarray = \
            self.stable_manifold.H1 @ self.yxr_first_year_projections + \
            self.stable_manifold.H2 @ self.exo_first_year_projections + \
            self._h3t[:, [0]]

        # tzl = mu1t*x[][1] + mu4t*exog[][1] + c4t[][1];
        self._exz_first_year_projections: np.ndarray = \
            self.stable_manifold.mu1 @ self.yxr_first_year_projections + \
            self.stable_manifold.mu2 @ self.exo_first_year_projections + \
            self._c4t[:, [0]]

        # z1l projections = d5n*x[][1]+d7n*exog[][1]+d6n*er+d4n*tzl+cz6[][1]
        self._z1l_first_year_projections: np.ndarray = \
            self.state_space_form.delta('z1l', 'yxr') @ self.yxr_first_year_projections + \
            self.state_space_form.delta('z1l', 'exo') @ self.exo_first_year_projections + \
            self.state_space_form.delta('z1l', 'yjr') @ self.yjr_first_year_projections + \
            self.state_space_form.delta('z1l', 'exz') @ self.exz_first_year_projections + \
            self.z1r_difference_from_ssf

    @property
    def yxr_first_year_projections(self) -> np.ndarray:
        """
        Projections of X1_t (yxr) in the first projection year
        """
        return self._yxr_first_year_projections

    @property
    def yjr_first_year_projections(self) -> np.ndarray:
        """
        Projections of J1_t (yjr) in the first projection year
        """
        return self._yjr_first_year_projections

    @property
    def exz_first_year_projections(self) -> np.ndarray:
        """
        Projections of ZE_t (exz) in the first projection year
        """
        return self._exz_first_year_projections

    @property
    def z1l_first_year_projections(self) -> np.ndarray:
        """
        Projections of Z1_t (z1l=z1r) in the first projection year
        """
        return self._z1l_first_year_projections

    @property
    def exo_first_year_projections(self) -> np.ndarray:
        """
        Projections of EXO_t in the first projection year
        """
        return self._exo_first_year_projections

    @property
    def first_year_original_projections_of_variables_adjusted_by_intertemporal_constants(self) -> np.ndarray:
        """
        The first year projected values for the variables that are being
        adjusted by the intertemporal constants.

        The values are those for the projection that is not adjusted by intertemporal constants.

        It is used in the calculation of the intertemporal constants but it is only preserved
        as a property to facilitate benchmarking against Ox.
        """
        return self._first_year_original_projections_of_variables_adjusted_by_intertemporal_constants


    def __update_perturbed_variable(self, variable_details: pd.Series):
        """
        ### Overview

        For each variable that has an intertemporal constant, we need to compute
        numerical approximations to the partial derivatives of the model with respect
        to that constant. Those  partial derivatives are approximated by evaluating the 
        relevant equations in the model using the data in the first projection year and then 
        again evaluating those equations after perturbing the variable of interest by
        `gcubed.Constants.DELTA`. The difference between the two evaluations is used
        to compute the partial derivatives for that constant.

        This function does the work of perturbing the intertemporal constant 
        associated with the variable, preparing for calculation of the partial 
        derivatives for that constant.

        The adjustment to the constant (the perturbation) is made by adjusting the
        constants associated with variables' observed differences from their state 
        space form equation evaluations in the baseline's first projection year.

        The original value of that constant is tracked using the private property, 
        `_original_value`, so that it can be restored after the partial derivatives
        have been computed.

        This function is called once for each variable in the SYM table of intertemporal 
        constant variables, as part of computing the intertemporal constants.

        """

        if hasattr(self, '_perturbed_variable_details'):
            sequence = self._perturbed_variable_details['sequence']
            match self._perturbed_variable_details['var_type']:
                case 'x1l':
                    self.x1r_difference_from_ssf[sequence] = self._original_value
                case 'j1l':
                    self.j1r_difference_from_ssf[sequence] = self._original_value
                case 'zel':
                    self.zer_difference_from_ssf[sequence] = self._original_value
                case 'z1l':
                    self.z1r_difference_from_ssf[sequence] = self._original_value
            delattr(self, '_original_value')

        if variable_details is None:
            delattr(self, '_perturbed_variable_details')
        else:
            sequence = variable_details['sequence']
            match variable_details['var_type']:
                case 'x1l':
                    self._original_value = float(self.x1r_difference_from_ssf[sequence])
                    self.x1r_difference_from_ssf[sequence] = self._original_value + Constants().DELTA
                case 'j1l':
                    self._original_value = float(self.j1r_difference_from_ssf[sequence])
                    self.j1r_difference_from_ssf[sequence] = self._original_value + Constants().DELTA
                case 'zel':
                    self._original_value = float(self.zer_difference_from_ssf[sequence])
                    self.zer_difference_from_ssf[sequence] = self._original_value + Constants().DELTA
                case 'z1l':
                    self._original_value = float(self.z1r_difference_from_ssf[sequence])
                    self.z1r_difference_from_ssf[sequence] = self._original_value + Constants().DELTA
            self._perturbed_variable_details = variable_details

    @property
    def perturbed_variable_details(self) -> pd.Series:
        """
        If computing intertemporal constants, 
        the var_map details (the row of the SYM var_map dataframe)
        for the variable being perturbed as part of computing
        derivatives needed to set intertemporal constants. Otherwise, this returns
        `None` if just producing the baseline projections.
        """
        if hasattr(self, '_perturbed_variable_details'):
            return self._perturbed_variable_details
        return None


    @property
    def first_year_projections_of_variables_adjusted_by_intertemporal_constants(self) -> np.ndarray:
        """
        An column vector of first year projection values for those variables that are adjusted
        by intertemporal constants.

        The vector is populated from the vectors of first year projections for 
        each of `x1l`, `j1l`, `zel`,  and `z1l`.
        """
        result = np.zeros(shape=(len(self.sym_data.variables_adjusted_by_intertemporal_constants), 1))
        i = 0
        for index, adjusted_variable_details in self.sym_data.variables_adjusted_by_intertemporal_constants.iterrows():
            sequence = adjusted_variable_details['sequence']
            match adjusted_variable_details['var_type']:
                case 'x1l':
                    result[i, 0] = self.yxr_first_year_projections[[sequence]]
                case 'j1l':
                    result[i, 0] = self.yjr_first_year_projections[[sequence]]
                case 'zel':
                    result[i, 0] = self.exz_first_year_projections[[sequence]]
                case 'z1l':
                    result[i, 0] = self.z1l_first_year_projections[[sequence]]
            i += 1
        return result

    @property
    def partial_derivatives_wrt_intertemporal_constants(self) -> np.ndarray:
        """
        The matrix of partial derivatives used in Newton's method to
        compute the intertemporal constants.

        This is a property of the class just to support benchmarking against Ox.
        """
        return self._partial_derivatives
    

    @property
    def intertemporal_constants(self) -> pd.DataFrame:
        """
        The data frame of intertemporal constants information
        obtained from SYM but augmented with the values of the
        intertemporal constants.

        The dataframe is indexed by the variable names.

        The constant values are stored in a column called `constant_value`.
        """
        return self._intertemporal_constants


    def __calculate_intertemporal_constants(self):
        """
        ### Overview

        Computes the intertemporal constant adjustments to 
        jump and other variables to align starting data
        values with model projections in the first year.

        Step 1.
        Compute functions of future exogenous variables through all years from the
        original first projection year (for the baseline projections) through to 
        the last projection year. These are needed to compute the functions of future
        exogenous variables that feed into the intertemporal constant calculations.

        Step 2.
        For the variables that are to be adjusted by the intertemporal
        constants, compute their projected values in the base projection year
        and store these values for comparison to perturbed base year projections so we can calculate
        the derivatives matrix needed to set the intertemporal constants.
        Also store the values of each of the 4 vectors in the model in the base year for benchmarking.

        Step 3.
        Initialise the partial derivatives matrix. This is the matrix of derivatives of each of the
        variables that is adjusted by intertemporal constants, with respect to each of the intertemporal
        constants, in the SSF equations (each of which is linear).

        Iterate over the intertemporal constants, perturbing each and recalculating the base year projections
        of the variables that are adjusted by intertemporal constants so that we can 
        estimate the relevant numeric derivatives.

        At the end of this step, update the perturbed variable details to `None` so that
        all constants associated with the difference between observed values and SSF calculated values
        are at their unpurturbed values when doing actual baseline projections.

        Step 4.
        Apply Newton's method to solve for the intertemporal constants.
        Multiply the difference between the observed values of the variables that are adjusted by
        the intertemporal constants and their original projected values, in the first projection year,
        by the inverse of the partial derivatives matrix.

        This only needs to be done once because the SSF of the model is linear so Newton's method
        gets to the solution in one iteration.
        """

        # Step 1.
        self._compute_functions_of_future_exogenous_variables(exogenous_projections=self.exo_projections)

        # Step 2.
        # Compute the first year projections - noting that no intertemporal 
        # constant adjustments have been made yet.
        self.__evaluate_first_projection_year_vector_projections()

        # Capture the first year projections of the intertemporal variables. 
        # These are used in this function for Newton's method below
        # and they are also deep-copied and stored as a property of the 
        # class for benchmarking purposes.
        self._first_year_original_projections_of_variables_adjusted_by_intertemporal_constants = self.first_year_projections_of_variables_adjusted_by_intertemporal_constants.copy()

        # Step 3.
        # Compute the partial derivatives matrix
        self._partial_derivatives = np.zeros(shape=(len(self.sym_data.intertemporal_constant_variables), len(
            self.sym_data.variables_adjusted_by_intertemporal_constants)))
        i = 0
        for index, variable_details in self.sym_data.intertemporal_constant_variables.iterrows():
            self.__update_perturbed_variable(variable_details=variable_details)
            self._compute_functions_of_future_exogenous_variables(exogenous_projections=self.exo_projections)
            self.__evaluate_first_projection_year_vector_projections()
            self._partial_derivatives[:, [i]] = (
                self.first_year_projections_of_variables_adjusted_by_intertemporal_constants -
                self._first_year_original_projections_of_variables_adjusted_by_intertemporal_constants) / Constants().DELTA
            i += 1

        # Generate the baseline projection to use in computing partial derivatives
        # and to generate matrix values that are used later in projection processes.
        self.__update_perturbed_variable(variable_details=None)

        # Step 4.
        # Use Newtons method adjustment to compute intertemporal constant values
        self._intertemporal_constants = self.sym_data.intertemporal_constant_variables
        values: np.ndarray = np.linalg.inv(self._partial_derivatives) @ \
            (self.baseline_projections.first_year_observed_values_of_variables_adjusted_by_intertemporal_constants -
             self.first_year_original_projections_of_variables_adjusted_by_intertemporal_constants)
        values = values.reshape((len(self.intertemporal_constants.index), 1))
        self._intertemporal_constants['constant_value'] = values
        self._intertemporal_constants = self.baseline_projections.intertemporal_constants

        logging.info("The intertemporal constants have been calibrated for the relinearised model.")



    @property
    def x1_constants(self) -> np.ndarray:
        """
        The constant adjustments to X1 to ensure projections equal observed values.
        Add any intertemporal constant values to the X1R difference to SSF equation 
        results with zero constants to get the combined set of constants.
        """

        if hasattr(self, "_x1_constants"):
            return self._x1_constants

        result: np.ndarray = self.x1r_difference_from_ssf.copy()
        if not hasattr(self, "intertemporal_constants"):
            return result

        i = 0
        for index, variable_details in self.sym_data.intertemporal_constant_variables.iterrows():
            if variable_details['var_type'] == 'x1l':
                result[variable_details['sequence'], 0] += self.intertemporal_constants.loc[variable_details['name'], 'constant_value']
            i = i + 1

        self._x1_constants: np.ndarray = result
        return self._x1_constants

    @property
    def j1_constants(self) -> np.ndarray:
        """
        The constant adjustments to J1 to ensure projections equal observed values.
        Add any intertemporal constant values to the X1R difference to SSF equation 
        results with zero constants to get the combined set of constants.
        """

        if hasattr(self, "_j1_constants"):
            return self._j1_constants

        result: np.ndarray = self.j1r_difference_from_ssf.copy()
        if not hasattr(self, "intertemporal_constants"):
            return result
        i = 0
        for index, variable_details in self.sym_data.intertemporal_constant_variables.iterrows():
            if variable_details['var_type'] == 'j1l':
                result[variable_details['sequence'], 0] += self.intertemporal_constants.loc[variable_details['name'], 'constant_value']
            i = i + 1

        self._j1_constants: np.ndarray = result
        return self._j1_constants

    @property
    def ze_constants(self) -> np.ndarray:
        """
        The constant adjustments to ZE to ensure projections equal observed values.
        Add any intertemporal constant values to the X1R difference to SSF equation 
        results with zero constants to get the combined set of constants.
        """

        if hasattr(self, "_ze_constants"):
            return self._ze_constants

        result: np.ndarray = self.zer_difference_from_ssf.copy()
        if not hasattr(self, "intertemporal_constants"):
            return result

        i = 0
        for index, variable_details in self.sym_data.intertemporal_constant_variables.iterrows():
            if variable_details['var_type'] == 'zel':
                logging.debug(
                    f"At index {i} intertemporal constant is {self.intertemporal_constants.loc[variable_details['name'],'constant_value']} : shape is {self.intertemporal_constants.shape}")
                result[variable_details['sequence'], 0] += self.intertemporal_constants.loc[variable_details['name'], 'constant_value']
            i = i + 1

        self._ze_constants: np.ndarray = result
        return self._ze_constants

    @property
    def z1_constants(self) -> np.ndarray:
        """
        The constant adjustments to Z1 to ensure projections equal observed values.
        Add any intertemporal constant values to the X1R difference to SSF equation 
        results with zero constants to get the combined set of constants.
        """

        if hasattr(self, "_z1_constants"):
            return self._z1_constants

        result: np.ndarray = self.z1r_difference_from_ssf.copy()
        if not hasattr(self, "intertemporal_constants"):
            return result
        i = 0
        for index, variable_details in self.sym_data.intertemporal_constant_variables.iterrows():
            if variable_details['var_type'] == 'z1l':
                result[variable_details['sequence'], 0] += self.intertemporal_constants.loc[variable_details['name'], 'constant_value']
            i = i + 1

        self._z1_constants: np.ndarray = result
        return self._z1_constants

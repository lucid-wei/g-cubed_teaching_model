# ------------------------------------------------------------------
# Purpose: Compute and provide access to baseline projections.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
"""
Contains the BaselineProjections class, for doing baseline projections.
"""
import logging
import pandas as pd
import numpy as np
from gcubed.linearisation.stable_manifold import StableManifold
from gcubed.model import Model
from gcubed.linearisation.state_space_form import StateSpaceForm
from gcubed.sym_data import SymData
from gcubed.model_parameters.parameters import Parameters
from gcubed.model_configuration import ModelConfiguration
from gcubed.data.gdp_scaled_database import GDPScaledDatabase
from gcubed.baseline.effective_labour_productivity import EffectiveLabourProductivity
from gcubed.baseline.energy_usage_efficiency import EnergyUsageEfficiency
from gcubed.projections.projections import Projections


class BaselineProjections(Projections):
    """
    ### Overview

    Compute the baseline model projections over the projection horizon 
    from the first projection year (a year with available data to be 
    matched by the projections) through to the last projection year.
    """

    # The perturbation to use when computing partial derivatives for intertemporal constant determination.
    PERTURBATION = 0.0001

    def __init__(self, stable_manifold: StableManifold) -> None:
        """
       ### Arguments

        stable_manifold: The stable manifold that provides access to all 
        of the model information required to produce projections.
        """
        logging.info("Setting up the baseline projections.")

        super().__init__(stable_manifold=stable_manifold)
        self._is_baseline_projections = True
        
        self._database = GDPScaledDatabase(database=self.model.database, base_year=self.configuration.base_year)

        self.__set_first_projection_year_observed_values()

        self.__store_observed_yxr_values_in_first_projection_year()

        # Set up the exogenous variable projections
        self.__create_exogenous_variable_projections()

        self.__store_observed_values_of_variables_adjusted_by_intertemporal_constants_in_first_projection_year()
        self.__compute_first_projection_year_ssf_deviations_from_observed_values()

        if not self.using_rolled_projections:
            self.__calculate_intertemporal_constants()

        # Generate the baseline projections
        self._generate_projections()

        # Generate the database projections
        self._generate_database_projections()

        # Generate publishable version of the projections
        self._generate_publishable_projections()

        self.__validate()


    def __validate(self):
        """
        TODO:  Validate the projections: 
        1. check that they are available for the expected projection years.
        2. Check that the base year projections are equal to the base year data values.
        """
        logging.info("The baseline projections have been generated.")

    @property
    def database(self) -> GDPScaledDatabase:
        """
        The database used as the starting point for the projections.
        """
        return self._database

    @property
    def using_rolled_projections(self) -> bool:
        """
        True if these projections are building on
        previous projections rather than just observed data.

        This affects how the baseline projections are set up in terms
        of the constants used.
        """
        return self.database.has_data_for_all_projection_years

    def __update_perturbed_variable(self, variable_details: pd.Series):
        """
        ### Overview

        Changes the perturbed variable, preparing for the
        next evaluation of the values needed to compute
        partial derivatives relevant to the determination 
        of the intertemporal constants.
        """

        if hasattr(self, '_perturbed_variable_details'):
            sequence = self._perturbed_variable_details['sequence']
            match self._perturbed_variable_details['var_type']:
                case 'x1l':
                    self.x1r_difference_from_ssf[sequence] = self._original_value
                case 'j1l':
                    self.j1r_difference_from_ssf[sequence] = self._original_value
                case 'zel':
                    self.zer_difference_from_ssf[sequence] = self._original_value
                case 'z1l':
                    self.z1r_difference_from_ssf[sequence] = self._original_value
            delattr(self, '_original_value')

        if variable_details is None:
            delattr(self, '_perturbed_variable_details')
        else:
            sequence = variable_details['sequence']
            match variable_details['var_type']:
                case 'x1l':
                    self._original_value = float(self.x1r_difference_from_ssf[sequence])
                    self.x1r_difference_from_ssf[sequence] = self._original_value + __class__.PERTURBATION
                case 'j1l':
                    self._original_value = float(self.j1r_difference_from_ssf[sequence])
                    self.j1r_difference_from_ssf[sequence] = self._original_value + __class__.PERTURBATION
                case 'zel':
                    self._original_value = float(self.zer_difference_from_ssf[sequence])
                    self.zer_difference_from_ssf[sequence] = self._original_value + __class__.PERTURBATION
                case 'z1l':
                    self._original_value = float(self.z1r_difference_from_ssf[sequence])
                    self.z1r_difference_from_ssf[sequence] = self._original_value + __class__.PERTURBATION
            self._perturbed_variable_details = variable_details

    @property
    def perturbed_variable_details(self) -> pd.Series:
        """
        The var_map details of the variable being perturbed to as part of computing
        derivatives needed to set intertemporal constants or none if just doing projections.
        """
        if hasattr(self, '_perturbed_variable_details'):
            return self._perturbed_variable_details
        return None

    @property
    def first_year_projections_of_variables_adjusted_by_intertemporal_constants(self) -> np.ndarray:
        """
        The values of the variables that have been changed by the perturbation to 
        an intertemporal constant as part of computing partial derivatives for setting the
        intertemporal constants appropriately. These values are a column vector
        for the first projection year only.
        """
        result = np.zeros(shape=(len(self.sym_data.variables_adjusted_by_intertemporal_constants), 1))
        i = 0
        for index, adjusted_variable_details in self.sym_data.variables_adjusted_by_intertemporal_constants.iterrows():
            sequence = adjusted_variable_details['sequence']
            match adjusted_variable_details['var_type']:
                case 'x1l':
                    result[i, 0] = self.yxr_first_year_projections[[sequence]]
                case 'j1l':
                    result[i, 0] = self.yjr_first_year_projections[[sequence]]
                case 'zel':
                    result[i, 0] = self.exz_first_year_projections[[sequence]]
                case 'z1l':
                    result[i, 0] = self.z1l_first_year_projections[[sequence]]
            i += 1
        return result

    def __set_first_projection_year_observed_values(self):
        """
        ### Overview

        Sets the database values for the vectors in 
        the model in the first projection year.
        """
        # RHS (identical to LHS) vector values to be compared to SSF calculated values
        self._first_projection_year_x1r: np.ndarray = self.database.rhs_vector_value(vector_name='x1r', year=self.first_projection_year, use_neutral_real_interest_rate=True)  # t+1
        self._first_projection_year_j1r: np.ndarray = self.database.rhs_vector_value(vector_name='j1r', year=self.first_projection_year, use_neutral_real_interest_rate=True)  # t+1
        self._first_projection_year_zer: np.ndarray = self.database.rhs_vector_value(vector_name='zer', year=self.first_projection_year, use_neutral_real_interest_rate=True)  # t
        self._first_projection_year_z1r: np.ndarray = self.database.rhs_vector_value(vector_name='z1r', year=self.first_projection_year, use_neutral_real_interest_rate=True)  # t

        # SSF RHS vector values
        self._first_projection_year_yxr: np.ndarray = self.database.rhs_vector_value(vector_name='yxr', year=self.first_projection_year, use_neutral_real_interest_rate=True)  # t
        self._first_projection_year_yjr: np.ndarray = self.database.rhs_vector_value(vector_name='yjr', year=self.first_projection_year, use_neutral_real_interest_rate=True)  # t
        self._first_projection_year_exz: np.ndarray = self.database.rhs_vector_value(vector_name='exz', year=self.first_projection_year, use_neutral_real_interest_rate=True)  # t+1
        self._first_projection_year_exo: np.ndarray = self.database.rhs_vector_value(vector_name='exo', year=self.first_projection_year, use_neutral_real_interest_rate=True)  # t

    def __store_observed_yxr_values_in_first_projection_year(self):
        """
        Save the values of the state vector in the base projection year to use in
        initiating the projection process.
        """
        yxr_initial_values = pd.DataFrame(self.first_projection_year_yxr.copy())
        yxr_initial_values.index = self.sym_data.vector_variable_names(vector_name='yxr')
        yxr_initial_values.columns = [str(self.first_projection_year)]
        self._yxr_initial_values: pd.DataFrame = yxr_initial_values

    def __store_observed_values_of_variables_adjusted_by_intertemporal_constants_in_first_projection_year(self):
        """
        Save the database values of the variables
        that are adjusted by intertemporal constants so that we can use
        those as the values we adjust the variables to using the intertemporal
        constants.
        """
        self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants: np.ndarray = \
            np.zeros(shape=(len(self.sym_data.variables_adjusted_by_intertemporal_constants), 1))
        i = 0
        for index, adjusted_variable_details in self.sym_data.variables_adjusted_by_intertemporal_constants.iterrows():
            sequence = adjusted_variable_details['sequence']
            match adjusted_variable_details['var_type']:
                case 'x1l':
                    self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants[i, 0] = self.first_projection_year_yxr[[sequence]]  # t = base year
                case 'j1l':
                    self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants[i, 0] = self.first_projection_year_yjr[[sequence]]  # t = base year
                case 'zel':
                    self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants[i, 0] = self.first_projection_year_exz[[sequence]]  # t+1 = year after base year
                case 'z1l':
                    self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants[i, 0] = self.first_projection_year_z1r[[sequence]]  # t = base year
            i += 1

    def __compute_first_projection_year_ssf_deviations_from_observed_values(self):
        """
        Compute the SSF values for the base projection year and calculate the differences from
        observed variable values for all system-determined variables (not the exogenous ones).
        See setconSYMBL.ox for details of the Ox implementation.

        Compute values for LHS variables based on RHS variable values in the projection base year 
        based on the SSF model. Then determine the difference between these LHS variables 
        (model predictions) and the actual values.

        Results are saved as data minus projections for all vectors.
        """

        # No constant adjustments for differences from SSF when doing rolling baseline projections
        if self.using_rolled_projections:
            self._x1r_difference_from_ssf = np.zeros((self.sym_data.vector_length(vector_name='x1r'), 1))
            self._j1r_difference_from_ssf = np.zeros((self.sym_data.vector_length(vector_name='j1r'), 1))
            self._zer_difference_from_ssf = np.zeros((self.sym_data.vector_length(vector_name='zer'), 1))
            self._z1r_difference_from_ssf = np.zeros((self.sym_data.vector_length(vector_name='z1r'), 1))
            return

        # We got here so we must be done the initial baseline projections that require a constant adjustment
        # for the SSF differences from observed data values in the base projection year.

        self.x1l_ssf_calculations_using_first_projection_year_data = self.state_space_form.delta('x1l', 'yxr') @ self.first_projection_year_yxr + \
            self.state_space_form.delta('x1l', 'yjr') @ self.first_projection_year_yjr + \
            self.state_space_form.delta('x1l', 'exz') @ self.first_projection_year_exz + \
            self.state_space_form.delta('x1l', 'exo') @ self.first_projection_year_exo

        self.j1l_ssf_calculations_using_first_projection_year_data = self.state_space_form.delta('j1l', 'yxr') @ self.first_projection_year_yxr + \
            self.state_space_form.delta('j1l', 'yjr') @ self.first_projection_year_yjr + \
            self.state_space_form.delta('j1l', 'exz') @ self.first_projection_year_exz + \
            self.state_space_form.delta('j1l', 'exo') @ self.first_projection_year_exo

        self.zel_ssf_calculations_using_first_projection_year_data = self.state_space_form.delta('zel', 'yxr') @ self.first_projection_year_yxr + \
            self.state_space_form.delta('zel', 'yjr') @ self.first_projection_year_yjr + \
            self.state_space_form.delta('zel', 'exz') @ self.first_projection_year_exz + \
            self.state_space_form.delta('zel', 'exo') @ self.first_projection_year_exo

        self.z1l_ssf_calculations_using_first_projection_year_data = self.state_space_form.delta('z1l', 'yxr') @ self.first_projection_year_yxr + \
            self.state_space_form.delta('z1l', 'yjr') @ self.first_projection_year_yjr + \
            self.state_space_form.delta('z1l', 'exz') @ self.first_projection_year_exz + \
            self.state_space_form.delta('z1l', 'exo') @ self.first_projection_year_exo

        self._x1r_difference_from_ssf = self.first_projection_year_x1r - self.x1l_ssf_calculations_using_first_projection_year_data  # t+1 = year after base year
        self._j1r_difference_from_ssf = self.first_projection_year_j1r - self.j1l_ssf_calculations_using_first_projection_year_data  # t+1 = year after base year
        self._zer_difference_from_ssf = self.first_projection_year_zer - self.zel_ssf_calculations_using_first_projection_year_data  # t = base year
        self._z1r_difference_from_ssf = self.first_projection_year_z1r - self.z1l_ssf_calculations_using_first_projection_year_data  # t = base year

    @property
    def first_projection_year_x1r(self) -> np.ndarray:
        """
        If the first projection year = t:
        Returns the value of x1r from the database as the value of x1 in period t+1
        """
        return self._first_projection_year_x1r

    @property
    def first_projection_year_j1r(self) -> np.ndarray:
        """
        If the first projection year = t:
        Returns the value of j1r from the database as the value of j1 in period t+1
        """
        return self._first_projection_year_j1r

    @property
    def first_projection_year_zer(self) -> np.ndarray:
        """
        If the first projection year = t:
        Returns the value of zer from the database as the value of x1 in period t
        """
        return self._first_projection_year_zer

    @property
    def first_projection_year_z1r(self) -> np.ndarray:
        """
        If the first projection year = t:
        Returns the value of z1r from the database as the value of z1 in period t
        """
        return self._first_projection_year_z1r

    @property
    def first_projection_year_yxr(self) -> np.ndarray:
        """
        If the first projection year = t:
        Returns the value of yxr from the database as the value of x1 in period t
        """
        return self._first_projection_year_yxr

    @property
    def first_projection_year_yjr(self) -> np.ndarray:
        """
        If the first projection year = t:
        Returns the value of yjr from the database as the value of j1 in period t
        """
        return self._first_projection_year_yjr

    @property
    def first_projection_year_exz(self) -> np.ndarray:
        """
        If the first projection year = t:
        Returns the value of exz from the database as the value of ze in period t+1
        """
        return self._first_projection_year_exz

    @property
    def first_projection_year_exo(self) -> np.ndarray:
        """
        If the first projection year = t:
        Returns the value of exo from the database as the value of exogenous variables (exo)
        in period t
        """
        return self._first_projection_year_exo

    @property
    def x1r_difference_from_ssf(self):
        """
        In Ox: decl cz2 = x1r - x1l
        """
        return self._x1r_difference_from_ssf

    @property
    def j1r_difference_from_ssf(self):
        """
        In Ox: decl cz4 = j1r - j1l
        """
        return self._j1r_difference_from_ssf

    @property
    def zer_difference_from_ssf(self):
        """
        In Ox: decl cz5 = zer - zel
        """
        return self._zer_difference_from_ssf

    @property
    def z1r_difference_from_ssf(self):
        """
        In Ox: decl cz6 = z1r - z1l
        """
        return self._z1r_difference_from_ssf

    @property
    def reference_h3t_used_to_compute_intertemporal_constants(self) -> np.ndarray:
        """
        Equivalent to h3t in the Ox implementation
        Functions of current and future exogenous variables affecting J1.
        This is the reference version of h3t, computed to calculation the projections
        for the base year that will be used as a reference projection when determining 
        the numeric derivatives for calculation of the intertemporal constants.

        Its only role is to preserve the appropriate information for benchmarking against Ox.
        """
        return self._reference_h3t_used_to_compute_intertemporal_constants

    @property
    def reference_c4t_used_to_compute_intertemporal_constants(self) -> np.ndarray:
        """
        Equivalent to c4t in the Ox implementation
        Functions of current and future exogenous variables affecting ZE.
        This is the reference version of h3t, computed to calculation the projections
        for the base year that will be used as a reference projection when determining 
        the numeric derivatives for calculation of the intertemporal constants.

        Its only role is to preserve the appropriate information for benchmarking against Ox.
        """
        return self._reference_c4t_used_to_compute_intertemporal_constants

    @property
    def x1_constants(self) -> np.ndarray:
        """
        The constant adjustments to X1 to ensure projections equal observed values.
        Add any intertemporal constant values to the X1R difference to SSF equation 
        results with zero constants to get the combined set of constants.
        """

        if hasattr(self, "_x1_constants"):
            return self._x1_constants

        result: np.ndarray = self.x1r_difference_from_ssf.copy()
        if not hasattr(self, "intertemporal_constants"):
            return result

        i = 0
        for index, variable_details in self.sym_data.intertemporal_constant_variables.iterrows():
            if variable_details['var_type'] == 'x1l':
                result[variable_details['sequence'], 0] += self.intertemporal_constants.loc[variable_details['name'], 'constant_value']
            i = i + 1

        self._x1_constants: np.ndarray = result
        return self._x1_constants

    @property
    def j1_constants(self) -> np.ndarray:
        """
        The constant adjustments to J1 to ensure projections equal observed values.
        Add any intertemporal constant values to the X1R difference to SSF equation results with zero constants
        to get the combined set of constants.
        """

        if hasattr(self, "_j1_constants"):
            return self._j1_constants

        result: np.ndarray = self.j1r_difference_from_ssf.copy()
        if not hasattr(self, "intertemporal_constants"):
            return result
        i = 0
        for index, variable_details in self.sym_data.intertemporal_constant_variables.iterrows():
            if variable_details['var_type'] == 'j1l':
                result[variable_details['sequence'], 0] += self.intertemporal_constants.loc[variable_details['name'], 'constant_value']
            i = i + 1

        self._j1_constants: np.ndarray = result
        return self._j1_constants

    @property
    def ze_constants(self) -> np.ndarray:
        """
        The constant adjustments to ZE to ensure projections equal observed values.
        Add any intertemporal constant values to the X1R difference to SSF equation results with zero constants
        to get the combined set of constants.
        """

        if hasattr(self, "_ze_constants"):
            return self._ze_constants

        result: np.ndarray = self.zer_difference_from_ssf.copy()
        if not hasattr(self, "intertemporal_constants"):
            return result

        i = 0
        for index, variable_details in self.sym_data.intertemporal_constant_variables.iterrows():
            if variable_details['var_type'] == 'zel':
                logging.debug(
                    f"At index {i} intertemporal constant is {self.intertemporal_constants.loc[variable_details['name'],'constant_value']} : shape is {self.intertemporal_constants.shape}")
                result[variable_details['sequence'], 0] += self.intertemporal_constants.loc[variable_details['name'], 'constant_value']
            i = i + 1

        self._ze_constants: np.ndarray = result
        return self._ze_constants

    @property
    def z1_constants(self) -> np.ndarray:
        """
        The constant adjustments to Z1 to ensure projections equal observed values.
        Add any intertemporal constant values to the X1R difference to SSF equation results with zero constants
        to get the combined set of constants.
        """

        if hasattr(self, "_z1_constants"):
            return self._z1_constants

        result: np.ndarray = self.z1r_difference_from_ssf.copy()
        if not hasattr(self, "intertemporal_constants"):
            return result
        i = 0
        for index, variable_details in self.sym_data.intertemporal_constant_variables.iterrows():
            if variable_details['var_type'] == 'z1l':
                result[variable_details['sequence'], 0] += self.intertemporal_constants.loc[variable_details['name'], 'constant_value']
            i = i + 1

        self._z1_constants: np.ndarray = result
        return self._z1_constants

    def __create_exogenous_variable_projections(self):
        """
        Populates the exogenous variable values through the projection years. 
        These values are determined outside the system.

        The rolling baseline projections just copy the exogenous values from the previous projections
        and use those as the starting point for the next round of projection generation.

        Otherwise, when initially setting up baseline projections, incorporate values from:
        - the database in the base projection year
        - effective labour productivity projections
        - energy efficiency improvement projections
        """

        # If we are doing the baseline projections after rolling forward to a new base projection year,
        # just copy the database values for the exogenous variables over the projection years
        # and then we are done.
        if self.using_rolled_projections:
            matching_indices: pd.Index = self.sym_data.combined_variable_summary.loc[self.sym_data.combined_variable_summary.vector == 'exo', :].index
            self._exo_projections: pd.DataFrame = self.database.data.loc[matching_indices, self.projection_years_column_labels]
            return

        # We got here so we must be setting up the exogenous variable projections for the first time ...

        # Replicate projection base year values across all projection periods for all exogenous variables.
        projections: pd.DataFrame = pd.DataFrame(np.tile(self.first_projection_year_exo, (1, self.configuration.projection_years_count)))
        projections.columns = self.projection_years_column_labels
        projections.reset_index()

        # Add effective labour productivity and energy usage efficiency.
        effective_labour_productivity: EffectiveLabourProductivity = self.model.effective_labour_productivity
        rogy: pd.DataFrame = effective_labour_productivity.rogy
        energy_usage_efficiency: EnergyUsageEfficiency = self.model.energy_usage_efficiency
        for region in self.sym_data.regions_members:

            regional_effective_labour_productivity: pd.DataFrame = effective_labour_productivity.effective_productivity_deviations(region=region)
            regional_energy_usage_efficiency: pd.DataFrame = energy_usage_efficiency.sector_cumulative_energy_usage_efficiency_gains(region=region)
            consumption_energy_usage_efficiency: pd.DataFrame = energy_usage_efficiency.consumption_cumulative_energy_usage_efficiency_gains

            variable_prefix_ROGY: str = f"ROGY"
            rogy_name: str = f"{variable_prefix_ROGY}({region})"
            if self.sym_data.has_variables(variable_name_prefix=rogy_name):
                rogy_index: int = self.sym_data.variable_index(vector_name='exo', variable_name=rogy_name)
                rogy_units = self.sym_data.variable_units(vector_name='exo', variable_name_prefix=variable_prefix_ROGY)
                rogy_data: pd.DataFrame = rogy.loc[[region], self.projection_years_column_labels]
                if 'gdp' in rogy_units:
                    raise Exception(f"{rogy_name} has gdp units so shocks to that variable are not supported.")

                projections.loc[[rogy_index], :] = projections.loc[[rogy_index], :] + (rogy_data.to_numpy().flatten() / 100)
            # else:
            #     logging.warning(f"{rogy_name} is not in the SYM model.")

            shefc_name_prefix: str = f"SHEFC"
            shefc_name: str = f"{shefc_name_prefix}({region})"
            if self.sym_data.has_variables(variable_name_prefix=shefc_name_prefix):
                shefc_index: int = self.sym_data.variable_index(vector_name='exo', variable_name=shefc_name)
                shefc_units = self.sym_data.variable_units(vector_name='exo', variable_name_prefix=shefc_name_prefix)
                shefc_data: pd.DataFrame = consumption_energy_usage_efficiency.loc[[region], self.projection_years_column_labels]
                if 'gdp' in shefc_units:
                    raise Exception(f"{shefc_name} has gdp units so shocks to that variable are not supported.")
                projections.loc[[shefc_index], :] = projections.loc[[shefc_index], :] + (shefc_data.to_numpy().flatten() / 100)
            # else:
            #     logging.warning(f"{shefc_name} is not in the SYM model.")

            variable_prefix_SHL: str = 'SHL'
            variable_prefix_SHEF: str = 'SHEF'
            for sector in self.sym_data.sectors_members:

                shl_name: str = f"{variable_prefix_SHL}({region},{sector})"
                if self.sym_data.has_variables(variable_name_prefix=shl_name):
                    shl_index: int = self.sym_data.variable_index(vector_name='exo', variable_name=shl_name)
                    shl_units = self.sym_data.variable_units(vector_name='exo', variable_name_prefix=variable_prefix_SHL)
                    shl_data: pd.DataFrame = regional_effective_labour_productivity.loc[[sector], self.projection_years_column_labels]
                    if 'gdp' in shl_units:
                        raise Exception(f"{shl_name} has gdp units so shocks to that variable are not supported.")
                    projections.loc[[shl_index], :] = projections.loc[[
                        shl_index], :] + (shl_data.to_numpy().flatten() / 100)
                # else:
                #     logging.warning(f"{shl_name} is not in the SYM model.")

                shef_name: str = f"{variable_prefix_SHEF}({sector},{region})"
                if self.sym_data.has_variables(variable_name_prefix=shef_name):
                    shef_index: int = self.sym_data.variable_index(vector_name='exo', variable_name=shef_name)
                    shef_units = self.sym_data.variable_units(vector_name='exo', variable_name_prefix=variable_prefix_SHEF)
                    shef_data: pd.DataFrame = regional_energy_usage_efficiency.loc[[sector], self.projection_years_column_labels]
                    if 'gdp' in shef_units:
                        raise Exception(f"{shef_name} has gdp units so shocks to that variable are not supported.")
                    projections.loc[[shef_index], :] = projections.loc[[shef_index], :] + (shef_data.to_numpy().flatten() / 100)
                # else:
                #     logging.warning(f"{shef_shock_name} is not in the SYM model.")

        # Index with variable names.
        projections.index = self.sym_data.vector_variable_names(vector_name='exo')

        # Store the exogenous projections that will be augmented for other projections.
        self._exo_projections: pd.DataFrame = projections

    def __evaluate_first_projection_year_vector_projections(self):
        """
        Computes the values of the model equation vectors in the first projection year, 
        using the functions of future exogenous variables, the stable manifold, etc
        """

        self._exo_first_year_projections = self.exo_projections[:, [0]]

        self._yxr_first_year_projections = self.yxr_initial_values.to_numpy().copy()

        # er = h1t*x[][1] + h2t*exog[][1] + h3t[][1];
        self._yjr_first_year_projections = \
            self.stable_manifold.H1 @ self.yxr_first_year_projections + \
            self.stable_manifold.H2 @ self.exo_first_year_projections + \
            self._h3t[:, [0]]

        # tzl = mu1t*x[][1] + mu4t*exog[][1] + c4t[][1];
        self._exz_first_year_projections = \
            self.stable_manifold.mu1 @ self.yxr_first_year_projections + \
            self.stable_manifold.mu2 @ self.exo_first_year_projections + \
            self._c4t[:, [0]]

        # z1l projections = d5n*x[][1]+d7n*exog[][1]+d6n*er+d4n*tzl+cz6[][1]
        self._z1l_first_year_projections = \
            self.state_space_form.delta('z1l', 'yxr') @ self.yxr_first_year_projections + \
            self.state_space_form.delta('z1l', 'exo') @ self.exo_first_year_projections + \
            self.state_space_form.delta('z1l', 'yjr') @ self.yjr_first_year_projections + \
            self.state_space_form.delta('z1l', 'exz') @ self.exz_first_year_projections + \
            self.z1r_difference_from_ssf

    @property
    def yxr_first_year_projections(self) -> np.ndarray:
        """
        Projections of X1_t (yxr) in the first projection year
        """
        return self._yxr_first_year_projections

    @property
    def yjr_first_year_projections(self) -> np.ndarray:
        """
        Projections of J1_t (yjr) in the first projection year
        """
        return self._yjr_first_year_projections

    @property
    def exz_first_year_projections(self) -> np.ndarray:
        """
        Projections of ZE_t (exz) in the first projection year
        """
        return self._exz_first_year_projections

    @property
    def z1l_first_year_projections(self) -> np.ndarray:
        """
        Projections of Z1_t (z1l=z1r) in the first projection year
        """
        return self._z1l_first_year_projections

    @property
    def exo_first_year_projections(self) -> np.ndarray:
        """
        Projections of EXO_t in the first projection year
        """
        return self._exo_first_year_projections

    @property
    def first_year_original_projections_of_variables_adjusted_by_intertemporal_constants(self) -> np.ndarray:
        """
        The first year projected values for the variables that are being
        adjusted by the intertemporal constants.

        The values are those for the projection that is not adjusted by intertemporal constants.
        """
        return self._first_year_original_projections_of_variables_adjusted_by_intertemporal_constants

    @property
    def first_year_original_projections_of_yxr(self) -> np.ndarray:
        """
        The first year projected values for the state variables.
        Required for benchmarking against Ox.
        """
        return self._first_year_original_projections_of_yxr

    @property
    def first_year_original_projections_of_yjr(self) -> np.ndarray:
        """
        The first year projected values for the costate variables.
        Required for benchmarking against Ox.
        """
        return self._first_year_original_projections_of_yjr

    @property
    def first_year_original_projections_of_exz(self) -> np.ndarray:
        """
        The first year projected values for the expected endogenous variables exz.
        Required for benchmarking against Ox.
        """
        return self._first_year_original_projections_of_exz

    @property
    def first_year_original_projections_of_z1l(self) -> np.ndarray:
        """
        The first year projected values for the endogenous variables.
        Required for benchmarking against Ox.
        """
        return self._first_year_original_projections_of_z1l

    @property
    def first_year_observed_values_of_variables_adjusted_by_intertemporal_constants(self) -> np.ndarray:
        """
        Returns the observed values, in the first projection year, of the 
        variables that are adjusted by intertemporal constants.
        """
        return self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants

    @property
    def intertemporal_constants(self) -> pd.DataFrame:
        return self._intertemporal_constants

    @property
    def partial_derivatives_wrt_intertemporal_constants(self) -> np.ndarray:
        return self._partial_derivatives

    def __calculate_intertemporal_constants(self):
        """
        Computes the intertemporal constant adjustments to jump and other variables to align starting data
        values with model projections in the first year.

        Step 1.
        Compute functions of future exogenous variables through all years of the projection.

        Step 2.
        For the variables that are to be adjusted by the intertemporal
        constants, compute their projected values in the base projection year
        and store these values for comparison to perturbed base year projections so we can calculate
        the derivatives matrix needed to set the intertemporal constants.
        Also store the values of each of the 4 vectors in the model in the base year for benchmarking.

        Step 3.
        Initialise the partial derivatives matrix. This is the matrix of derivatives of each of the
        variables that is adjusted by intertemporal constants, with respect to each of the intertemporal
        constants.
        Iterate over the intertemporal constants, perturbing each and recalculating the base year projections
        of the variables that are adjusted by intertemporal constants so that we can 
        estimate the relevant numeric derivatives.
        """

        # Step 1.
        self._compute_functions_of_future_exogenous_variables()
        self._reference_c4t_used_to_compute_intertemporal_constants = self.c4t.copy()
        self._reference_h3t_used_to_compute_intertemporal_constants = self.h3t.copy()

        # Step 2.
        self.__evaluate_first_projection_year_vector_projections()
        self._first_year_original_projections_of_yxr = self.yxr_first_year_projections.copy()
        self._first_year_original_projections_of_yjr = self.yjr_first_year_projections.copy()
        self._first_year_original_projections_of_exz = self.exz_first_year_projections.copy()
        self._first_year_original_projections_of_z1l = self.z1l_first_year_projections.copy()
        self._first_year_original_projections_of_variables_adjusted_by_intertemporal_constants = \
            self.first_year_projections_of_variables_adjusted_by_intertemporal_constants.copy()

        # Step 3.
        self._partial_derivatives = np.zeros(shape=(len(self.sym_data.intertemporal_constant_variables), len(
            self.sym_data.variables_adjusted_by_intertemporal_constants)))
        i = 0
        for index, variable_details in self.sym_data.intertemporal_constant_variables.iterrows():
            self.__update_perturbed_variable(variable_details=variable_details)
            self._compute_functions_of_future_exogenous_variables()
            self.__evaluate_first_projection_year_vector_projections()
            self._partial_derivatives[:, [i]] = (
                self.first_year_projections_of_variables_adjusted_by_intertemporal_constants -
                self._first_year_original_projections_of_variables_adjusted_by_intertemporal_constants) \
                / __class__.PERTURBATION
            i += 1

        # Get the unperturbed values of the variables in first projection year

        # Generate the baseline projection to use in computing partial derivatives
        # and to generate matrix values that are used later in projection processes.
        self.__update_perturbed_variable(variable_details=None)

        # Use newtons method adjustment to compute intertemporal constant values
        self._intertemporal_constants = self.sym_data.intertemporal_constant_variables
        values: np.ndarray = np.linalg.inv(self._partial_derivatives) @ \
            (self.first_year_observed_values_of_variables_adjusted_by_intertemporal_constants -
             self.first_year_original_projections_of_variables_adjusted_by_intertemporal_constants)
        values = values.reshape((len(self.intertemporal_constants.index), 1))
        self._intertemporal_constants['constant_value'] = values
        logging.info("The intertemporal constants have been calibrated.")

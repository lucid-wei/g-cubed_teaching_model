# ------------------------------------------------------------------
# Purpose: Compute and provide access to baseline projections.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
"""
Contains the `BaselineProjections` class, used for doing baseline projections.
"""
import logging
from typing import Optional # DO NOT DELETE THIS IMPORT it manages circular references.
import pandas as pd
import numpy as np
from gcubed.constants import Constants
from gcubed.linearisation.stable_manifold import StableManifold
from gcubed.data.gdp_scaled_database import GDPScaledDatabase
from gcubed.baseline.effective_labour_productivity import EffectiveLabourProductivity
from gcubed.baseline.energy_usage_efficiency import EnergyUsageEfficiency
from gcubed.projections.projections import Projections


class BaselineProjections(Projections):
    """
    ### Overview

    Compute the baseline model projections over the projection horizon 
    from the first projection year (a year with available data to be 
    matched by the projections) through to the last projection year.

    """

    def __init__(self, stable_manifold: StableManifold, start_from_neutral_real_interest_rate: bool = None) -> None:
        """
       ### Arguments

        `stable_manifold`: The stable manifold that provides access to all 
        of the model information required to produce projections.

        `start_from_neutral_real_interest_rate`: `True` if the baseline projections start from 
        the neutral real interest rate and `False` if they start from the observed real interest rates.
        This parameter defaults to a value of `None` which means that the baseline projections start
        from the neutral real interest rate if the linear model used for the
        projections was done at the neutral real interest rate.
        """
        logging.info("Setting up the baseline projections.")

        super().__init__(stable_manifold=stable_manifold)
        self._is_baseline_projections = True

        # Determine whether the baseline projections start the projections from the neutral 
        # real interest rate or from the observed real interest rates.
        if start_from_neutral_real_interest_rate is None:
            self._start_from_neutral_real_interest_rate = self.stable_manifold.ssf.linear_model.use_neutral_real_interest_rate
        else:
            self._start_from_neutral_real_interest_rate = start_from_neutral_real_interest_rate
        
        self._database = GDPScaledDatabase(database=self.model.database, base_year=self.configuration.base_year)

        self.__set_first_projection_year_observed_values()

        self.__store_observed_yxr_values_in_first_projection_year()

        # Set up the exogenous variable projections
        self.__create_exogenous_variable_projections()

        self.__store_observed_values_of_variables_adjusted_by_intertemporal_constants_in_first_projection_year()
        self.__compute_first_projection_year_ssf_deviations_from_observed_values()

        # Set up the intertemporal constant variables
        self.__calculate_intertemporal_constants()

        # Generate the baseline projections
        self._generate_projections()

        # Generate the database projections
        self._generate_database_projections()

        # Generate publishable version of the projections
        self._generate_publishable_projections()

        self.__validate()


    def __validate(self):
        """
        TODO:  Validate the projections: 
        1. check that they are available for the expected projection years.
        2. Check that the base year projections are equal to the base year data values.
        """
        logging.info("The baseline projections have been generated.")

    @property
    def baseline_projections(self) -> Optional['BaselineProjections']:
        return self

    @property
    def database(self) -> GDPScaledDatabase:
        """
        The database used as the starting point for the projections.
        """
        return self._database

    @property
    def start_from_neutral_real_interest_rate(self) -> bool:
        """
        `True` if interest rates are set to the neutral real interest
        rate for the start of the baseline projections and `False` otherwise.
        """
        return self._start_from_neutral_real_interest_rate

    def __update_perturbed_variable(self, variable_details: pd.Series):
        """
        ### Overview

        For each variable that has an intertemporal constant, we need to compute
        numerical approximations to the partial derivatives of the model with respect
        to that constant. Those  partial derivatives are approximated by evaluating the 
        relevant equations in the model using the data in the first projection year and then 
        again evaluating those equations after perturbing the variable of interest by
        `Constants.DELTA`. The difference between the two evaluations is used
        to compute the partial derivatives for that constant.

        This function does the work of perturbing the intertemporal constant 
        associated with the variable, preparing for calculation of the partial 
        derivatives for that constant.

        The adjustment to the constant (the perturbation) is made by adjusting the
        constants associated with variables' observed differences from their state 
        space form equation evaluations in the baseline's first projection year.

        The original value of that constant is tracked using the private property, 
        `_original_value`, so that it can be restored after the partial derivatives
        have been computed.

        This function is called once for each variable in the SYM table of intertemporal 
        constant variables, as part of computing the intertemporal constants.

        """

        if hasattr(self, '_perturbed_variable_details'):
            sequence = self._perturbed_variable_details['sequence']
            match self._perturbed_variable_details['var_type']:
                case 'x1l':
                    self.x1r_difference_from_ssf[sequence] = self._original_value
                case 'j1l':
                    self.j1r_difference_from_ssf[sequence] = self._original_value
                case 'zel':
                    self.zer_difference_from_ssf[sequence] = self._original_value
                case 'z1l':
                    self.z1r_difference_from_ssf[sequence] = self._original_value
            delattr(self, '_original_value')

        if variable_details is None:
            delattr(self, '_perturbed_variable_details')
        else:
            sequence = variable_details['sequence']
            match variable_details['var_type']:
                case 'x1l':
                    self._original_value = float(self.x1r_difference_from_ssf[sequence])
                    self.x1r_difference_from_ssf[sequence] = self._original_value + Constants().DELTA
                case 'j1l':
                    self._original_value = float(self.j1r_difference_from_ssf[sequence])
                    self.j1r_difference_from_ssf[sequence] = self._original_value + Constants().DELTA
                case 'zel':
                    self._original_value = float(self.zer_difference_from_ssf[sequence])
                    self.zer_difference_from_ssf[sequence] = self._original_value + Constants().DELTA
                case 'z1l':
                    self._original_value = float(self.z1r_difference_from_ssf[sequence])
                    self.z1r_difference_from_ssf[sequence] = self._original_value + Constants().DELTA
            self._perturbed_variable_details = variable_details

    @property
    def perturbed_variable_details(self) -> pd.Series:
        """
        If computing intertemporal constants, 
        the var_map details (the row of the SYM var_map dataframe)
        for the variable being perturbed as part of computing
        derivatives needed to set intertemporal constants. Otherwise, this returns
        `None` if just producing the baseline projections.
        """
        if hasattr(self, '_perturbed_variable_details'):
            return self._perturbed_variable_details
        return None

    @property
    def first_year_projections_of_variables_adjusted_by_intertemporal_constants(self) -> np.ndarray:
        """
        An column vector of first year projection values for those variables that are adjusted
        by intertemporal constants.

        The vector is populated from the vectors of first year projections for 
        each of `x1l`, `j1l`, `zel`,  and `z1l`.
        """
        result = np.zeros(shape=(len(self.sym_data.variables_adjusted_by_intertemporal_constants), 1))
        i = 0
        for index, adjusted_variable_details in self.sym_data.variables_adjusted_by_intertemporal_constants.iterrows():
            sequence = adjusted_variable_details['sequence']
            match adjusted_variable_details['var_type']:
                case 'x1l':
                    result[i, 0] = self.yxr_first_year_projections[[sequence]]
                case 'j1l':
                    result[i, 0] = self.yjr_first_year_projections[[sequence]]
                case 'zel':
                    result[i, 0] = self.exz_first_year_projections[[sequence]]
                case 'z1l':
                    result[i, 0] = self.z1l_first_year_projections[[sequence]]
            i += 1
        return result

    def __set_first_projection_year_observed_values(self):
        """
        ### Overview

        Populates the model vectors using the database values associated with 
        the first projection year. 
        
        Note that some variables are populated iwth
        data from adjacent years. Review the `Database.rhs_vector_value` method
        for details. 
        
        Note also that there is the option to override real and 
        nominal interest rates with values associated with inflation neutrality.
        """
        # RHS (identical to LHS) vector values to be compared to SSF calculated values
        self._first_projection_year_x1r: np.ndarray = self.database.rhs_vector_value(vector_name='x1r', year=self.first_projection_year, use_neutral_real_interest_rate=self.start_from_neutral_real_interest_rate)  # t+1
        self._first_projection_year_j1r: np.ndarray = self.database.rhs_vector_value(vector_name='j1r', year=self.first_projection_year, use_neutral_real_interest_rate=self.start_from_neutral_real_interest_rate)  # t+1
        self._first_projection_year_zer: np.ndarray = self.database.rhs_vector_value(vector_name='zer', year=self.first_projection_year, use_neutral_real_interest_rate=self.start_from_neutral_real_interest_rate)  # t
        self._first_projection_year_z1r: np.ndarray = self.database.rhs_vector_value(vector_name='z1r', year=self.first_projection_year, use_neutral_real_interest_rate=self.start_from_neutral_real_interest_rate)  # t

        # SSF RHS vector values
        self._first_projection_year_yxr: np.ndarray = self.database.rhs_vector_value(vector_name='yxr', year=self.first_projection_year, use_neutral_real_interest_rate=self.start_from_neutral_real_interest_rate)  # t
        self._first_projection_year_yjr: np.ndarray = self.database.rhs_vector_value(vector_name='yjr', year=self.first_projection_year, use_neutral_real_interest_rate=self.start_from_neutral_real_interest_rate)  # t
        self._first_projection_year_exz: np.ndarray = self.database.rhs_vector_value(vector_name='exz', year=self.first_projection_year, use_neutral_real_interest_rate=self.start_from_neutral_real_interest_rate)  # t+1
        self._first_projection_year_exo: np.ndarray = self.database.rhs_vector_value(vector_name='exo', year=self.first_projection_year, use_neutral_real_interest_rate=self.start_from_neutral_real_interest_rate)  # t

    def __store_observed_yxr_values_in_first_projection_year(self):
        """
        ### Overview

        Save the values of the state vector (X1) in the first projection year to use in
        initiating the projection process.
        """
        yxr_initial_values = pd.DataFrame(self.first_projection_year_yxr.copy())
        yxr_initial_values.index = self.sym_data.vector_variable_names(vector_name='yxr')
        yxr_initial_values.columns = [str(self.first_projection_year)]
        self._yxr_initial_values: pd.DataFrame = yxr_initial_values

    def __store_observed_values_of_variables_adjusted_by_intertemporal_constants_in_first_projection_year(self):
        """
        ### Overview

        Save the database values of the variables
        that are adjusted by intertemporal constants so that we can use
        those as the values we adjust the variables to using the intertemporal
        constants.
        """
        self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants: np.ndarray = \
            np.zeros(shape=(len(self.sym_data.variables_adjusted_by_intertemporal_constants), 1))
        i = 0
        for index, adjusted_variable_details in self.sym_data.variables_adjusted_by_intertemporal_constants.iterrows():
            sequence = adjusted_variable_details['sequence']
            match adjusted_variable_details['var_type']:
                case 'x1l':
                    self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants[i, 0] = self.first_projection_year_yxr[[sequence]]  # t = base year
                case 'j1l':
                    self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants[i, 0] = self.first_projection_year_yjr[[sequence]]  # t = base year
                case 'zel':
                    self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants[i, 0] = self.first_projection_year_exz[[sequence]]  # t+1 = year after base year
                case 'z1l':
                    self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants[i, 0] = self.first_projection_year_z1r[[sequence]]  # t = base year
            i += 1

    def __compute_first_projection_year_ssf_deviations_from_observed_values(self):
        """
        ### Overview

        Step 1.
        Compute the state-space-form values for the LHS vectors  in  thefirst projection year 
        using the values from the database for the RHS vectors in the state space form.

        and 

        Step 2.
        Calculate the differences between the database values for the RHS vectors
        `x1r`, `j1r`, `zer`, and `z1r` and the values computed in Step 1. Store these
        as properties of the class instance. They become constant adjustments that are
        used in the projection process to ensure that the database values in 
        the first projection year match the baseline projections of those values.

        The differences are preserved as the database values minus projections.
        """

        # Step 1.
        self.x1l_ssf_calculations_using_first_projection_year_data = self.state_space_form.delta('x1l', 'yxr') @ self.first_projection_year_yxr + \
            self.state_space_form.delta('x1l', 'yjr') @ self.first_projection_year_yjr + \
            self.state_space_form.delta('x1l', 'exz') @ self.first_projection_year_exz + \
            self.state_space_form.delta('x1l', 'exo') @ self.first_projection_year_exo

        self.j1l_ssf_calculations_using_first_projection_year_data = self.state_space_form.delta('j1l', 'yxr') @ self.first_projection_year_yxr + \
            self.state_space_form.delta('j1l', 'yjr') @ self.first_projection_year_yjr + \
            self.state_space_form.delta('j1l', 'exz') @ self.first_projection_year_exz + \
            self.state_space_form.delta('j1l', 'exo') @ self.first_projection_year_exo

        self.zel_ssf_calculations_using_first_projection_year_data = self.state_space_form.delta('zel', 'yxr') @ self.first_projection_year_yxr + \
            self.state_space_form.delta('zel', 'yjr') @ self.first_projection_year_yjr + \
            self.state_space_form.delta('zel', 'exz') @ self.first_projection_year_exz + \
            self.state_space_form.delta('zel', 'exo') @ self.first_projection_year_exo

        self.z1l_ssf_calculations_using_first_projection_year_data = self.state_space_form.delta('z1l', 'yxr') @ self.first_projection_year_yxr + \
            self.state_space_form.delta('z1l', 'yjr') @ self.first_projection_year_yjr + \
            self.state_space_form.delta('z1l', 'exz') @ self.first_projection_year_exz + \
            self.state_space_form.delta('z1l', 'exo') @ self.first_projection_year_exo

        # Step 2.
        self._x1r_difference_from_ssf = self.first_projection_year_x1r - self.x1l_ssf_calculations_using_first_projection_year_data  # t+1 = year after base year
        self._j1r_difference_from_ssf = self.first_projection_year_j1r - self.j1l_ssf_calculations_using_first_projection_year_data  # t+1 = year after base year
        self._zer_difference_from_ssf = self.first_projection_year_zer - self.zel_ssf_calculations_using_first_projection_year_data  # t = base year
        self._z1r_difference_from_ssf = self.first_projection_year_z1r - self.z1l_ssf_calculations_using_first_projection_year_data  # t = base year

    @property
    def first_projection_year_x1r(self) -> np.ndarray:
        """
        The `x1r` vector populated with database values
        from the year after the first projection year.

        These values are not adjusted by any constants and are never
        altered after they are set.
        """
        return self._first_projection_year_x1r

    @property
    def first_projection_year_j1r(self) -> np.ndarray:
        """
        The `j1r` vector populated with database values
        from the year after the first projection year.
        
        These values are not adjusted by any constants and are never
        altered after they are set.
        """
        return self._first_projection_year_j1r

    @property
    def first_projection_year_zer(self) -> np.ndarray:
        """
        The `zer` vector populated with database values
        from the first projection year.
        
        These values are not adjusted by any constants and are never
        altered after they are set.
        """
        return self._first_projection_year_zer

    @property
    def first_projection_year_z1r(self) -> np.ndarray:
        """
        The `z1r` vector populated with database values
        from the first projection year.
        
        These values are not adjusted by any constants and are never
        altered after they are set.
        """
        return self._first_projection_year_z1r

    @property
    def first_projection_year_yxr(self) -> np.ndarray:
        """
        The `yxr` vector populated with database values
        from the first projection year.
        
        These values are not adjusted by any constants and are never
        altered after they are set.
        """
        return self._first_projection_year_yxr

    @property
    def first_projection_year_yjr(self) -> np.ndarray:
        """
        The `yjr` vector populated with database values
        from the first projection year.

        These values are not adjusted by any constants and are never
        altered after they are set.
        """
        return self._first_projection_year_yjr

    @property
    def first_projection_year_exz(self) -> np.ndarray:
        """
        The `exz` vector populated with database values
        from the year after the first projection year.

        These values are not adjusted by any constants and are never
        altered after they are set.
        """
        return self._first_projection_year_exz

    @property
    def first_projection_year_exo(self) -> np.ndarray:
        """
        The `exo` vector populated with database values
        from the first projection year.

        These values are not adjusted by any constants and are never
        altered after they are set.
        """
        return self._first_projection_year_exo

    @property
    def x1r_difference_from_ssf(self):
        """
        The difference between the database values of `x1r`
        and the raw baseline projections of those values,
        without making any constant adjustments at all.

        These differences are added to the constants that
        are used in the baseline projections to ensure that
        the projections in the first projection year match
        the database values in that year.
        """
        return self._x1r_difference_from_ssf

    @property
    def j1r_difference_from_ssf(self):
        """
        The difference between the database values of `j1r`
        and the raw baseline projections of those values,
        without making any constant adjustments at all.

        These differences are added to the constants that
        are used in the baseline projections to ensure that
        the projections in the first projection year match
        the database values in that year.

        """
        return self._j1r_difference_from_ssf

    @property
    def zer_difference_from_ssf(self):
        """
        The difference between the database values of `zer`
        and the raw baseline projections of those values,
        without making any constant adjustments at all.

        These differences are added to the constants that
        are used in the baseline projections to ensure that
        the projections in the first projection year match
        the database values in that year.
        """
        return self._zer_difference_from_ssf

    @property
    def z1r_difference_from_ssf(self):
        """
        The difference between the database values of `z1r`
        and the raw baseline projections of those values,
        without making any constant adjustments at all.

        These differences are added to the constants that
        are used in the baseline projections to ensure that
        the projections in the first projection year match
        the database values in that year.
        """
        return self._z1r_difference_from_ssf

    @property
    def reference_h3t_used_to_compute_intertemporal_constants(self) -> np.ndarray:
        """
        Equivalent to h3t in the Ox implementation
        Functions of current and future exogenous variables affecting J1.
        This is the reference version of h3t, computed to calculation the projections
        for the base year that will be used as a reference projection when determining 
        the numeric derivatives for calculation of the intertemporal constants.

        Its only role is to preserve the appropriate information for benchmarking against Ox.
        """
        return self._reference_h3t_used_to_compute_intertemporal_constants

    @property
    def reference_c4t_used_to_compute_intertemporal_constants(self) -> np.ndarray:
        """
        Equivalent to c4t in the Ox implementation
        Functions of current and future exogenous variables affecting ZE.
        This is the reference version of h3t, computed to calculation the projections
        for the base year that will be used as a reference projection when determining 
        the numeric derivatives for calculation of the intertemporal constants.

        Its only role is to preserve the appropriate information for benchmarking against Ox.
        """
        return self._reference_c4t_used_to_compute_intertemporal_constants

    @property
    def x1_constants(self) -> np.ndarray:
        """
        The constant adjustments to X1 to ensure projections equal observed values.
        Add any intertemporal constant values to the X1R difference to SSF equation 
        results with zero constants to get the combined set of constants.
        """

        if hasattr(self, "_x1_constants"):
            return self._x1_constants

        result: np.ndarray = self.x1r_difference_from_ssf.copy()
        if not hasattr(self, "intertemporal_constants"):
            return result

        i = 0
        for index, variable_details in self.sym_data.intertemporal_constant_variables.iterrows():
            if variable_details['var_type'] == 'x1l':
                result[variable_details['sequence'], 0] += self.intertemporal_constants.loc[variable_details['name'], 'constant_value']
            i = i + 1

        self._x1_constants: np.ndarray = result
        return self._x1_constants

    @property
    def j1_constants(self) -> np.ndarray:
        """
        The constant adjustments to J1 to ensure projections equal observed values.
        Add any intertemporal constant values to the X1R difference to SSF equation results with zero constants
        to get the combined set of constants.
        """

        if hasattr(self, "_j1_constants"):
            return self._j1_constants

        result: np.ndarray = self.j1r_difference_from_ssf.copy()
        if not hasattr(self, "intertemporal_constants"):
            return result
        i = 0
        for index, variable_details in self.sym_data.intertemporal_constant_variables.iterrows():
            if variable_details['var_type'] == 'j1l':
                result[variable_details['sequence'], 0] += self.intertemporal_constants.loc[variable_details['name'], 'constant_value']
            i = i + 1

        self._j1_constants: np.ndarray = result
        return self._j1_constants

    @property
    def ze_constants(self) -> np.ndarray:
        """
        The constant adjustments to ZE to ensure projections equal observed values.
        Add any intertemporal constant values to the X1R difference to SSF equation results with zero constants
        to get the combined set of constants.
        """

        if hasattr(self, "_ze_constants"):
            return self._ze_constants

        result: np.ndarray = self.zer_difference_from_ssf.copy()
        if not hasattr(self, "intertemporal_constants"):
            return result

        i = 0
        for index, variable_details in self.sym_data.intertemporal_constant_variables.iterrows():
            if variable_details['var_type'] == 'zel':
                logging.debug(
                    f"At index {i} intertemporal constant is {self.intertemporal_constants.loc[variable_details['name'],'constant_value']} : shape is {self.intertemporal_constants.shape}")
                result[variable_details['sequence'], 0] += self.intertemporal_constants.loc[variable_details['name'], 'constant_value']
            i = i + 1

        self._ze_constants: np.ndarray = result
        return self._ze_constants

    @property
    def z1_constants(self) -> np.ndarray:
        """
        The constant adjustments to Z1 to ensure projections equal observed values.
        Add any intertemporal constant values to the X1R difference to SSF equation results with zero constants
        to get the combined set of constants.
        """

        if hasattr(self, "_z1_constants"):
            return self._z1_constants

        result: np.ndarray = self.z1r_difference_from_ssf.copy()
        if not hasattr(self, "intertemporal_constants"):
            return result
        i = 0
        for index, variable_details in self.sym_data.intertemporal_constant_variables.iterrows():
            if variable_details['var_type'] == 'z1l':
                result[variable_details['sequence'], 0] += self.intertemporal_constants.loc[variable_details['name'], 'constant_value']
            i = i + 1

        self._z1_constants: np.ndarray = result
        return self._z1_constants

    def __create_exogenous_variable_projections(self):
        """
        Populates the exogenous variable values through the projection years. 
        These values are determined outside of the model.

        When setting up baseline projections for exogenous variables, start by
        using the first projection year values for all of those variables and applying 
        them in all years through to the last projection year.
        
        Then adjust the database exogenous variable projections for:

        * effective labour productivity projections (based on population and productivity
        growth rates in each region)
        * energy efficiency improvement projections (based on projections of 
        autonomous energy efficiency improvements)
        """

        # Replicate projection base year values across all projection periods for all exogenous variables.
        projections: pd.DataFrame = pd.DataFrame(np.tile(self.first_projection_year_exo, (1, self.configuration.projection_years_count)))
        projections.columns = self.projection_years_column_labels
        projections.reset_index()

        # Add effective labour productivity and energy usage efficiency.
        effective_labour_productivity: EffectiveLabourProductivity = self.model.effective_labour_productivity
        rogy: pd.DataFrame = effective_labour_productivity.rogy
        energy_usage_efficiency: EnergyUsageEfficiency = self.model.energy_usage_efficiency
        for region in self.sym_data.regions_members:

            regional_effective_labour_productivity: pd.DataFrame = effective_labour_productivity.effective_productivity_deviations(region=region)
            regional_energy_usage_efficiency: pd.DataFrame = energy_usage_efficiency.sector_cumulative_energy_usage_efficiency_gains(region=region)
            consumption_energy_usage_efficiency: pd.DataFrame = energy_usage_efficiency.consumption_cumulative_energy_usage_efficiency_gains

            variable_prefix_ROGY: str = f"ROGY"
            rogy_name: str = f"{variable_prefix_ROGY}({region})"
            if self.sym_data.has_variables(variable_name_prefix=rogy_name):
                rogy_index: int = self.sym_data.variable_index(vector_name='exo', variable_name=rogy_name)
                rogy_units = self.sym_data.units_for_variables_with_given_name_prefix(vector_name='exo', variable_name_prefix=variable_prefix_ROGY)
                rogy_data: pd.DataFrame = rogy.loc[[region], self.projection_years_column_labels]
                if 'gdp' in rogy_units:
                    raise Exception(f"{rogy_name} has gdp units so shocks to that variable are not supported.")

                projections.loc[[rogy_index], :] = projections.loc[[rogy_index], :] + (rogy_data.to_numpy().flatten() / 100)
            # else:
            #     logging.warning(f"{rogy_name} is not in the SYM model.")

            shefc_name_prefix: str = f"SHEFC"
            shefc_name: str = f"{shefc_name_prefix}({region})"
            if self.sym_data.has_variables(variable_name_prefix=shefc_name_prefix):
                shefc_index: int = self.sym_data.variable_index(vector_name='exo', variable_name=shefc_name)
                shefc_units = self.sym_data.units_for_variables_with_given_name_prefix(vector_name='exo', variable_name_prefix=shefc_name_prefix)
                shefc_data: pd.DataFrame = consumption_energy_usage_efficiency.loc[[region], self.projection_years_column_labels]
                if 'gdp' in shefc_units:
                    raise Exception(f"{shefc_name} has gdp units so shocks to that variable are not supported.")
                projections.loc[[shefc_index], :] = projections.loc[[shefc_index], :] + (shefc_data.to_numpy().flatten() / 100)
            # else:
            #     logging.warning(f"{shefc_name} is not in the SYM model.")

            variable_prefix_SHL: str = 'SHL'
            variable_prefix_SHEF: str = 'SHEF'
            for sector in self.sym_data.sectors_members:

                shl_name: str = f"{variable_prefix_SHL}({region},{sector})"
                if self.sym_data.has_variables(variable_name_prefix=shl_name):
                    shl_index: int = self.sym_data.variable_index(vector_name='exo', variable_name=shl_name)
                    shl_units = self.sym_data.units_for_variables_with_given_name_prefix(vector_name='exo', variable_name_prefix=variable_prefix_SHL)
                    shl_data: pd.DataFrame = regional_effective_labour_productivity.loc[[sector], self.projection_years_column_labels]
                    if 'gdp' in shl_units:
                        raise Exception(f"{shl_name} has gdp units so shocks to that variable are not supported.")
                    projections.loc[[shl_index], :] = projections.loc[[
                        shl_index], :] + (shl_data.to_numpy().flatten() / 100)
                # else:
                #     logging.warning(f"{shl_name} is not in the SYM model.")

                shef_name: str = f"{variable_prefix_SHEF}({sector},{region})"
                if self.sym_data.has_variables(variable_name_prefix=shef_name):
                    shef_index: int = self.sym_data.variable_index(vector_name='exo', variable_name=shef_name)
                    shef_units = self.sym_data.units_for_variables_with_given_name_prefix(vector_name='exo', variable_name_prefix=variable_prefix_SHEF)
                    shef_data: pd.DataFrame = regional_energy_usage_efficiency.loc[[sector], self.projection_years_column_labels]
                    if 'gdp' in shef_units:
                        raise Exception(f"{shef_name} has gdp units so shocks to that variable are not supported.")
                    projections.loc[[shef_index], :] = projections.loc[[shef_index], :] + (shef_data.to_numpy().flatten() / 100)
                # else:
                #     logging.warning(f"{shef_shock_name} is not in the SYM model.")

        # Index with variable names.
        projections.index = self.sym_data.vector_variable_names(vector_name='exo')

        # Store the exogenous projections that will be augmented for other projections.
        self._exo_projections: pd.DataFrame = projections

    def __evaluate_first_projection_year_vector_projections(self):
        """
        Computes the values of the model equation vectors in the first projection year, 
        using the functions of future exogenous variables, the stable manifold, etc
        """

        self._exo_first_year_projections = self.exo_projections.loc[:, [str(self.first_projection_year)]].to_numpy()

        self._yxr_first_year_projections = self.yxr_initial_values.to_numpy().copy()

        # er = h1t*x[][1] + h2t*exog[][1] + h3t[][1];
        self._yjr_first_year_projections = \
            self.stable_manifold.H1 @ self.yxr_first_year_projections + \
            self.stable_manifold.H2 @ self.exo_first_year_projections + \
            self._h3t[:, [0]]

        # tzl = mu1t*x[][1] + mu4t*exog[][1] + c4t[][1];
        self._exz_first_year_projections = \
            self.stable_manifold.mu1 @ self.yxr_first_year_projections + \
            self.stable_manifold.mu2 @ self.exo_first_year_projections + \
            self._c4t[:, [0]]

        # z1l projections = d5n*x[][1]+d7n*exog[][1]+d6n*er+d4n*tzl+cz6[][1]
        self._z1l_first_year_projections = \
            self.state_space_form.delta('z1l', 'yxr') @ self.yxr_first_year_projections + \
            self.state_space_form.delta('z1l', 'exo') @ self.exo_first_year_projections + \
            self.state_space_form.delta('z1l', 'yjr') @ self.yjr_first_year_projections + \
            self.state_space_form.delta('z1l', 'exz') @ self.exz_first_year_projections + \
            self.z1r_difference_from_ssf

    @property
    def yxr_first_year_projections(self) -> np.ndarray:
        """
        Projections of X1_t (yxr) in the first projection year
        """
        return self._yxr_first_year_projections

    @property
    def yjr_first_year_projections(self) -> np.ndarray:
        """
        Projections of J1_t (yjr) in the first projection year
        """
        return self._yjr_first_year_projections

    @property
    def exz_first_year_projections(self) -> np.ndarray:
        """
        Projections of ZE_t (exz) in the first projection year
        """
        return self._exz_first_year_projections

    @property
    def z1l_first_year_projections(self) -> np.ndarray:
        """
        Projections of Z1_t (z1l=z1r) in the first projection year
        """
        return self._z1l_first_year_projections

    @property
    def exo_first_year_projections(self) -> np.ndarray:
        """
        Projections of EXO_t in the first projection year
        """
        return self._exo_first_year_projections

    @property
    def first_year_original_projections_of_variables_adjusted_by_intertemporal_constants(self) -> np.ndarray:
        """
        The first year projected values for the variables that are being
        adjusted by the intertemporal constants.

        The values are those for the projection that is not adjusted by intertemporal constants.

        It is used in the calculation of the intertemporal constants but it is only preserved
        as a property to facilitate benchmarking against Ox.
        """
        return self._first_year_original_projections_of_variables_adjusted_by_intertemporal_constants

    @property
    def first_year_original_projections_of_yxr(self) -> np.ndarray:
        """
        The first year projected values for the state variables.
        
        This is only required for benchmarking against Ox.
        """
        return self._first_year_original_projections_of_yxr

    @property
    def first_year_original_projections_of_yjr(self) -> np.ndarray:
        """
        The first year projected values for the costate variables.

        This is only required for benchmarking against Ox.
        """
        return self._first_year_original_projections_of_yjr

    @property
    def first_year_original_projections_of_exz(self) -> np.ndarray:
        """
        The first year projected values for the expected endogenous variables exz.

        This is only required for benchmarking against Ox.
        """
        return self._first_year_original_projections_of_exz

    @property
    def first_year_original_projections_of_z1l(self) -> np.ndarray:
        """
        The first year projected values for the endogenous variables.

        This is only required for benchmarking against Ox.
        """
        return self._first_year_original_projections_of_z1l

    @property
    def first_year_observed_values_of_variables_adjusted_by_intertemporal_constants(self) -> np.ndarray:
        """
        Returns the observed values, in the first projection year, of the 
        variables that are adjusted by intertemporal constants.

        The values are not adjusted after they are initially set so they
        can be relied up and reused by the constant calculation process in this
        baseline projections and in any later relinearisation projections.
        """
        return self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants

    @property
    def intertemporal_constants(self) -> pd.DataFrame:
        """
        The data frame of intertemporal constants information
        obtained from SYM but augmented with the values of the
        intertemporal constants.

        The dataframe is indexed by the variable names.

        The constant values are stored in a column called `constant_value`.
        """
        return self._intertemporal_constants

    @property
    def partial_derivatives_wrt_intertemporal_constants(self) -> np.ndarray:
        """
        The matrix of partial derivatives used in Newton's method to
        compute the intertemporal constants.

        This is a property of the class just to support benchmarking against Ox.
        """
        return self._partial_derivatives

    def __calculate_intertemporal_constants(self):
        """
        ### Overview

        Computes the intertemporal constant adjustments to jump and other variables to align starting data
        values with model projections in the first year.

        Step 1.
        Compute functions of future exogenous variables through all years of the projection.

        Step 2.
        For the variables that are to be adjusted by the intertemporal
        constants, compute their projected values in the base projection year
        and store these values for comparison to perturbed base year projections so we can calculate
        the derivatives matrix needed to set the intertemporal constants.
        Also store the values of each of the 4 vectors in the model in the base year for benchmarking.

        Step 3.
        Initialise the partial derivatives matrix. This is the matrix of derivatives of each of the
        variables that is adjusted by intertemporal constants, with respect to each of the intertemporal
        constants, in the SSF equations (each of which is linear).

        Iterate over the intertemporal constants, perturbing each and recalculating the base year projections
        of the variables that are adjusted by intertemporal constants so that we can 
        estimate the relevant numeric derivatives.

        At the end of this step, update the perturbed variable details to `None` so that
        all constants associated with the difference between observed values and SSF calculated values
        are at their unpurturbed values when doing actual baseline projections.

        Step 4.
        Apply Newton's method to solve for the intertemporal constants.
        Multiply the difference between the observed values of the variables that are adjusted by
        the intertemporal constants and their original projected values, in the first projection year,
        by the inverse of the partial derivatives matrix.

        This only needs to be done once because the SSF of the model is linear so Newton's method
        gets to the solution in one iteration.
        """

        # Step 1.
        self._compute_functions_of_future_exogenous_variables(exogenous_projections=self.exo_projections)
        self._reference_c4t_used_to_compute_intertemporal_constants = self.c4t.copy()
        self._reference_h3t_used_to_compute_intertemporal_constants = self.h3t.copy()

        # Step 2.
        
        # Compute the first year projections - noting that no intertemporal 
        # constant adjustments have been made yet.
        self.__evaluate_first_projection_year_vector_projections()

        # Capture the first year projections of the intertemporal variables. 
        # These are used in this function for Newton's method below
        # and they are also deep-copied and stored as a property of the 
        # class for benchmarking purposes.
        self._first_year_original_projections_of_variables_adjusted_by_intertemporal_constants = self.first_year_projections_of_variables_adjusted_by_intertemporal_constants.copy()

        # For benchmarking purposes only, preserve the original first year projections
        self._first_year_original_projections_of_yxr = self.yxr_first_year_projections.copy()
        self._first_year_original_projections_of_yjr = self.yjr_first_year_projections.copy()
        self._first_year_original_projections_of_exz = self.exz_first_year_projections.copy()
        self._first_year_original_projections_of_z1l = self.z1l_first_year_projections.copy()

        # Step 3.
        # Compute the partial derivatives matrix
        self._partial_derivatives = np.zeros(shape=(len(self.sym_data.intertemporal_constant_variables), len(
            self.sym_data.variables_adjusted_by_intertemporal_constants)))
        i = 0
        for index, variable_details in self.sym_data.intertemporal_constant_variables.iterrows():
            self.__update_perturbed_variable(variable_details=variable_details)
            self._compute_functions_of_future_exogenous_variables(exogenous_projections=self.exo_projections)
            self.__evaluate_first_projection_year_vector_projections()
            self._partial_derivatives[:, [i]] = (
                self.first_year_projections_of_variables_adjusted_by_intertemporal_constants -
                self._first_year_original_projections_of_variables_adjusted_by_intertemporal_constants) / Constants().DELTA
            i += 1

        # Generate the baseline projection to use in computing partial derivatives
        # and to generate matrix values that are used later in projection processes.
        self.__update_perturbed_variable(variable_details=None)

        # Step 4.
        # Use Newtons method adjustment to compute intertemporal constant values
        self._intertemporal_constants = self.sym_data.intertemporal_constant_variables
        values: np.ndarray = np.linalg.inv(self._partial_derivatives) @ \
            (self.first_year_observed_values_of_variables_adjusted_by_intertemporal_constants -
             self.first_year_original_projections_of_variables_adjusted_by_intertemporal_constants)
        values = values.reshape((len(self.intertemporal_constants.index), 1))
        self._intertemporal_constants['constant_value'] = values

        logging.info("The intertemporal constants have been calibrated.")

# ------------------------------------------------------------------
# Purpose: Manage loading and provision of calibration database.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
import logging
import pandas as pd
import numpy as np
from gcubed import base
from gcubed.data.database import Database
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData


class CalibrationDatabase(Database):
    """
    Encapsulates all of the information about the calibration data used to calibrate parameters of a Model.

    Additional properties:

        database: the database that this calibration database was derived from.
        base_year: the base year for the database.

    """

    def __init__(self, database:Database, base_year:int) -> None:
        assert database is not None
        self._sym_data = database.sym_data
        self._configuration = self.sym_data.configuration
        self._variables = database.variables.copy()  # save memory by not taking a copy?
        self._data = database.data.copy()
        if database.base_year != base_year:
            logging.info(f"The parameter calibration database is being rebased from {database.base_year} to {base_year}")
            super().rebase(new_base_year=base_year)
        else:
            self._base_year = base_year
        self._data = self.data / 100

        self.__validate()

    @property
    def sym_data(self) -> SymData:
        return self._sym_data

    @property
    def configuration(self) -> ModelConfiguration:
        return self.sym_data.configuration
        
    def __validate(self):
        """
        Raise an exception if the calibration data is invalid
        """
        pass

    def rebase(self):
        raise Exception("Rebasing operations cannot be performed on a calibration database. Rebase the original database instead.")

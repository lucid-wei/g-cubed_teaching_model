# ------------------------------------------------------------------
# Purpose: Manage loading and provision of the database.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
import logging
from operator import index
import os
import pandas as pd
import numpy as np
from gcubed.base import Base
from gcubed.constants import Constants
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData


class Database(Base):
    """

    The database class is used directly but it is also 
    subclassed to support specific data usage scenarios.

    It encapsulates all of the information about the database 
    of values for all variables across a range of years.
    
    """

    def __init__(self, sym_data: SymData) -> None:

        assert sym_data is not None
        assert isinstance(sym_data, SymData)
        self._sym_data = sym_data
        self._base_year = self.configuration.base_year
        logging.info(f"Loading a database from {self.configuration.database_file}")
        self.__load_data()
        self.__validate()

    @property
    def sym_data(self) -> SymData:
        """
        The SYM processor output
        """
        return self._sym_data

    @property
    def configuration(self) -> ModelConfiguration:
        """
        The model configuration
        """
        return self.sym_data.configuration

    @property
    def variables(self) -> pd.DataFrame:
        """
        Metadata about the variables, contained in a dataframe 
        with columns for each type of metadata and with the rows indexed by variable"""
        return self._variables

    @property
    def data(self) -> pd.DataFrame:
        """
        The data itself, contained in a dataframe with columns 
        indexed by 4 digit (YYYY) year strings and with the rows indexed by variable
        names.

        """
        return self._data

    @property
    def variables_count(self) -> int:
        """
        The number of variables in the database.
        """
        return len(self.variables.index)

    @property
    def years_count(self) -> int:
        """
        The number of years in the database.
        """
        return len(self.data.columns)

    @property
    def years_column_names(self) -> pd.Index:
        """
        The year column names for the data.
        """
        return self.data.columns

    @property
    def base_year(self) -> int:
        """
        The (YYYY) format base year for the data. All indexes in the database
        are based in the specified year.  Databases (but not database subclasses)
        can be rebased to different years.
        """
        return self._base_year
    
    @property
    def first_available_year(self):
        """
        The first year of data in the database.
        """
        return self._first_available_year

    @property
    def last_available_year(self):
        """
        The last year of data in the database.
        """
        return self._last_available_year


    def __load_data(self):
        """
        ### Overview

        Import the data from the database CSV file, splitting it into 
        the variable metadata and the data itself.
        """
        filename = self.configuration.database_file
        assert os.path.isfile(filename)
        (self._variables, self._data) = self.load_data(filename)
        self._data = self._data.astype(float)
        self._variables.columns = ("order", "name", "description", "units", "region")
        self._variables["order"].astype("int")
        self._first_available_year = int(self.data.columns[0])
        self._last_available_year = int(self.data.columns[-1])

    def __validate(self):
        """        
        Raise an exception if the database is invalid.
        """
        assert len(self._variables.columns) == 5
        assert self.data is not None
        assert self.variables is not None
        assert self.years_count > 0
        assert self.variables_count > 0

        assert self.configuration.original_first_projection_year <= self.last_available_year
        assert self.configuration.base_year >= self.first_available_year
        assert self.configuration.calibration_year >= self.first_available_year
        assert self.configuration.calibration_of_carbon_coefficients_year >= self.first_available_year
        assert self.configuration.linearisation_year >= self.first_available_year

        # Make sure that the data is ordered properly from the first year to the last year.
        i = 0
        for year in range(self.first_available_year, self._last_available_year+1):
            assert str(year) ==  self.data.columns[i]
            i += 1

        if not (self.sym_data.combined_variable_summary.loc[:,'units'] == self.variables.loc[:,'units']).all():
            raise Exception("The variable units specified in the database do not match those from the SYM model definition.")

        self.__validate_base_year()

    def __validate_base_year(self):
        """
        Make sure that the price index is equal to zero for all regions, in the base year.
        """
        assert self.data.loc[self.data.index.str.contains(Constants().PRID_PREFIX), str(self.base_year)].sum() == 0

    def export_to_csv(self, filename:str):
        """
        Export the database to a CSV file, making sure that the file extension is '.csv'.
        """
        if filename.endswith('.csv'):
            np.savetxt(filename,self.data, delimiter=",")                
        else:
            np.savetxt(f"{filename}.csv", self.data, delimiter=",")

    def rebase(self, new_base_year: int):
        """
        Rebase a database so indices have a new base year.
        This can be used to convert the database used for calibration
        to a database with the base year equal to the start year
        for projections (eg. 2011 to 2018).

        Note that this script draws on the approach in the G-Cubed utilities/rebase.ox script.

       ### Arguments
            new_base_year (int): a YYYY formatted new base year for the database.
        """

        # Adjust the price indices
        for prefix in Constants().LOG_INDEX_PREFIXES:
            self.__rebase_log_index(variable_prefix=prefix,  new_base_year=new_base_year)
        for prefix in Constants().LAG_LOG_INDEX_PREFIXES:
            self.__rebase_log_index(variable_prefix=prefix,  new_base_year=new_base_year+1)
        for prefix in Constants().LEAD_LOG_INDEX_PREFIXES:
            self.__rebase_log_index(prefix, new_base_year=new_base_year-1)
        for prefix in Constants().INDEX_PREFIXES:
            self.__rebase_index(variable_prefix=prefix, new_base_year=new_base_year)

        # Adjust real GDP for the change in the base year.
        self.__rebase_real_gdp(new_base_year=new_base_year)

        # Store the current base year for this database after the rebasing.
        self._base_year = new_base_year

        # Check that the rebasing operation worked.
        self.__validate_base_year()


    def __rebase_log_index(self, variable_prefix: str, new_base_year: int):
        """
        Does a log index rebase, changing the base year for the chosen variables.
        This can also be used for rebasing lead and lag price and wage indices
        by simply modifying the new_base_year appropriately, adding 1 for a lag
        variable and subtracting 1 for a lead variable.
       ### Arguments
            variablePrefix: The text name of the variable to be rebased, up to
            but not including the component of the variable name in round brackets ().
            new_base_year: the new year to be applied in the output file, again in YYYY integer format
        """
        row_indices = self.data.index.str.startswith(f"{variable_prefix}(")
        data_for_variable: pd.DataFrame = self.data.loc[row_indices, :]
        self.data.loc[row_indices, :] = data_for_variable.sub(data_for_variable.loc[:, str(new_base_year)], axis=0)

    def __rebase_index(self, variable_prefix: str, new_base_year: int):
        """
        Does an index rebase, changing the base year for the chosen variables.
        This can also be used for rebasing lead and lag indices
        by simply modifying the new_base_year appropriately, adding 1 for a lag
        variable and subtracting 1 for a lead variable.
       ### Arguments
            variablePrefix: The text name of the variable to be rebased, up to
            but not including the component of the variable name in round brackets ().
            new_base_year: the new year to be applied in the output file, again in YYYY integer format
        """
        row_indices = self.data.index.str.startswith(f"{variable_prefix}(")
        data_for_variable: pd.DataFrame = self.data.loc[row_indices, :]
        self.data.loc[row_indices, :] = 100 * data_for_variable.div(data_for_variable.loc[:, str(new_base_year)], axis=0)

    def __rebase_real_gdp(self, new_base_year: int):
        """
        Does an index rebase, changing the base year for real GDP in each region.
        This updates the LGDPR and YRATR variables.

       ### Arguments
            new_base_year (int): the new year to be applied 
            in the output file, in YYYY integer format
        """
        real_gdp_row_indices = self.data.index.str.startswith(f"{Constants().REAL_GDP_PREFIX}(")
        real_gdp = self.data.loc[real_gdp_row_indices, :]
        nominal_gdp_row_indices = self.data.index.str.startswith(f"{Constants().NOMINAL_GDP_PREFIX}(")
        nominal_gdp = self.data.loc[nominal_gdp_row_indices, :]
        scale_factor = nominal_gdp.loc[:, str(new_base_year)].to_numpy() / real_gdp.loc[:, str(new_base_year)].to_numpy()
        rebased_real_gdp: np.ndarray = real_gdp.to_numpy() * scale_factor.reshape((len(scale_factor), 1))
        self.data.loc[real_gdp_row_indices, :] = rebased_real_gdp

        rebased_real_gdp_ratio: np.ndarray = 100 * rebased_real_gdp / rebased_real_gdp[0,:]
        yratr_row_indices = self.data.index.str.startswith(f"{Constants().US_REAL_GDP_RATIO_PREFIX}(")
        self.data.loc[yratr_row_indices, :] = rebased_real_gdp_ratio

    def rhs_vector_value(self, vector_name: str, year: int, use_neutral_real_interest_rate=False) -> np.ndarray:
        """

        ### Overview

        Retrieves data from the database for all of the variables in a specific RHS vector in the model.
        The data is retrieved for the specified year. 
        
        Note that some state variables have their data retrieved
        for the following year. 

        Note also that interest rate values can be overridden by the globally defined neutral real interest rate
        that is set in the model configuration file.

        The implementation steps are:

        1. get the rows for the variables of the given type in varmap.
        2. get the names of the variables in those rows from varmap.
        3. use those names to select the data from the calibration year database.
        4. set the values for those variables in the appropriate places in the vector to that data for that year
        using the indices specified in the varmap data.


       ### Arguments

        `vector_name`: The name of the vector to get the values for. This must be a RHS vector listed in
        the model's RHS vector names by the SymData class.

        `year`: The YYYY format year to get data for when populating the RHS vectors.
        e.g. 2011 implies linearise model equations around the values
        of the model variables in 2011 (or in adjacent years for leads/lags).

        `use_neutral_real_interest_rate`: True if interest rates are to be overridden with the
        model configuration neutral real interest rate and False otherwise.

       ### Returns
          
        A column vector with the requested values for the RHS vector or
        `None` if the vector has zero length.

        """

        if not vector_name in self.sym_data.rhs_vector_names:
            raise Exception(f"{vector_name} is not a RHS vector in the model. It should be one of {self.sym_data.rhs_vector_names}")

        vector_value: np.ndarray = np.zeros(shape=(self.sym_data.vector_length(vector_name=vector_name), 1), dtype=float)
        match vector_name:
            case "exo":
                (data, indices) = self.get_data_and_varmap_indices(vector_name=vector_name, year=year)
                vector_value[indices] = data

            case "x1r":
                (data, indices) = self.get_data_and_varmap_indices(vector_name=vector_name, year=(year+1))
                vector_value[indices] = data
                for variable_prefix in Constants().STATE_LEAD_VARIABLES:
                    (sequence, data) = self.get_data_and_varmap_indices_for_matching_variables(variable_prefix=variable_prefix, vector_name=vector_name, year=year)
                    vector_value[sequence] = data

            case "yxr":
                (data, indices) = self.get_data_and_varmap_indices(vector_name=vector_name, year=year)
                vector_value[indices] = data
                for variable_prefix in Constants().STATE_LEAD_VARIABLES:
                    (sequence, data) = self.get_data_and_varmap_indices_for_matching_variables(variable_prefix=variable_prefix, vector_name=vector_name, year=(year-1))
                    vector_value[sequence] = data

            case "j1r":
                (data, indices) = self.get_data_and_varmap_indices(vector_name=vector_name, year=(year+1))
                vector_value[indices] = data

            case "yjr":
                (data, indices) = self.get_data_and_varmap_indices(vector_name=vector_name, year=year)
                vector_value[indices] = data

            case "zer":
                (data, indices) = self.get_data_and_varmap_indices(vector_name=vector_name, year=year)
                vector_value[indices] = data

            case "exz":
                (data, indices) = self.get_data_and_varmap_indices(vector_name=vector_name, year=(year+1))
                vector_value[indices] = data

            case "z1r":
                (data, indices) = self.get_data_and_varmap_indices(vector_name=vector_name, year=year)
                vector_value[indices] = data

            case "_":
                raise Exception(f"Invalid RHS vector name {vector_name}.")

        if use_neutral_real_interest_rate:

            neutral_real_interest_rate: float = self.configuration.neutral_real_interest_rate
            var_type = self.sym_data.varmap_variable_type(vector_name)

            target_inflation_rates_for_regions: np.ndarray = self.get_data(name_regular_expression=f"{Constants().INFX_PREFIX}\(", years=[year]).to_numpy()

            # Replace all real interest rate values with r0 parameter value.
            for prefix in Constants().ALL_REAL_INTEREST_RATE_PREFIXES:
                vector_rows_in_map = self.sym_data.var_map.var_type == var_type
                variable_rows_in_map = self.sym_data.var_map.name.str.startswith(f"{prefix}(")
                rows_in_map = (vector_rows_in_map & variable_rows_in_map)
                sequences:pd.DataFrame = self.sym_data.var_map.loc[rows_in_map, ["sequence"]].to_numpy().flatten()
                if len(sequences) != 0:
                    vector_value[sequences] = neutral_real_interest_rate

            # Replace all nominal interest rate values with (r0 parameter value + target inflation rate).
            var_type = self.sym_data.varmap_variable_type(vector_name)
            for prefix in Constants().ALL_NOMINAL_INTEREST_RATE_PREFIXES:
                vector_rows_in_map = self.sym_data.var_map.var_type == var_type
                variable_rows_in_map = self.sym_data.var_map.name.str.startswith(f"{prefix}(")
                rows_in_map = (vector_rows_in_map & variable_rows_in_map)
                sequences:pd.DataFrame = self.sym_data.var_map.loc[rows_in_map, ["sequence"]].to_numpy().flatten()

                if len(sequences) != 0:
                    # logging.debug(f"Original nominal rates = \n{vector_value[sequences]}")
                    # logging.debug(f"equilibrium nominal rates  = \n{(target_inflation_rates_for_regions + self.configuration.neutral_real_interest_rate)}")
                    # logging.debug(f"constant adjustment = \n{vector_value[sequences] - (target_inflation_rates_for_regions + self.configuration.neutral_real_interest_rate)}")
                    vector_value[sequences] = target_inflation_rates_for_regions + neutral_real_interest_rate
                    # logging.debug(f"Returning nominal rates = \n{vector_value[sequences]}")
        return vector_value

    def get_data_and_varmap_indices(self, vector_name: str, year: int) -> tuple:
        """
       ### Arguments

        vector_name: The three character name of the vector that is to be populated 
        with data.

        year: the 4 digit integer specifying the year in the database that will be used
        to source the data that will be inserted into the named vector.

        This method uses the varmap file created by the SYM processor, 
        finding those rows in the varmap that have a value in the var_type column 
        that match the given vector_name, e.g. 'x1r'.
        The matching rows contain the variable names and their indices within the
        vector that has been named as an input to the function.

        The variable names are used to determine the rows of the database where the
        data will be sourced.

        The year determines the column in the database where the data will be sourced.

        A tuple is returned. That tuple contains a numpy vector of the data that has been 
        extracted from the database and a vector of indices indicating where, in the specified
        vector, that data should be inserted.

        """
        variable_type:str = self.sym_data.varmap_variable_type(vector_name=vector_name)
        map = self.sym_data.var_map[self.sym_data.var_map.var_type == variable_type]
        
        names = map.name
        indices = map.sequence
        result: np.ndarray = self.data.loc[names, str(year)].to_numpy()
        return (result.reshape((len(result), 1)), indices)

    def get_data_and_varmap_indices_for_matching_variables(self, variable_prefix: str, vector_name: str, year: int):
        """
        Gets matching data for the given variable prefix for a given vector.

       ### Arguments

        variable_prefix: The prefix for the variable name

        vector_name: the name of the vector to be populated.

        Returns a tuple containing the indices in the vector to be populated (as a list of integers) 
        and the values to use to do the populating as a numpy column vector.
        """
        map: pd.DataFrame = self.sym_data.var_map[self.sym_data.var_map['name'].str.contains(variable_prefix)]

        variable_type:str = self.sym_data.varmap_variable_type(vector_name=vector_name)
        map = map[map.var_type.str.match(variable_type)]
        
        result: np.ndarray = self.data.loc[map.name, str(year)].to_numpy()

        return (map.sequence.to_list(), result.reshape((len(result), 1)))

    def get_data(self, name_regular_expression: str, years: list) -> pd.DataFrame:
        """

        Gets data for the set of variables with variable names that match the given regular
        expression.

       ### Arguments

        name_regular_expression (str): The variable selection criteria. It can be any 
        regular expression that works with the Python regex package. 
        
        To get all variables with a name that starts with INF, use "^INF".

        To get the specific variable, INFL(UU), use "^INFL\(UU\)".

        To get the the INFL variables for all regions, use "^INFL\(".

        years (list): the list of years for which the data is to be retrieved. Note that
        this can be a list of integer values or a list of strings.

       ### Returns
        
        pd.DataFrame: a copy of the data for the specified year for 
        all variables with names matching the given regular expression
        where the names are matched against the row index (labels) in 
        the database.
        """
        selected_rows = self.data.index.str.contains(name_regular_expression)
        if not years:
            return self.data.loc[selected_rows, :].copy()
        if isinstance(years, int):
            return self.data.loc[selected_rows, [str(years)]].copy()
        if isinstance(years, str):
            return self.data.loc[selected_rows, [years]].copy()
        if isinstance(years, list):
            # works with list of integers or strings
            selected_columns = [str(x) for x in years]
            return self.data.loc[selected_rows, selected_columns].copy()
        raise Exception(
            f"There is no data available matching {name_regular_expression} in {years}")

    def update_data(self, new_data: pd.DataFrame):
        """
        Replace the existing data property with a new dataframe. All of the data is replaced.

        This is useful if you need to do projections and then treat those projections as actual data
        in a subsequent step in your analysis pipeline.

       ### Arguments

        new_data (pd.DataFrame): The new dataframe to use.
        """
        if not self._data.index.equals(new_data.index):
            raise Exception("The new database does not describe the same set of variables as the old database.")
        self._data = new_data

    def has_data(self, year:int) -> bool:
        """
        Used to check if there is a column of data in the database for the specified year.

        Args:

        year (int): The 4 digit integer value of the year (YYYY).

       ### Returns
        bool:  True if the database has data for the specified year and False otherwise
        """
        return str(year) in self.data.columns

    @property 
    def has_data_for_all_projection_years(self) -> bool:
        """
        This property is used when determining whether the database has been populated
        with projections, in which case those projections provide values, now stored 
        as data, out to the end year of the projections.

        bool: True if the database has data for the last projection year.
        """
        return self.has_data(year = self.configuration.last_projection_year)

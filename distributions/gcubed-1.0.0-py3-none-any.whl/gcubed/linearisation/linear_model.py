# ------------------------------------------------------------------
# Purpose: Linearise the model to produce the partial derivative
# matrices that embody the model dynamics.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
import logging
import time
import pandas as pd
import numpy as np
import sys
import importlib
from gcubed.data.gdp_scaled_database import GDPScaledDatabase
from gcubed.model import Model
from gcubed.base import Base
from gcubed.constants import Constants
from gcubed.sym_data import SymData
from gcubed.model_configuration import ModelConfiguration
from gcubed.linearisation.model_solver import ModelSolver


class LinearModel(Base):
    """

    ### Overview
    
    The algebra embodied in this class follows 
    https://www.msgpl.com.au/Manuals2021/GGGv20JManual/softwaremanual/algorithm.pdf
    
    The notation has been extended to also include equations for 
    expected endogenous variables to include exogenous variables.

    This class provides the ability to work with the model equations. It:

    1. Computes the partial derivatives of the model equations
    so that an approximation of the model can be expressed as 
    a set of linear equations.
    2. Constructs the matrices of constants associated with the 
    state-space form of the linearised model. This involves eliminating
    the endogenous variables from the model via substitution.

    To use this class:

    1.  instantiate it with a model.
    2.  run the __compute_partial_derivatives() method.

    Once this sequence of steps has been completed without raising an exception,
    the matrices associated with the state space form will be accessible
    as properties of the linear model to support solving the model.

    Instantiation determines the values for the RHS variable vectors
    based upon the model's database and the year that has been chosen
    to determine the variable values that the model will be linearised 
    around.

    These RHS variable vector values, and the implied LHS variable vector values 
    are exposed as properties of the linear model. The names of these vector 
    properties are 3 character acronyms:

    The linear model supports evaluation of the model equations to obtain
    values for the LHS and RHS vectors of variables defined in sym_data.

    To understanding the naming conventions, the partial 
    derivatives matrix associated with the partials of
    x1l with respect to z1r are stored in a property called x1l_z1r_partials.
    The same naming convention is used for all partials matrices:
    <LHS_vector_name>_<RHS_vector_name>_partials.
    """

    def __init__(self, model: Model, use_neutral_real_interest_rate: bool = True) -> None:
        """
        ### Arguments

        `model`: The model that is to be linearised with the linearisation
        year specified as part of the model configuration.

        `use_neutral_real_interest_rate`: If `True`, use the neutral real interest rate
        for the values around which linearisation is done, otherwise use the real interest rate
        from the database (which may be negative). This parameter defaults to `True`.
        """

        # Set this switch to true when the partial derivatives have been computed.
        self._linear_model_is_available: bool = False

        # Track the use of the neutral real interest rate to ensure
        # that baseline projections etc are done consistently.
        self._use_neutral_real_interest_rate: bool = use_neutral_real_interest_rate

        assert model is not None
        self._model = model

        logging.info(f"Linearising the model using data with a base year of {self.configuration.linearisation_year}")
        self._linearisation_database = GDPScaledDatabase(database=self.model.database, base_year=self.configuration.linearisation_year)

        # Set up the LHS vectors as vectors of zeros.
        self.__configure_lhs_vectors()
        
        # Set up the RHS vectors for the model using data for the linearisation year.
        # First check which linearisation approach to use.
        if not self.model.configuration.linearise_around_strict_model_solution:
            # Do the standard kind of linearisation
            self.__load_rhs_vectors(
                linearisation_year=self.configuration.linearisation_year,
                use_neutral_real_interest_rate=use_neutral_real_interest_rate
                )
        else:
            # Do the fancy linearisation where we search for a strict solution to the model first.
            model_solver: ModelSolver = ModelSolver(
                model=self.model, 
                linearisation_year=self.configuration.linearisation_year,
                use_neutral_real_interest_rate = use_neutral_real_interest_rate)
            if not model_solver.solution_found:
                raise Exception(f"Failed to find a solution to the model for data values near those in the database for linearisation year {self.configuration.linearisation_year}. Linearisation cannot proceed.")
            for vector_name in self.sym_data.rhs_vector_names:
                rhs_vector:pd.DataFrame = getattr(model_solver, f"_{vector_name}")
                if rhs_vector is not None:
                    setattr(self, f"_{vector_name}", rhs_vector)
                else:
                    raise Exception(f"Failed to get RHS vector {vector_name} from the solved model.")


        # Import the model equations.
        sys.path.append(self.configuration.sym_directory)
        equations_module = importlib.import_module(self.configuration.sym_output_filename_prefix)
        equations_class = getattr(equations_module, "Equations")
        self._equations = equations_class(x1l=self._x1l,
                                          j1l=self._j1l,
                                          zel=self._zel,
                                          z1l=self._z1l,
                                          x1r=self._x1r,
                                          j1r=self._j1r,
                                          z1r=self._z1r,
                                          zer=self._zer,
                                          yjr=self._yjr,
                                          yxr=self._yxr,
                                          exo=self._exo,
                                          exz=self._exz,
                                          par=self.model.parameters.parameter_values_vector)

        # Solve for LHS vectors using the model equations,
        # the parameters and the RHS vectors. Store the results as benchmark
        # values for calculating partial derivatives.
        self.__compute_benchmark_equation_results()

        # Generate differences in LHS variables from those used on RHS to evaluate equations
        # These two lines of code do not typically need to run but give insight into linearisation.
        # self.__generate_nonlinear_equation_differences()
        # self.nonlinear_equation_differences.to_csv(f"{self.model.configuration.benchmarking_reports_directory}nonlinear equation LHS-RHS differences.csv")

        # Load the map from RHS variables to model equations to use when computing partial derivatives.
        self.__load_equation_map()

        # Compute the partial derivatives
        self.__compute_partial_derivatives()

        self.__validate()

    def __validate(self):
        """
        Validate the linear model details
        """

        # Check we have all vectors and they are the right lengths.
        for vector_name in self.sym_data.lhs_vector_names:
            vector = self.get_vector_by_name(vector_name=vector_name)
            assert vector is not None
            assert len(vector) == self.sym_data.vector_length(
                vector_name=vector_name)

        if self.linear_model_is_available:
            logging.info("The model has been linearised.")
        else:
            logging.error("The model linearisation failed. Changes are required before proceeding.")

    @property
    def linearisation_database(self) -> GDPScaledDatabase:
        """
        The database containing the values that will be utilised to populate 
        variable values for the linearisation.
        """
        return self._linearisation_database

    @property
    def linear_model_is_available(self) -> bool:
        """
        `True` if the model has been linearised 
        successfully and `False` otherwise (either because linearisation has not
        finished or linearisation was not possible for whatever reason).
        """
        return self._linear_model_is_available

    @property
    def use_neutral_real_interest_rate(self) -> bool:
        """
        This property is checked when doing baseline projections
        to ensure that baseline projections never start from the
        neutral real interest rate unless the linearisation was done
        around the neutral real interest rate.

        `True` if the linearisation used the neutral real interest rate
        and `False` otherwise.
        """
        return self._use_neutral_real_interest_rate

    @property
    def equations(self):
        """
        The equations subclass instance that implements the functions
        for each of the nonlinear equations in the model.
        """
        return self._equations

    @property
    def model(self):
        """
        The model being linearised.
        """
        return self._model
    
    @model.setter
    def model(self, value: Model):
        """
        ### Overview

        Updates the model associated with this linear model.

        Do not use this setter. It is just provided to assist with unit
        testing experiments.
        """
        if value is None:
            raise Exception("The new model must not be None")
        if not isinstance(value, Model):
            raise Exception(f"The new model must be a gcubed.Model. It is instead a {type(value)}")
        self._model = value

    @property
    def sym_data(self) -> SymData:
        """
        The SYM data for the model being linearised.
        """
        return self.model.sym_data

    @property
    def configuration(self) -> ModelConfiguration:
        """
        The configuration details for the model 
        being linearised.
        """
        return self.model.configuration

    @property
    def equations_map(self) -> dict[tuple[str, int], list[tuple[str, int]]]:
        """
        ### Overview

        This is only a public property to assist with unit testing.
        Do not use it directly for other purposes.

        The map is populated from the SYM processor output and is used to make
        the calculation of partial derivatives more efficient, only calculating
        those derivatives that are not zero by definition.

        ### Returns

        The map from each RHS variable in the model to the list of 
        LHS variables (equations) that depend on it.
        """
        return self._equations_map

    def get_vector_by_name(self, vector_name) -> np.ndarray:
        """
        ### Overview

        Use the name of the vector to retrieve its numpy array value.
        These values have been set using data in the database.

        ### Arguments

        `vector_name`: The name of the LHS or RHS vector.
        
        ### Returns
        
        The named column vector.
        
        """
        if not hasattr(self, "_{}".format(vector_name)):
            raise Exception("There is no vector for {}".format(vector_name))
        return getattr(self, "_{}".format(vector_name))

    def get_original_lhs_vector_by_name(self, lhs_vector_name:str) -> np.ndarray:
        """

        ### Overview

        This function is useful for benchmarking the model's nonlinear equation evaluations.

        Use the name of the vector to retrieve its numpy array value.
        These values have been set by evaluating the model's non-linear equations
        using the RHS vector values for the base year chosen for the linearisation.

        ### Arguments

        `lhs_vector_name`: The name of the LHS vector, e.g. 'x1l' or 'j1l'.
        
        ### Returns
        
        The named LHS column vector.

        """
        if not lhs_vector_name in self._original_lhs_vectors:
            raise Exception(f"The requested vector, {lhs_vector_name}, is not a LHS vector in the model.")
        return self._original_lhs_vectors[lhs_vector_name]

    def get_partials(self, lhs_vector_name:str, rhs_vector_name:str) -> np.ndarray:
        """

        ### Overview

        Use the name of the LHS vector and the RHS vector to retrieve 
        the numpy matrix value for the partial derivatives.

        The matrices of partial derivatives are stored in a dictionary indexed
        by the lhs and rhs vector names.

        ### Arguments

        `lhs_vector_name`: The name of the LHS vector, e.g. 'x1l' or 'j1l'.

        `rhs_vector_name`: The name of the RHS vector, e.g. 'yxr' or 'j1r'.

        ### Returns
        
        The required partial derivatives as a dataframe 
        with variable names as the row and column labels.

        """
        if self._partial_derivatives is None:
            raise Exception(f"Attempted to access partial derivatives {lhs_vector_name} on {rhs_vector_name} before it was created.")
        key = (lhs_vector_name, rhs_vector_name)
        if key in self._partial_derivatives:
            return self._partial_derivatives[key]
        return None

    def get_partials_as_dataframe(self, lhs_vector_name, rhs_vector_name) -> pd.DataFrame:
        """

        ### Arguments

        `lhs_vector_name`: The name of the LHS vector, e.g. 'x1l' or 'j1l'.

        `rhs_vector_name`: The name of the RHS vector, e.g. 'yxr' or 'j1r'.

        ### Returns
        
        The required partial derivatives as a dataframe 
        with variable names as the row and column labels.

        """
        if self._partial_derivatives is None:
            raise Exception(f"Attempted to access partial derivatives {lhs_vector_name} on {rhs_vector_name} before it was created.")
        key = (lhs_vector_name, rhs_vector_name)
        if key in self._partial_derivatives:
            result: pd.DataFrame = pd.DataFrame(self._partial_derivatives[key])
            result.index = self.sym_data.vector_variable_names(vector_name=lhs_vector_name)
            result.columns = self.sym_data.vector_variable_names(vector_name=rhs_vector_name)
            return result
        return None

    def __configure_lhs_vectors(self):
        """
        ### Overview

        Create the LHS vectors that are used by the model equations.

        Initialises the LHS vectors with zeros.
        """
        for vector_name in self.sym_data.lhs_vector_names:
            setattr(self, "_{}".format(vector_name), np.zeros(
                shape=(self.sym_data.vector_length(vector_name=vector_name), 1), dtype=float))

    def __load_rhs_vectors(self, linearisation_year: int, use_neutral_real_interest_rate:bool):
        """

        ### Overview

        Create and set values for the RHS vectors that are used by the 
        model equations.

        Do not create vectors if they have no variables (are zero length).

        ### Arguments

        `linearisation_year`: The year in which the model is linearised.
        e.g. 2011 implies linearise model equations around the values
        of the model variables in 2011 (or in adjacent years for leads/lags
        
        `use_neutral_real_interest_rate`: If `True`, use the neutral real interest rate,
        otherwise use the actual real interest rate (which may be negative).
        
        """
        # Initialise RHS vectors with database values from the linearisation base year or the lead/lag from that year.
        for vector_name in self.sym_data.rhs_vector_names:
            rhs_vector:pd.DataFrame = self.linearisation_database.rhs_vector_value(vector_name=vector_name, year=linearisation_year, use_neutral_real_interest_rate=use_neutral_real_interest_rate)
            if rhs_vector is not None:
                setattr(self, f"_{vector_name}", rhs_vector)
            else:
                raise Exception(f"Failed to get RHS vector {vector_name} from the linearisation database.")

    def __compute_benchmark_equation_results(self):
        """
        ### Overview

        Compute the benchmark LHS vector values using supplied RHS values.
        These are used in computing the non-linear equations in the model.
        """

        self._original_lhs_vectors: dict[str, np.ndarray] = dict()
        for lhs_vector_name in self.sym_data.lhs_vector_names:
            lhs_vector = getattr(self, "_{}".format(lhs_vector_name))
            for lhs_index in range(len(lhs_vector)):
                function_name = "{}_{}".format(lhs_vector_name, lhs_index)
                if hasattr(self.equations, function_name):
                    func = getattr(self.equations, function_name)
                    func()
                else:
                    # logging.warning("No {} equation for element {}".format(lhs_vector_name, lhs_index))
                    pass
            self._original_lhs_vectors[lhs_vector_name] = lhs_vector.copy()

    def __load_equation_map(self):
        """
        ### Overview

        Uses the eqnmap output from the sym processor to create a map from each
        RHS variable (vector + index combination) to the equations that include
        that variable on the RHS.

        This map ensures we only have to evaluate the relevant equations when computing
        the partial derivatives of the model equations when considering each RHS variable.
        """

        self._equations_map: dict[tuple[str, int], list[tuple[str, int]]] = dict()
        """
        This is a map from RHS variable identifiers to LHS equation identifiers.
        Each RHS and LHS identifier is a tuple: a string, identifying the vector
        name (eg: x1l or zer) and an integer, identifying the string index.
        """

        rows: pd.DataFrame = pd.read_csv(self.configuration.eqnmap_file, header=None)
        rows.columns = ['name', 'number']
        # Remove 'par' RHS entries - they are not needed.
        rows = rows.loc[~(rows.name == 'par'), :]

        lhs: tuple[str, int] = None
        rhs: tuple[str, int] = None

        equationCount = 0
        for row in rows.itertuples(index=False):
            if row[0].endswith('l'):
                equationCount = equationCount + 1
                lhs = (row[0], int(row[1]))
                rhs = None
                continue
            else:
                rhs = (row[0], int(row[1]))

            if rhs is None:
                continue

            if rhs in self._equations_map:
                self._equations_map[rhs].append(lhs)
            else:
                self._equations_map[rhs] = [lhs]

    def __compute_partial_derivatives(self):
        """
        ### Overview

        Generate the matrices that reflect the linear approximation
        to the model. The model is linearised around the data for 
        a specific year that is specified in the model configuration.

        Do not compute partial derivatives for any vectors with zero length.

        Use the equation map to ensure that only non-zero partial derivatives
        are calculated. The others are, obviously, zero.
        """

        # Create the dictionary where the partial derivative matrices will be stored.
        self._partial_derivatives: dict[tuple[str, str], np.ndarray] = dict()

        # Initialise the matrices of partial derivatives

        for lhs in self.sym_data.lhs_vector_names:
            lhs_length = self.sym_data.vector_length(vector_name=lhs)
            if lhs_length == 0:
                continue

            for rhs in self.sym_data.rhs_vector_names:
                rhs_length = self.sym_data.vector_length(vector_name=rhs)
                if rhs_length == 0:
                    continue
                self._partial_derivatives[(lhs, rhs)] = np.zeros((lhs_length, rhs_length), dtype=float)

        for rhs in self.sym_data.rhs_vector_names:

            start_time: float = time.time()

            rhs_length = self.sym_data.vector_length(vector_name=rhs)
            if rhs_length == 0:
                continue

            # Get the vector of RHS variables in the named rhs vector
            rhs_vector = self.get_vector_by_name(vector_name=rhs)
            
            for rhs_index in range(rhs_length):

                 if (rhs, rhs_index) in self._equations_map:

                    original_RHS_value: float = rhs_vector[rhs_index].copy()

                    # Compute the partial by incrementing by delta then restore original value.
                    rhs_vector[rhs_index] = original_RHS_value + Constants().DELTA

                    # Iterate all equations that use the RHS variable to compute the partial derivatives.
                    for (lhs, lhs_index) in self._equations_map[(rhs, rhs_index)]:

                        # Run the relevant function to evaluate the model equation 
                        # at the adjusted RHS variable value.
                        func = getattr(self.equations, f"{lhs}_{lhs_index}")
                        func()

                        perturbed_LHS_value: float = self.get_vector_by_name(vector_name=lhs)[lhs_index]
                        original_LHS_value: float = self.get_original_lhs_vector_by_name(lhs_vector_name=lhs)[lhs_index]
                        partial_derivative: float = ((perturbed_LHS_value - original_LHS_value) / Constants().DELTA)

                        # Store the value of the derivative in the partial derivatives matrix at the
                        # appropriate row and column index.
                        self.get_partials(lhs_vector_name=lhs, rhs_vector_name=rhs)[lhs_index, rhs_index] = partial_derivative

                    rhs_vector[rhs_index] = original_RHS_value

            elapsed_time: float = time.time()- start_time
            if elapsed_time > 5:
                execution_time: str = "{:.3f}".format(elapsed_time)
                logging.info(f"Partial derivatives wrt variables in the {rhs} vector took {execution_time} seconds to calculate.")


        self._linear_model_is_available = True

    def __generate_nonlinear_equation_differences(self):
        """
        ### Overview
        
        Generate a report of the differences between observed values and 
        non-linear equation solutions used in model linearisation.
        """
        x1_diff: pd.DataFrame = pd.DataFrame(np.hstack((self._x1r,self._x1l, self._x1r - self._x1l)))
        x1_diff.index = self.model.sym_data.vector_variable_names(vector_name='x1l')
        x1_diff.columns = ['rhs', 'lhs', 'rhs_minus_lhs']
        j1_diff: pd.DataFrame = pd.DataFrame(np.hstack((self._j1r, self._j1l, self._j1r - self._j1l)))
        j1_diff.index = self.model.sym_data.vector_variable_names(vector_name='j1l')
        j1_diff.columns = ['rhs', 'lhs', 'rhs_minus_lhs']
        ze_diff: pd.DataFrame = pd.DataFrame(np.hstack((self._zer, self._zer, self._zer - self._zel)))
        ze_diff.index = self.model.sym_data.vector_variable_names(vector_name='zel')
        ze_diff.columns = ['rhs', 'lhs', 'rhs_minus_lhs']
        z1_diff: pd.DataFrame = pd.DataFrame(np.hstack((self._z1r, self._z1l, self._z1r - self._z1l)))
        z1_diff.index = self.model.sym_data.vector_variable_names(vector_name='z1l')
        z1_diff.columns = ['rhs', 'lhs', 'rhs_minus_lhs']
        exo_diff: pd.DataFrame = pd.DataFrame(index=self.model.sym_data.vector_variable_names(vector_name='exo'), columns=['rhs', 'lhs', 'rhs_minus_lhs'])
        exo_diff.loc[:,'rhs'] = self._exo
        exo_diff.loc[:, 'lhs'] = self._exo
        exo_diff.loc[:, 'rhs_minus_lhs'] = 0
        diffs = pd.concat([
            x1_diff,
            j1_diff,
            ze_diff,
            z1_diff,
            exo_diff])
        database_ordered_variable_list: pd.DataFrame = self.linearisation_database.variables.name
        self._nonlinear_equation_differences = pd.concat([database_ordered_variable_list, diffs], axis=1)
        self._nonlinear_equation_differences.drop('name', inplace=True, axis=1)
        self._nonlinear_equation_differences.insert(loc=0, column='vector', value=self.sym_data.combined_variable_summary.loc[:, 'vector'])
        self._nonlinear_equation_differences = self._nonlinear_equation_differences.loc[self._nonlinear_equation_differences.vector != 'exo', :]

    @property
    def nonlinear_equation_differences(self) -> pd.DataFrame:
        """
        Details about the differences between the LHS and RHS values for all
        endogenous variables as at the point of linearisation. This is only used for unit testing
        purposes.
        """
        self.__generate_nonlinear_equation_differences()
        return self._nonlinear_equation_differences

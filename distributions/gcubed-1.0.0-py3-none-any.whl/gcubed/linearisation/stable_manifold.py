# ------------------------------------------------------------------
# Purpose: Compute the stable manifold.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
"""
Contains the StableManifold class
"""
import logging
import sys
import numpy as np
import pandas as pd
from gcubed.base import Base
from gcubed.linearisation.state_space_form import StateSpaceForm
from gcubed.model import Model

class StableManifold(Base):
    """
    ### Overview

    The algebra embodied in this class follows the second page of
    https://www.msgpl.com.au/Manuals2021/GGGv20JManual/softwaremanual/algorithm.pdf
    
    For the details, see https://www.rba.gov.au/publications/rdp/1987/pdf/rdp8706.pdf

    This script produces rules for the evolution of model variables:

    Using the vector names defined in the SYM processor:

    The rule for the costate or jump variables has the form:
    
    $$J_t = H_1 X1_t + H_1 EXO_t + \\text{a linear function of future EXO variables}$$

    The rule for the ZE vector of special endogenous variables has the form:

    $$ZE_t = \\mu_1 X1_t + \\mu_4 EXO_t + \\text{a linear function of future EXO variables}$$

    The rule for the state variables is:

    $$X1_t = \\tau_1 X1_{t-1} + \\tau_2 J_{t-1} + \\tau_4 EXO_{t} + \\tau_7 EXO_{t-1}$$

    The rule for the endogenous variables, Z1, is just the equation obtained when forming the SSF:

    $$Z1_t = z1l/yxr_{ssf} X1_{t-1} + z1l/yjr_{ssf} J1_{t-1} + z1l/exz_{ssf} ZE_{t+1} + z1l/exo_{ssf} EXO_{t}$$

    These rules are embodied in the coefficient matrices in each of them.

    Iteration to convergence algorithm for the stable manifold:

    Convergence criteria:
    1. If there are no jump variables, just do a single iteration and stop.

    Report progress for each iteration:

    1. Check the average absolute error in the jump matrix, h1t
    2. Check the average absolute error in the jump matrix, h2t
    Cumulative errors are the average absolute values of the change in the elements 
    in the matrix, considering mean(abs(H1tL - H1t)) and mean(abs(H2tL - H2t)).

    Convergence has been reached if both of these average absolute errors are less than
    the tolerance specified in the model configuration.
    
    Iterations update the H1 and H2 coefficient matrices until they stabilise.

    Interim calculations in the iteration process produce the other coefficient matrices needed
    for the other rules describing the path of model variables X1 and ZE.
    """

    def __init__(self, state_space_form: StateSpaceForm) -> None:
        """

        ### Constructor

        The stable manifold is solved for using the coefficient matrices 
        in the state-space form of the model.
        
       ### Arguments

        state_space_form: The state-space form of the model being used.
        This provides access to all information about the model including 
        the coefficient matrices that define the state-space form itself.

        """

        assert state_space_form is not None
        self._state_space_form = state_space_form
        self.solve()
        self.__validate()

    def __validate(self):
        """
        TODO: Validate the setup to ensure we are ready to find the stable manifold.
        """
        logging.info("The stable manifold has been found for the model.")

    @property
    def ssf(self) -> StateSpaceForm:
        """
        The state space form of the model, based on algebraic manipulation
        of the linear approximation to the original model.
        """
        return self._state_space_form

    @property
    def model(self) -> Model:
        """
        The model for which the stable manifold is being sought.
        """
        return self.ssf.model

    def solve(self):
        """
        ### Overview

        Runs the iteration process, checking convergence criteria each time until convergence is reached
        or the maximum number of iterations has occurred.
        """
        self._iterations = 0
        while (not self.converged) and (self._iterations < self.model.configuration.stable_manifold_maximum_iterations):
            self.__iterate()

        if self.converged:

            # Compute state updating matrices:
            self._Anew = self.ssf.delta("x1l", "yxr") + \
                self.ssf.delta("x1l", "yjr") @ self._H1t + \
                self.ssf.delta("x1l", "exz") @ self.mu1
            self._Znew = self.ssf.delta("x1l", "exo") + \
                self.ssf.delta("x1l", "yjr") @ self.H2 + \
                self.ssf.delta("x1l", "exz") @ self.mu2

            # Check stability of solution.
            self.analyse_eigenvalues()

            return

        h1_average_absolute_change: float = np.average(np.abs(self._H1t_lead-self._H1t),axis=None)
        h2_average_absolute_change: float = np.average(np.abs(self._H2t_lead-self._H2t), axis=None)
        logging.warning(f"The average absolute change in the H1 elements is still {h1_average_absolute_change}")
        logging.warning(f"The average absolute change in the H2 elements is still {h2_average_absolute_change}")
        raise Exception(f"The search for a stable manifold reached the iteration limit {self.model.configuration.stable_manifold_maximum_iterations} without converging.")

    def __iterate(self):
        """

        ### Overview

        Recall from sym_data.py, the naming conventions for the LHS variable vectors:
        
        a. x1l (the vector of state variables) X=S=State
        b. j1l (the vector of costate or jump variables) J=C=Costate
        c. zel (the endogenous variables LOGY, PRCT, PRID) 
        d. z1l (the other endogenous variables)

        These 4 LHS vectors of variables are functions of:
        
        1. x1r is right hand side (RHS) state variables
        2. j1r is RHS costate or jump variables
        3. zer is RHS endogenous variables LOGY, PRCT, PRID
        4. exz is RHS the lead expected endogenous variables
        5. yxr is RHS state variables lagged by 1 period
        6. yjr is RHS costate variables lagged by 1 period
        7. exo is exogenous variables (by definition only appearing on RHS)
        8. z1r is RHS other endogenous variables.

        """

        self._iterations += 1

        np.set_printoptions(formatter={'float': lambda x: "{0:0.4f}".format(x)})
        np.set_printoptions(suppress=True, linewidth=400)
        np.set_printoptions(threshold=sys.maxsize)

        if self._iterations == 1:

            self._H1t = self.Gamma_jT @ (self.ssf.delta("j1l", "exz") @ self.psi_rs + self.ssf.delta("j1l", "yxr"))
            self._H2t = self.Gamma_jT @ (self.ssf.delta("j1l", "exz") @ self.psi_rx + self.ssf.delta("j1l", "exo"))
            self._M1t = self.psi_rs + self.psi_rj @ self._H1t
            self._M2t = self.psi_rx + self.psi_rj @ self._H2t

        else: 
            # See section 5.2 of the model solution documentation.
            self._H1t_lead = self._H1t
            self._H2t_lead = self._H2t
            self._M1t_lead = self._M1t
            self._M2t_lead = self._M2t

            # wvi in Ox
            self._Gamma_st = np.linalg.inv(np.identity(self.model.sym_data.vector_length("x1l")) - self.ssf.delta("x1l", "exz") @ self._M1t_lead)
            
            # th1t in Ox
            self._tau_sst = self.Gamma_st @ self.ssf.delta("x1l", "yxr") # s by s dimension

            # th2t in Ox
            self._tau_sjt = self.Gamma_st @ self.ssf.delta("x1l", "yjr") # s by j dimension

            # th4t in Ox
            self._tau_sxt = self.Gamma_st @ self.ssf.delta("x1l", "exo") # s by x dimension

            # th6t in Ox
            self._common_factor = self._H1t_lead - self.ssf.delta("j1l", "exz") @ self._M1t_lead # j by s dimension

            #fdeltinv in Ox
            if self.model.sym_data.no_jump_variables:
                self._Gamma_jt = 0
            else:
                self._Gamma_jt = np.linalg.inv(self.ssf.delta("j1l", "yjr") - self.common_factor @ self._tau_sjt) # j by j dimension

            self._H1t = self.Gamma_jt @ (self.common_factor @ self._tau_sst - self.ssf.delta("j1l", "yxr")) # j by s dimension
            self._H2t = self.Gamma_jt @ (self.common_factor @ self._tau_sxt - self.ssf.delta("j1l", "exo")) # j by x dimension

            # th1t = th1t + th2t * bt1t in Ox (s by s)
            th1t: np.ndarray = self._tau_sst + self._tau_sjt @ self._H1t

            # th4t = th4t + th2t * bt3t in Ox (s by x)
            th4t: np.ndarray = self._tau_sxt + self._tau_sjt @ self._H2t

            # mu1t = mu1tL * th1t in Ox (r by s) x (s by s) -> (r by s)
            self._mu1t = self._M1t_lead @ th1t

            # mu4t = mu1tL * th4t in Ox (r by s) x (s by x) -> (r by x)
            self._mu2t = self._M1t_lead @ th4t

            # Model solution equation 71.
            self._M1t = self.ssf.delta("zel", "yxr") + self.ssf.delta("zel", "exz") @ self._mu1t +  self.ssf.delta("zel", "yjr") @ self._H1t # r by s dimension

            # Model solution equation 72.
            self._M2t = self.ssf.delta("zel", "exo") +  self.ssf.delta("zel", "exz") @ self._mu2t +  self.ssf.delta("zel", "yjr") @ self._H2t # r by x dimension

    @property
    def Gamma_rT(self) -> np.ndarray:
        """
        A matrix that is used when generating projections.
        See the model solution documentation equation 31.

        Note that in the Ox implementation of G-Cubed, the diagonal 
        elements are slightly wrong, being left as 1.0 exactly when they should be 
        slightly perturbed by the impact of the SSF matrix. 
        Python does not have this problem.
        """
        if not hasattr(self,'_Gamma_rT'):
            self._Gamma_rT = np.linalg.inv(np.identity(self.model.sym_data.vector_length("zel")) - self.ssf.delta("zel", "exz"))
        return self._Gamma_rT

    @property
    def psi_rs(self) -> np.ndarray:
        """
        A matrix that is used when generating projections.
        See the model solution documentation equation 32.
        """
        return self.Gamma_rT @ self.ssf.delta("zel", "yxr") 

    @property
    def psi_rj(self) -> np.ndarray:
        """
        A matrix that is used when generating projections.
        See the model solution documentation equation 33.
        """
        return self.Gamma_rT @ self.ssf.delta("zel", "yjr")

    @property
    def psi_rx(self) -> np.ndarray:
        """
        A matrix that is used when generating projections.
        See the model solution documentation equation 34.
        """
        return self.Gamma_rT @ self.ssf.delta("zel", "exo")


    @property
    def Gamma_jT(self) -> np.ndarray:
        """
        A matrix that is used when generating projections.
        See equation 37.
        """
        if not hasattr(self,'_Gamma_jT'):
            self._Gamma_jT = np.linalg.inv(np.identity(self.model.sym_data.vector_length("j1l")) - self.ssf.delta("j1l", "yjr") - self.ssf.delta("j1l", "exz") @ self.psi_rj)
        return self._Gamma_jT

    @property
    def Gamma_st(self) -> np.ndarray:
        """
        A matrix that is used when generating projections.
        See the model solution documentation equation 52
        """
        return self._Gamma_st

    @property
    def Gamma_jt(self) -> np.ndarray:
        """
        A matrix that is used when generating projections.
        See the model solution documentation equation 62
        """
        return self._Gamma_jt

    @property
    def H1(self) -> np.ndarray:
        """
        The matrix relating J1 (costate variables) to X1 (state variables) in the equation
        used to project costate variables.
        See the model solution documentation equation 63.
        """
        if self._H1t is None:
            raise Exception("The model has not yet been solved for the stable manifold so H1 is not available.")
        # if not self.converged:
        #     logging.warning("The search for the stable manifold has not converged.")
        return self._H1t

    @property
    def H2(self) -> np.ndarray:
        """
        The matrix relating J1 (costate variables) to EXO (exogenous variables) in the equation
        used to project costate variables.
        See the model solution documentation equation 64.
        """
        if self._H2t is None:
            raise Exception("The model has not yet been solved for the stable manifold so H2 is not available.")
        # if not self.converged:
        #     logging.warning("The search for the stable manifold has not converged.")
        return self._H2t

    @property
    def M1(self) -> np.ndarray:
        """
        The matrix relating ZE (expected endogenous variables) to X1 (state variables) in the 
        equation that can be used to project state variables.
        See the model solution documentation equation 71.
        """
        if self._M1t is None:
            raise Exception("The model has not yet been solved for the stable manifold so M1 is not available.")
        return self._M1t

    @property
    def M2(self) -> np.ndarray:
        """
        The matrix relating ze (expected endogenous variables) to exo (exogenous variables) in the 
        equation that can be used to project state variables.
        See the model solution documentation equation 72.
        """
        if self._M2t is None:
            raise Exception("The model has not yet been solved for the stable manifold so M2 is not available.")
        return self._M2t

    @property
    def mu1(self) -> np.ndarray:
        """
        The matrix relating time t expectations of endogenous variables in t+1 to state in period t.
        See the model solution documentation equation 77.
        """
        if self._mu1t is None:
            raise Exception(
                "The model has not yet been solved for the stable manifold so mu1 is not available.")
        return self._mu1t

    @property
    def mu2(self) -> np.ndarray:
        """
        The matrix relating time t expectations of endogenous variables in t+1 to exogenous variables in period t.
        See the model solution documentation equation 78.
        """
        if self._mu2t is None:
            raise Exception(
                "The model has not yet been solved for the stable manifold so mu2 is not available.")
        return self._mu2t

    @property
    def M1_lead(self) -> np.ndarray:
        """
        The 1 period lead (t+1) for M1t
        """
        if self._M1t_lead is None:
            raise Exception("The model has not yet been solved for the stable manifold so M1_lead is not available.")
        return self._M1t_lead

    @property
    def Anew(self) -> np.ndarray:
        """
        The matrix relating endogenous state variables (x1) s_{t+1} to previous state variables (x1) s_{t}
        See the model solution documentation equation 75.
        """
        if not self.converged:
            logging.warning("The search for the stable manifold has not converged.")
        return self._Anew
    
    @property
    def Znew(self) -> np.ndarray:
        """
        The matrix relating state variables (x1) s_{t+1} to previous exogenous variables (exo) x_{t}
        See the model solution documentation equation 75.
        """
        if not self.converged:
            raise Exception("The search for the stable manifold has not converged.")
        return self._Znew

    @property
    def H1_as_dataframe(self) -> pd.DataFrame:
        """
        A dataframe representation of H1 that labels the rows and 
        columns of H1 with the relevant variables.
        """
        result: pd.DataFrame = pd.DataFrame(self.H1.copy())
        result.index = self.model.sym_data.vector_variable_names(vector_name='j1l')
        result.columns = self.model.sym_data.vector_variable_names(vector_name='x1l')
        return result

    @property
    def H2_as_dataframe(self) -> pd.DataFrame:
        """
        A dataframe representation of H2 that labels the rows and 
        columns of H2 with the relevant variables.
        """
        result:pd.DataFrame = pd.DataFrame(self.H2.copy())
        result.index = self.model.sym_data.vector_variable_names(vector_name='j1l')
        result.columns = self.model.sym_data.vector_variable_names(vector_name='exo')
        return result

    @property
    def M1_as_dataframe(self) -> pd.DataFrame:
        """
        A dataframe representation of M1 that labels the rows and 
        columns of M1 with the relevant variables.
        """
        result:pd.DataFrame = pd.DataFrame(self.M1.copy())
        result.index = self.model.sym_data.vector_variable_names(vector_name='zel')
        result.columns = self.model.sym_data.vector_variable_names(vector_name='x1l')
        return result

    @property
    def M2_as_dataframe(self) -> pd.DataFrame:
        """
        A dataframe representation of M2 that labels the rows and 
        columns of M2 with the relevant variables.
        """
        result:pd.DataFrame = pd.DataFrame(self.M2.copy())
        result.index = self.model.sym_data.vector_variable_names(vector_name='zel')
        result.columns = self.model.sym_data.vector_variable_names(vector_name='exo')
        return result

    @property
    def Anew_as_dataframe(self) -> pd.DataFrame:
        """
        The matrix relating endogenous state variables (x1) s_{t+1} to previous state variables (x1) s_{t}
        as a dataframe.

        This is typically used for debugging purposes.
        """
        result:pd.DataFrame = pd.DataFrame(self.Anew.copy())
        result.index = self.model.sym_data.vector_variable_names(vector_name='x1l')
        result.columns = self.model.sym_data.vector_variable_names(vector_name='x1l')
        return result
    @property
    def Anew_as_dataframe(self) -> pd.DataFrame:
        """
        """
        result: pd.DataFrame = pd.DataFrame(self.Anew)
        result.index = self.model.sym_data.vector_variable_names(vector_name='x1l')
        result.columns = self.model.sym_data.vector_variable_names(vector_name='x1l')
        return result

    @property
    def Znew_as_dataframe(self) -> pd.DataFrame:
        """
        A dataframe representation of Znew that labels the rows and 
        columns of Znew with the relevant variables.
        """
        result:pd.DataFrame = pd.DataFrame(self.Znew.copy())
        result.index = self.model.sym_data.vector_variable_names(vector_name='z1l')
        result.columns = self.model.sym_data.vector_variable_names(vector_name='exo')
        return result

    @property
    def tau_sst(self):
        """
        A matrix that is exposed as part of unit testing the Python implementation.
        """
        return self._tau_sst

    @property
    def tau_sjt(self):
        """
        A matrix that is exposed as part of unit testing the Python implementation.
        
        th2t in Ox
        """
        return self._tau_sjt

    @property
    def tau_sxt(self):
        """
        A matrix that is exposed as part of unit testing the Python implementation.
        """
        return self._tau_sxt

    @property
    def common_factor(self):
        """
        A matrix that is exposed as part of unit testing the Python implementation.
        th6t in Ox
        """
        return self._common_factor

    @property
    def eigenvalues(self) -> np.ndarray:
        """
        The eigenvalues of the Anew matrix, returned as a column vector of complex numbers.
        """
        return np.linalg.eigvals(self.Anew)

    def analyse_eigenvalues(self):
        """
        ### Overview

        Determine how many eigen values are on the unit circle (implying unit roots in 
        state variables) and how many are outside of the unit circle (impying instability
        in the model).

        """
        eigenvalue_moduli = np.abs(self.eigenvalues)
        self._roots_outside_unit_circle = sum(eigenvalue_moduli > 1.001)
        self._unit_roots = sum( ~(self.roots_outside_unit_circle) and eigenvalue_moduli > 0.999999999 )
        if self.solution_is_stable:
            logging.info(f"All roots are on or inside the unit circle, indicating stability of the solution.")
            # logging.debug(f"The eigenvalue moduli are:\n{np.sort(eigenvalue_moduli)}")
        else:
            logging.warning(f"The eigenvalue moduli are:\n{np.sort(eigenvalue_moduli)}")
            raise Exception(f"There are {self.roots_outside_unit_circle} roots outside the unit circle. All eigenvalues must be on or inside the unit circle for stability.")

    @property
    def unit_roots(self) -> int:
        """
        The number of unit roots in the model.
        """
        return self._unit_roots

    @property
    def roots_outside_unit_circle(self) -> int:
        """
        The number of roots outside the unit circle.
        """
        return self._roots_outside_unit_circle

    @property
    def solution_is_stable(self) -> bool:
        """
        True if the model is stable and False otherwise.
        """
        return (self.roots_outside_unit_circle == 0)

    @property
    def converged(self) -> bool:
        """
        True if the model has converged to a solution (stable or otherwise) and False if 
        the model has not converged.
        """
        if self._iterations is None:
            return False
        if self._iterations < 2:
            return False
        if self.H1_changed:
            return False
        if self.H2_changed:
            return False
        return True

    @property
    def H1_changed(self) -> bool:
        """
        True if there is an alteration in H1 in the last iteration and False otherwise.
        """
        average_deviation = np.average(np.abs(self._H1t_lead-self._H1t),axis=None)
        # logging.info(f"The average H1 change = {average_deviation}")
        return  average_deviation > self.model.configuration.stable_manifold_tolerance

    @property
    def H2_changed(self) -> bool:
        """
        True if there is an alteration in H2 in the last iteration and False otherwise.
        """
        average_deviation = np.average(np.abs(self._H2t_lead-self._H2t), axis=None)
        # logging.info(f"The average H2 change = {average_deviation}")
        return average_deviation > self.model.configuration.stable_manifold_tolerance

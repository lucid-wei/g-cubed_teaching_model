# ------------------------------------------------------------------
# Purpose: Find a point that solves the equations in the model.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
import logging
import sys
import importlib
import pandas as pd
import numpy as np
from scipy.optimize import least_squares
from scipy.sparse import lil_matrix, identity
from gcubed.data.gdp_scaled_database import GDPScaledDatabase
from gcubed.model import Model
from gcubed.base import Base
from gcubed.constants import Constants

class ModelSolver(Base):
    """

    ### Overview

    The solver finds a point (a value for each variable in the model)
    that simultaneously solves the nonlinear equations 
    in the model, taking as given the values for the vectors:
    - yxr
    - yjr
    - exz
    - exo

    If a solution can be found, it will be values for the
    following vectors:
    - x1r
    - j1r
    - zer
    - z1r

    The process will be:
    1. Set up database
    2. Populate all vectors using database values for the linearisation year.
    3. Rearrange the model equations so that we can solve for all vectors by evaluating all 
    of the model equations and then take the RHS of the equation

    TODO: Implement based on logic in TestLinearisationRootFindingModel2R164

    """


    def __init__(self, model: Model, linearisation_year: int ):

        logging.info(f"Seeking a model solution close to the data values in {linearisation_year}.")
        self._solution_found = False
        
        assert model is not None
        self._model: Model = model

        assert linearisation_year  is not None
        assert linearisation_year < model.configuration.last_projection_year
        self._linearisation_year = linearisation_year


        self.database = GDPScaledDatabase(database=self.model.database, base_year=self.model.configuration.base_year)
        self._parameters = self.model.parameters.parameter_values_vector

        # Set up the RHS vectors for the model using data for the linearisation year.
        self.__load_rhs_vectors(linearisation_year=self.model.configuration.linearisation_year)

        # Set up the LHS vectors as vectors of zeros.
        self.__configure_lhs_vectors()

        self.__load_equation_map()

        sys.path.append(self.model.configuration.sym_directory)
        equations_module = importlib.import_module(self.model.configuration.sym_output_filename_prefix)
        equations_class = getattr(equations_module, "Equations")
        self.equations = equations_class(x1l=self._x1l,
                                          j1l=self._j1l,
                                          zel=self._zel,
                                          z1l=self._z1l,
                                          x1r=self._x1r,
                                          j1r=self._j1r,
                                          z1r=self._z1r,
                                          zer=self._zer,
                                          yjr=self._yjr,
                                          yxr=self._yxr,
                                          exo=self._exo,
                                          exz=self._exz,
                                          par=self._parameters)

        # Calculate the original LHS values for all equations.
        self.__compute_lhs_vectors()

        # Store the original LHS vector result values to use in final reports for comparison purposes.
        for lhs_vector_name in self.model.sym_data.lhs_vector_names:
            setattr(self, f"_original_{lhs_vector_name}", getattr(self, f"_{lhs_vector_name}").copy())

        self._iteration_count = 0

        self._solution_found = self.__find_solution()

    @property
    def model(self) -> Model:
        """
        Model: The model that needs a solution to linearise around.
        """
        return self._model

    @property
    def linearisation_year(self) -> int:
        """
        int: The return value, the 4 digit linearisation year.
        """
        return self._linearisation_year

    @property
    def solution_found(self) -> bool:
        """
        bool: True if the model solution has been found and False otherwise.
        """
        return self._solution_found


    def __load_equation_map(self):
        """
        Uses the eqnmap output from the sym processor to create a map from each
        RHS variable (vector + index combination) to the equations that include
        that variable on the RHS.

        This map ensures we only have to evaluate the relevant equations when computing
        the partial derivatives of the model equations when considering each RHS variable.

        The equations map is a map from RHS variable identifiers to LHS equation identifiers.
        Each RHS and LHS identifier is a tuple: a string, identifying the vector
        name (eg: x1l or zer) and an integer, identifying the string index.
        """

        # The RHS vectors relevant to this problem.
        rhs_vectors_of_interest: tuple[str] = ['x1r', 'j1r', 'zer', 'z1r']

        # Initialise the equations map
        self.equations_map: dict[tuple[str, int], list[tuple[str, int]]] = dict()

        # Load the raw data and remove entries for parameters.
        rows: pd.DataFrame = pd.read_csv(self.model.configuration.eqnmap_file, header=None)
        rows.columns = ['name', 'number']
        # Remove 'par' RHS entries - they are not needed.
        rows = rows.loc[~(rows.name == 'par'), :]

        lhs: tuple[str, int] = None
        rhs: tuple[str, int] = None

        # Set of variables on LHS
        lhs_set: set[tuple[str, int]] = set()

        # Set of LHS variables that are found on the RHS
        rhs_set: set[tuple[str, int]] = set()

        for row in rows.itertuples(index=False):

            if row[0].endswith('l'):
                lhs = (row[0], int(row[1]))
                lhs_set.add(lhs)
                rhs = None
                continue

            if (row[0]) in rhs_vectors_of_interest:
                rhs = (row[0], int(row[1]))
                if rhs not in rhs_set:
                    rhs_set.add((row[0][:-1] + 'l', int(row[1])))

            if rhs is None:
                continue

            if rhs in self.equations_map:
                self.equations_map[rhs].append(lhs)
            else:
                self.equations_map[rhs] = [lhs]

        # Get the set of LHS variables that are also RHS variables - these are the equations to focus on.
        self.lhs_variables_to_ignore: set[tuple[str, int]] = lhs_set.difference(rhs_set)
        self.lhs_variables_to_adjust: set[tuple[str, int]] = lhs_set.intersection(rhs_set)
        logging.info(f"LHS={len(lhs_set)} LHS variables to ignore={len(self.lhs_variables_to_ignore)}, LHS variables to adjust={len(self.lhs_variables_to_adjust)}")

        # The list of LHS variables that may need to be adjusted to get a model solution to linearise around
        self.lhs_variables = list(sorted(self.lhs_variables_to_adjust, key=lambda x: (x[0], x[1])))

        # Make variable-order lookups order 1 using a dictionary.
        self.lhs_variables_indices: dict[tuple[str,int], int] = dict()
        i = 0
        for lhs_variable in self.lhs_variables:
            self.lhs_variables_indices[lhs_variable] = i
            i += 1

        # Get a matching list of variable names and vector names and indices.
        for lhs_vector_name in self.model.sym_data.lhs_vector_names:
            setattr(self,f"_{lhs_vector_name}_names", self.model.sym_data.vector_variable_names(vector_name=lhs_vector_name))
        self.lhs_variable_names: list[str] = []
        for lhs_variable in self.lhs_variables:
            self.lhs_variable_names.append(getattr(self,f"_{lhs_variable[0]}_names")[lhs_variable[1]])

        df = pd.DataFrame(self.lhs_variables,columns=['vector','index'])
        df['name'] = self.lhs_variable_names

        self.lower_bounds = np.zeros(len(self.lhs_variable_names)) - np.Inf
        self.upper_bounds = np.zeros(len(self.lhs_variable_names)) + np.Inf

        self.lower_bounds[2] = 0.03
        self.lower_bounds[3] = 0.03

        # logging.debug(df)

    def index_of(self, variable:tuple[str,int]) -> int:
        """
        Args:
            variable (tuple[str,int]): The vector and index pair that
            identifies the variable.

       ### Returns
            int: The return value, equal to the index of the variable
            in the vector of variables that we are adjusting to find 
            a model solution.
        """
        return self.lhs_variables_indices[variable]

    def __configure_lhs_vectors(self):
        """
        Create the LHS vectors that are used by the model equations
        as properties of this model solver.

        Initialise the newly created LHS vectors with zeros.

        These vector properties will be populated whenever the model 
        equations are run.
        """
        for vector_name in self.model.sym_data.lhs_vector_names:
            setattr(self, "_{}".format(vector_name), np.zeros(
                shape=(self.model.sym_data.vector_length(vector_name=vector_name), 1), dtype=float))

    def __load_rhs_vectors(self, linearisation_year: int):
        """
        Create and set values for the RHS vectors that are used by the 
        model equations.

        Do not create vectors if they have no variables (are zero length).

        We initialise the RHS vectors with database values from the 
        linearisation base year or the lead/lag from that year.

        All 8 RHS vectors are populated. As LHS values are computed from the 
        model equations, the RHS versions of those LHS vectors will be updated.
        That process will underpin the numeric search for a model solution near
        the data values from the linearisation year.

        Args:
        linearisation_year (int): The (YYYY format) year for which the 
        model is being linearised. This determines the data that is retrieved
        from the database to populate the RHS vectors.
        """
        for vector_name in self.model.sym_data.rhs_vector_names:
            rhs_vector:pd.DataFrame = self.database.rhs_vector_value(vector_name=vector_name, year=linearisation_year, use_neutral_real_interest_rate=True)
            if rhs_vector is not None:
                setattr(self, f"_{vector_name}", rhs_vector)
                # Save the original value of the vector for comparison purposes.
                setattr(self, f"_original_{vector_name}", rhs_vector.copy())

    def __compute_lhs_vectors(self):
        """
        Evaluates each of the equations in the model, updating the
        associated LHS value in the LHS vector properties of the model
        solver instance.
        """
        if self.equations is None:
            raise Exception("The model equations have not been loaded by the model solver.")
        
        for lhs_vector_name in self.model.sym_data.lhs_vector_names:
            lhs_vector = getattr(self, f"_{lhs_vector_name}")
            for lhs_index in range(len(lhs_vector)):
                function_name = f"{lhs_vector_name}_{lhs_index}"
                if hasattr(self.equations, function_name):
                    func = getattr(self.equations, function_name)
                    func()



    def __find_solution(self) -> bool:
        """
        The solver looks for roots of the objective function using the least squares
        method documented as part of the scientific python package.
        https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.least_squares.html
        
        It finds a solution to the nonlinear model equations using an explicit 
        Jacobian calculation. The sparsity of the Jacobian is taken into account.

        This function has two sub-functions, the objective function that defines
        the objective used by the least squares solver ad the jacobian function that
        efficiently computes the necessary Jacobian for each iteration.

        The process is to call the scientific python least_squares function passing in
        these two functions as well as starting values for the variables being adjusted 
        to find a full model solution.

        The set of variables being adjusted are determined during the loading of the model
        equation map. Only those variables that occur on the LHS of one equation and the RHS 
        of any other equation in the model need to be adjusted to find a model solution.

        Once a solution is obtained, those values for the variables being adjusted are 
        mapped back into the complete RHS vectors of the model. The LHS vectors of the
        model are already populated with the full model solution by the solver.

        These LHS and RHS vector values are then exposed as model solver properties and they
        can be accessed as vector values around which the model can be linearised.

       ### Returns

        bool: True if the model could be solved and False otherwise.

        """

        def objective_function(x: np.ndarray) -> np.ndarray:
            """
            The objective function passed as an input to the least squares
            algorithm.

            Steps:
            1. 
            # Use the input x vector to set those elements of the RHS vectors 
            that are being adjusted to find a model solution. The variables in the 
            x vector are in the same order as the lhs_variables list.

            2. 
            Evaluate just those equations in the model that are associated with
            the variables that are being adjusted to find a model solution.

            3.
            # From the LHS vector properties of the model solver (that have been updated
            by evaluation of the model equations), get the values of each of the variables 
            that are being adjusted to find a model solution and place them in a vector
            that reflects the model RHS. Call this vector the result.

            4. Compute the return vector for the objective function:
            x - result.
            When this difference between x and the result of the equation evaluations
            is equal to zero for all equations, then a model solution has been found.

            Args:
            x (np.ndarray): The vector of values being used to evaluate the objective function.
            These are the LHS vector values that need to be adjusted to find a model solution.

            This objective function implements the model equations to be solved so that we get 
            (model LHS - model RHS) = 0

           ### Returns
            np.ndarray: The return value, the vector (model LHS - model RHS), evaluated at the
            input x, for the vector of equations associated with those variables in the model 
            that the solver is adjusting.
            """

            # Step 1.
            i = 0
            for lhs_variable in self.lhs_variables:
                match lhs_variable[0]:
                    case 'x1l':
                        self._x1r[lhs_variable[1]] = x[i]
                    case 'j1l':
                        self._j1r[lhs_variable[1]] = x[i]
                    case 'zel':
                        self._zer[lhs_variable[1]] = x[i]
                    case 'z1l':
                        self._z1r[lhs_variable[1]] = x[i]
                i += 1

            # Step 2.
            for lhs_variable in self.lhs_variables:
                function_name = f"{lhs_variable[0]}_{lhs_variable[1]}"
                if hasattr(self.equations, function_name):
                    func = getattr(self.equations, function_name)
                    func()

            # Step 3.
            result: np.ndarray = np.zeros((len(self.lhs_variables),))
            i = 0
            for lhs_variable in self.lhs_variables:
                match lhs_variable[0]:
                    case 'x1l':
                        result[i] = self._x1l[lhs_variable[1]]
                    case 'j1l':
                        result[i] = self._j1l[lhs_variable[1]]
                    case 'zel':
                        result[i] = self._zel[lhs_variable[1]]
                    case 'z1l':
                        result[i] = self._z1l[lhs_variable[1]]
                i += 1

            # Step 4.
            result = x - result

            logging.info(f"Maximum absolute discrepancy = {np.abs(result).max()}")

            return result

        def jacobian(x) -> lil_matrix:
            """
            The function that calculates the square Jacobian at the 
            given set of values. the Jacobian is square, having a row for
            each equation associated with a LHS variable that is being solved
            for and a column for each of those variables also.
            
            This function is passed as an input to the least squares algorithm.

            Steps:

            0.
            Initialise the jacobian matrix, setting all values to zero initially.

            1. 
            # Use the input x vector to set those elements of the RHS vectors 
            that are being adjusted to find a model solution. The variables in the 
            x vector are in the same order as the lhs_variables list.

            2. 
            Compute the numerical derivative element in the Jacobian for
            each of the adjusting variables that occurs on the RHS of
            an equation that is being used by the solver to find a model solution.

            Args:
            x (np.ndarray): The vector of values being used to evaluate the objective function.
            These are the LHS vector values that need to be adjusted to find a model solution.

            This objective function implements the model equations to be solved so that we get 
            (model LHS - model RHS) = 0

           ### Returns
            The return value, the sparse matrix representing the Jacobian.
            """

            # Step 0.
            result: lil_matrix = identity(len(x), format='lil')

            # Step 1.
            i = 0
            for lhs_variable in self.lhs_variables:
                match lhs_variable[0]:
                    case 'x1l':
                        self._x1r[lhs_variable[1]] = x[i]
                    case 'j1l':
                        self._j1r[lhs_variable[1]] = x[i]
                    case 'zel':
                        self._zer[lhs_variable[1]] = x[i]
                    case 'z1l':
                        self._z1r[lhs_variable[1]] = x[i]
                i += 1

            # Step 2.
            for rhs_variable in self.lhs_variables:
                jacobian_col_index: int = self.index_of(rhs_variable)
                rhs_vector_name: str = rhs_variable[0][:-1] + 'r'
                rhs_vector_index: int = rhs_variable[1]
                original_value: float = getattr(self, f"_{rhs_vector_name}")[rhs_vector_index]
                # Get each equation that the RHS variable contributes to and approximate the partial derivative.
                for lhs_variable in self.equations_map[(rhs_vector_name, rhs_vector_index)]:
                    if lhs_variable not in self.lhs_variables:
                        continue
                    jacobian_row_index: int = self.index_of(lhs_variable)
                    lhs_vector_name: str = lhs_variable[0]
                    lhs_vector_index: int = lhs_variable[1]

                    # Compute reference value
                    func = getattr(self.equations, f"{lhs_vector_name}_{lhs_vector_index}")
                    func()
                    reference_value: float = getattr(self, f"_{lhs_vector_name}")[lhs_vector_index]

                    # Compute perturbed value
                    getattr(self, f"_{rhs_vector_name}")[rhs_vector_index] = original_value + Constants().DELTA
                    func()
                    perturbed_value: float = getattr(self, f"_{lhs_vector_name}")[lhs_vector_index]

                    # Reset the RHS variable value
                    getattr(self, f"_{rhs_vector_name}")[rhs_vector_index] = original_value

                    # Approximate the partial derivative
                    partial_derivative: float = ((perturbed_value - reference_value) / Constants().DELTA)

                    # logging.debug(f"Partials derivative of {lhs_variable}  wrt {(rhs_vector_name, rhs_vector_index)} = {partial_derivative}")

                    # Store the partial derivative
                    result[jacobian_row_index, jacobian_col_index] -= partial_derivative

            self._iteration_count += 1
            logging.info(f"computed the jacobian for iteration {self._iteration_count}")
            return result

        start_x: np.ndarray = np.zeros((len(self.lhs_variables),))
        i = 0
        for lhs_variable in self.lhs_variables:
            match lhs_variable[0]:
                case 'x1l':
                    start_x[i] =self._x1r[lhs_variable[1]]
                case 'j1l':
                    start_x[i] =self._j1r[lhs_variable[1]]
                case 'zel':
                    start_x[i] =self._zer[lhs_variable[1]]
                case 'z1l':
                    start_x[i] =self._z1r[lhs_variable[1]]
            i += 1

        logging.info("Starting the least-squares solver using an explicit Jacobian")
        solver_results = least_squares(fun=objective_function, x0=start_x, jac=jacobian)
        
        logging.info(f"Maximum change in linearisation value for variables: {np.abs(solver_results.x - start_x).max()}")

        # Set the RHS values of the adjusted LHS variables.
        i = 0
        for lhs_variable in self.lhs_variables:
            match lhs_variable[0]:
                case 'x1l':
                    self._x1r[lhs_variable[1]] = solver_results.x[i]
                case 'j1l':
                    self._j1r[lhs_variable[1]] = solver_results.x[i]
                case 'zel':
                    self._zer[lhs_variable[1]] = solver_results.x[i]
                case 'z1l':
                    self._z1r[lhs_variable[1]] = solver_results.x[i]
            i += 1

        # Evaluate all of the equations to get the model - solving set of variable values to get LHS vectors that are a root of the equation system.
        self.__compute_lhs_vectors()
        
        # Copy LHS results to use as RHS inputs.
        for lhs_vector_name in self.model.sym_data.lhs_vector_names:
            rhs_vector_name = lhs_vector_name[:-1]+'r'
            setattr(self, f"_{rhs_vector_name}", getattr(self, f"_{lhs_vector_name}").copy())

        # Evaluate all of the equations to get the model - solving set of variable values to get LHS vectors that are a root of the equation system.
        self.__compute_lhs_vectors()

        # Check that the solver has worked.
        result: bool = True
        for lhs_vector_name in self.model.sym_data.lhs_vector_names:
            rhs_vector_name: str = lhs_vector_name[:-1]+ 'r'
            lhs_vector: np.ndarray = getattr(self, f"_{lhs_vector_name}")
            rhs_vector: np.ndarray = getattr(self, f"_{rhs_vector_name}")
            if not np.allclose(lhs_vector, rhs_vector, atol=0.000001):
                logging.error(f"The model solver failed to find a solution for {lhs_vector_name}")
                result = False
            # data: pd.DataFrame = pd.DataFrame(np.hstack(( getattr(self, f"_original_{lhs_vector_name}"),  getattr(self, f"_original_{rhs_vector_name}"), getattr(self, f"_solution_{lhs_vector_name}"), getattr(self, f"_{lhs_vector_name}") )))
            # data.index = self.model.sym_data.vector_variable_names(vector_name=rhs_vector_name)
            # data.columns = ['LHS original', 'RHS original', 'RHS/LHS adjusted', 'RHS/LHS iteration test']
            # data.to_csv(f"{self.model.configuration.benchmarking_reports_directory}{rhs_vector_name} adjusted linearisation values.csv")

        # Model solved successfully.
        return result

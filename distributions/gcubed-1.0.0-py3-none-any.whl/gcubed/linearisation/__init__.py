"""
Model linearisation package.
"""
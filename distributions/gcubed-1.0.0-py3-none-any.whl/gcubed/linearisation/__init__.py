"""
Model linearisation package.
"""
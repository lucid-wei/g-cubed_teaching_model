"""
The gcubed package provides a full implementation of the 
G-Cubed model.

An introduction to G-Cubed usage is available [online](https://lucid-wei.github.io/g-cubed_teaching_model/docs/).

Support for the C-Cubed is available from 
[McKibbin Software Group](https://sensiblepolicy.com/).

©1993-2023 McKibbin Software Group Pty Ltd. All rights reserved.
"""
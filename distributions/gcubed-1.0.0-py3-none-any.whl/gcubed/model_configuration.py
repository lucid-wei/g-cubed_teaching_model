# ------------------------------------------------------------------
# Purpose: Definition of the model details class.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
"""
Contains the ModelConfiguration class
"""
import logging
import pandas as pd
import numpy as np
import regex as re
import os
import os.path
import sys
import importlib
from gcubed.base import Base

# Ensure pdoc generated API documentation includes the following methods.
__pdoc__ = {}
__pdoc__['ModelConfiguration._load_configuration_details'] = True

class ModelConfiguration(Base):
    """
    ### Overview

    Provides access to model configuration details that have been
    read in from the model configuration CSV file.
    """

    def __init__(self, configuration_file: str) -> None:
        """

        ### Constructor

        Initialises the model details from a modified version of the CSV files
        used by G-cubed. The information in the file is a subset of the information
        in the modeldetails.csv file and a subset of the information that is stored
        in the baseinfo.csv file.

        ### Arguments
            configuration_file: the relative path, from Python's
            current working directory, to the model configuration file.

        """

        if not configuration_file:
            raise Exception("A configuration file is required to create a model.")

        if not os.path.isfile(configuration_file):
            raise Exception(f"Configuration file {configuration_file} does not exist.")

        # Get the directory that contains the model configuration and other related files.
        self._model_directory = os.path.dirname(os.path.realpath(configuration_file))

        data: pd.DataFrame = pd.read_csv(configuration_file, header=None)
        self._load_configuration_details(configuration_details = data)
        self.__validate()

        logging.info(f"Preparing to use model {self.version} {self.build}.")

        if __class__.DOING_DETAILED_DEBUG:
            logging.info("Verbose debugging information will be logged.")
            np.set_printoptions(suppress=False, formatter={'float': lambda x: "{0:0.12f}".format(x)})
            pd.set_option('display.max_rows', None)
            pd.set_option('display.max_columns', None)
            pd.set_option('display.width', 2000)

    @property
    def model_directory(self):
        """
        The root directory of the model, where the configuration CSV file is located.
        """
        return f"{self._model_directory}/"
    
    @property
    def data_directory(self):
        """
        The data directory of the model, where the model's data files are stored.
        """
        return f"{self.model_directory}data/"

    @property
    def sym_directory(self):
        """
        The sym directory of the model, where the model's sym files are stored
        and where the Python script and other SYM processor outputs are stored
        after the SYM processor has been run.
        """
        return f"{self.model_directory}sym/"

    @property
    def ox_directory(self):
        """
        This directory is only used to benchmark Python
        implementation results against Ox implementation outputs.
        """
        return f"{self.model_directory}ox/"

    @property
    def benchmarking_reports_directory(self):
        """
        This directory is where all model benchmarking reports 
        are stored.
        """
        return f"{self.model_directory}benchmarking/"

    @property
    def simulations_directory(self) -> str:
        """
        This directory is where all simulation experiment definitions
        are stored. Each experiment has its own root directory that
        is a subfolder of the simulations directory.
        """        
        return f"{self.model_directory}simulations/"

    @property
    def debugging(self) -> bool:
        """
        True if logs are to be verbose (for debugging purposes) and False otherwise.

        The configuration file value
        should be set to 1 if logs are to be verbose and to 0 otherwise.

        The name for this property in the configuration file is `Debugging`. 
        """
        return bool(self.__class__.DOING_DETAILED_DEBUG)
    
    @property
    def version(self):
        """
        The unique string identifying the version of the model.
        This influences the way that the model parameters are calibrated.
        
        This configuration property must be specified.

        Conventionally the model version is a number plus single letter string, 
        where number represents the number of sectors, and the letter relates to 
        specific regions in the model. For example:
        
        2R is the 2 region/2 sector model
        
        20R is the 2 region/20 sector model
        
        20C is the 10 region/20 sector model used for carbon emissions modelling.

        The name for this property in the configuration file is `Version`.
        """
        if not hasattr(self, "_version"):
            raise Exception("You must specify the model version in the model configuration.")    
        return self._version

    @property
    def build(self) -> str:
        """
        The string identifying the build of the model.
        This influences the way that the model parameters are calibrated.
        
        This configuration property must be specified.

        The model build must start with an integer number but it can also
        include a suffix that consists of digits and letters (e.g. 170logv3).

        The name for this property in the configuration file is `Build`.
        """
        if not hasattr(self, "_build"):
            raise Exception("You must specify the model build in the model configuration.")    
        return self._build
    
    @property
    def build_number(self) -> int:
        """
        The integer indicating which build of the model is being used.
        A given model version can have many different builds.

        This configuration property must be implicit in the configuration "Build" property.
        """
        if not hasattr(self, "_build_number"):
            raise Exception("The model build in the model specification must start with a positive integer.")
        return self._build_number

    @property
    def sym_input_file(self):
        """
        The absolute path and name of the file to process with the sym processor
        to produce the sym details for the model and the Python implementation of the
        model equations.

        This configuration property must be specified.

        The name for this property in the configuration file is "SymInputFile".
        """
        return f"{self.sym_directory}{self._sym_input_file}"

    @property
    def sym_output_filename_prefix(self):
        """
        The equations Python module that is imported by the Lineariser.
        """
        return f"model_{self.version}_{self.build}"

    @property
    def fully_qualified_equations_module_name(self):
        """
        The fully qualified module name required to import the 
        SYM generated Python equations module.
        """
        return f"model.{self.version}.{self.build}.sym.{self.sym_output_filename_prefix}"

    @property
    def equations_python_module_file(self):
        """
        The name of the file that is the Python equations module for
        this model.
        """
        return f"{self.sym_directory}{self.sym_output_filename_prefix}.py"

    @property
    def sym_output_file_path_and_prefix(self):
        """
        The prefix used for all files output by the SYM processor.
        """
        return f"{self.sym_directory}{self.sym_output_filename_prefix}"

    @property
    def varmap_file(self):
        """
        The absolute path to the SYM processor generated varmap file.
        """
        return f"{self.sym_output_file_path_and_prefix}_varmap.csv"

    @property
    def eqnmap_file(self):
        """
        The absolute path to the SYM processor generated eqnmap file.

        The file containing a listing of left and right hand side variables
        in the model equations. the LHS variable comes first, as a name of
        the vector (column 1), and the index in that vector (column 2). Then each
        RHS variable appears, again as the vector name in column 2 and the index
        in that vector in column 2.

        This information is used to populate a dictionary with keys being the vector
        and index tuple for each RHS variable and the value being a list of of
        vector name, vector index tuples, one for each equation that the RHS variable 
        occurs in. That dictionary then drives the equation evaluations used in model
        linearisation.
        """
        return f"{self.sym_output_file_path_and_prefix}_eqnmap.csv"

    @property
    def variables_info_file(self):
        """
        The absolute path to the SYM processor generated varinfo file.
        """
        return f"{self.sym_output_file_path_and_prefix}_varinfo.csv"

    @property
    def opt_map_file(self):
        """
        The absolute path to the SYM processor generated optmap file.

        This is not used by the Python implementation.
        """
        return f"{self.sym_output_file_path_and_prefix}_optmap.csv"

    @property
    def model_summary_file(self):
        """
        The absolute path to the SYM processor generated lis file.

        This is not used by the Python implementation.
        """
        return f"{self.sym_output_file_path_and_prefix}.lis"

    @property
    def database_file(self):
        """
        The absolute path to the model's database CSV file.
        """
        return f"{self.data_directory}{self._database_file}"

    @property
    def io_table_file(self):
        """
        The absolute path to the model's input-output tables CSV file.

        An example value is `IOTABLESvR2011.csv`.

        The name for this property in the configuration file 
        is `IOTables`.
        """
        return f"{self.data_directory}{self._io_table_file}"

    @property
    def parameters_file(self):
        """
        The absolute path to the CSV file containing the values
        of the parameters that are set by the user rather than
        by calibration using database and IO table information.

        The name for this property in the configuration file 
        is `UsersParameters`.
        """
        return f"{self.data_directory}{self._parameters_file}"

    @property
    def productivity_file(self):
        """
        The absolute path to the CSV file containing the information
        needed to do region/sector productivity growth projections.

        The name for this property in the configuration file 
        is `Productivity`.
        """
        return f"{self.data_directory}{self._productivity_file}"

    @property
    def population_file(self):
        """
        The absolute path to the CSV file containing the information
        needed to do region population growth projections.

        The name for this property in the configuration file 
        is `Population`.
        """
        return f"{self.data_directory}{self._population_file}"

    @property
    def aeei_file(self):
        """
        The absolute path to the CSV file containing the information
        needed to do projections of region/sector energy efficiency improvements.

        The name for this property in the configuration file 
        is `AutonomousEnergyEfficiencyImprovement`.
        """
        return f"{self.data_directory}{self._aeei_file}"

    @property
    def linearisation_year(self):
        """
        The year to use when selecting the database data for model linearisation 
        purposes.

        e.g. `2011`.

        The name for this property in the configuration file is
        `LinearisationYear`. 
        """
        return self._linearisation_year

    @property
    def calibration_year(self):
        """
        The year to use when selecting the database data for model parameter calibration 
        purposes.

        e.g. `2011`.

        The name for this property in the configuration file is
        `CalibrationYear`. 
        """
        return self._calibration_year

    @property
    def calibration_of_carbon_coefficients_year(self):
        """
        The year to use when selecting the database data 
        for model parameter calibration purposes for the 
        carbon emissions related parameters.

        e.g. `2018`.

        The name for this property in the configuration file is
        `CalibrationOfCarbonCoefficientsYear`. 
        
        """
        return self._calibration_of_carbon_coefficients_year

    @property
    def base_year(self):
        """
        The year in which all indices are based at 1 (so their log values are 0).
        Typically, this is chosen to be the first projection year, noting that
        the first year of projections are matched up to observed data in that first
        year.

        If the database file has indexes with a base year of 2018, then the configuration
        file would set this property value to `2018`. Note that this property needs to describe
        the actual database file. It should not be a specification of the base year that you
        want to use. Other properties manage how the base year is altered after the data is
        loaded.

        e.g. 2018 if the provided database file has its base year in 2018.
        
        The name for this property in the configuration file 
        is `BaseYear`.
        """
        return self._base_year

    @property
    def original_first_projection_year(self):
        """
        The original first projection year. This is tracked 
        because, for projections that iterate forward through the projection years, 
        the first projection year will be updated with each iteration.
        
        This property is set equal to the value of the
        `FirstProjectionYear` property in the configuration file. 
        
        It must not be specified
        independently of the `FirstProjectionYear`.
        .
        """
        return self._original_first_projection_year

    @property
    def first_projection_year(self):
        """
        The first year that projections are to be generated for.
        Note that for baseline projections, the projections start
        in a year where the model's database has data, so the projections
        can be lined up with the observed data in the database.

        The name for this property in the configuration file is
        `FirstProjectionYear`. 
        """
        return self._first_projection_year
    
    @first_projection_year.setter
    def first_projection_year(self, value: int):
        """
        Updates the configuration to have a new first projection year, 
        updating the linearisation year also but not changing the 
        original first projection year.

        The first projection year must only ever be incremented.
        """
        assert value is not None
        assert isinstance(value, int)
        assert value > self.first_projection_year
        self._first_projection_year = value
        self._linearisation_year = value

    @property
    def last_projection_year(self):
        """
        The last year for which data will be projected.

        The name for this property in the configuration file is
        `LastProjectionYear`. 
        """
        return self._last_projection_year

    @property
    def projection_years(self) -> list[int]:
        """
        The list of integer years from the first projection
        year to the last projection year.
        """
        return range(self.first_projection_year, self.last_projection_year+1)

    @property
    def projection_years_column_labels(self) -> list[str]:
        """
        A list of string representations of the years from the
        first projection year to the last projection year.
        """
        return [str(x) for x in self.projection_years]

    @property
    def projection_years_count(self) -> int:
        """
        The number of projection years, from the first to the last.
        """
        return (self.last_projection_year - self.first_projection_year + 1)

    @property
    def stable_manifold_tolerance(self):
        """
        The maximum size of the change in the stable manifold estimate
        allowed during the search for the stable manifold.

        This configuration value is used to ensure that the search for a stable
        manifold terminates within a reasonable period of time. Consider
        making this value larger if the search is not converging.

        If not specified in the configuration file, then this model configuration
        property defaults to 0.00001.

        The name for this property in the configuration file 
        is `StableManifoldTolerance`.
        """
        if not hasattr(self, "_stable_manifold_tolerance"):
            self.self._stable_manifold_tolerance = 0.00001
        return self._stable_manifold_tolerance

    @property
    def stable_manifold_maximum_iterations(self):
        """
        The maximum number of iterations allowed when searching
        for the stable manifold for the model. If this number is reached
        without convergence of the stable manifold, then the model cannot 
        be used for projection purposes.

        This configuration value is used to ensure that the search for a stable
        manifold terminates within a reasonable period of time.

        If not specified in the configuration file, then this model configuration
        property defaults to 1000.

        The name for this property in the configuration file 
        is `StableManifoldMaximumIterations`.
        """
        if not hasattr(self, "_stable_manifold_maximum_iterations"):
            self.self._stable_manifold_maximum_iterations = 1000
        return self._stable_manifold_maximum_iterations

    @property
    def neutral_real_interest_rate(self):
        """
        The global neutral real interest rate as a decimal, so a value of 3.6% would
        be specified inn the model configuration as 0.036.

        The name for this property in the configuration file 
        is `NeutralRealInterestRate`.
        """
        if not hasattr(self, "_neutral_real_interest_rate"):
            raise Exception("You must include a global neutral real interest rate.")      
        return self._neutral_real_interest_rate
    
    @property
    def linearise_around_strict_model_solution(self) -> bool:
        """
        True if the model linearisation is done around a strict model
        solution and False if the model linearisation is to instead be done
        around actual data values sourced from the model database or from a 
        previous model projection. Set this to False for standard linearisation
        as has been done for G-Cubed for decades. Set this to True if the
        actual data values are to be adjusted to find similar values that exactly
        solve all of the equations in the model before then linearising around
        those similar values.

        This property defaults to False unless overridden in the model configuration.

        This property can be modified after the model has been loaded if a different
        behaviour is required.

        The name for this property in the configuration file 
        is `LineariseAroundStrictModelSolution`.
        """
        if not hasattr(self, "_linearise_around_strict_model_solution"):
            self._linearise_around_strict_model_solution = False
        return self._linearise_around_strict_model_solution

    @linearise_around_strict_model_solution.setter
    def linearise_around_strict_model_solution(self, value):
        """
        ### Overview
        
        Set the value to True if the model linearisation is done around a strict model
        solution and False if the model linearisation is to instead be done
        around actual data values sourced from the model database or from a 
        previous model projection.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._linearise_around_strict_model_solution = value

    def _load_configuration_details(self, configuration_details: pd.DataFrame):
        """

        ### Overview

        Iterates over the configuration details read in from the CSV configuration 
        file, populating the properties of this ModelConfiguration.

        ### Arguments

        configuration_details (pd.DataFrame): The panda dataframe populated by loading
        the CSV model configuration file.

        The CSV file should have the configuration property name in the first column.

        The CSV file should have the configuration property value in the second column.

        All other columns are ignored and so they can be used for documentation purposes.
        """

        for row in configuration_details.itertuples(index=False):
            match row[0]:
                case "Version":
                    self._version: str = str(row[1])
                case "Build":
                    self._build: str = str(row[1])
                    match = re.search(r'^\d+', self.build)
                    if match:
                        self._build_number: int = int(match.group(0))
                    else:
                        raise Exception("The model build must start with a positive integer.")
                case "Debugging":
                    self.__class__.DOING_DETAILED_DEBUG = (int(row[1]) == 1)
                case "SymInputFile":
                    self._sym_input_file: str = row[1]
                case "UserParameters":
                    self._parameters_file: str = row[1]
                case "IOTables":
                    self._io_table_file: str = row[1]
                case "Database":
                    self._database_file: str = row[1]
                case "Productivity":
                    self._productivity_file: str = row[1]
                case "Population":
                    self._population_file: str = row[1]
                case "AutonomousEnergyEfficiencyImprovement":
                    self._aeei_file: str = row[1]
                case "LinearisationYear":
                    self._linearisation_year: int = int(row[1])
                case "CalibrationYear":
                    self._calibration_year: int = int(row[1])
                case "CalibrationOfCarbonCoefficientsYear":
                    self._calibration_of_carbon_coefficients_year: int = int(row[1])
                case "BaseYear":
                    self._base_year: int = int(row[1])
                case "FirstProjectionYear":
                    self._first_projection_year: int = int(row[1])
                    self._original_first_projection_year: int = self.first_projection_year
                case "LastProjectionYear":
                    self._last_projection_year: int = int(row[1])
                case "StableManifoldTolerance":
                    self._stable_manifold_tolerance = float(row[1])
                case "StableManifoldMaximumIterations":
                    self._stable_manifold_maximum_iterations = int(row[1])
                case "NeutralRealInterestRate":
                    self._neutral_real_interest_rate = float(row[1])
                case "LineariseAroundStrictModelSolution":
                    self._linearise_around_strict_model_solution = bool(row[1])
                case _:
                    raise Exception(f"Configuration parameter {row[0]} is not recognised.")

    def __validate(self):

        # Check we have a model version and a model build number.
        assert self.version is not None
        assert self.build is not None
        assert self.build_number is not None
        if self.build_number <= 0:
            raise Exception(f"The model build must start with a positive integer. It starts with {self.build_number}.")

        # Check that all of the files named in the configuration exist.
        if not os.path.isfile(self.sym_input_file):
            raise Exception(f"Could not find the sym_input_file: {self.sym_input_file}")
        if not os.path.isfile(self.varmap_file):
            raise Exception(f"Could not find the varmap file generated by the SYM processor: {self.varmap_file}")
        assert os.path.isfile(self.varmap_file)
        assert os.path.isfile(self.eqnmap_file)
        assert os.path.isfile(self.variables_info_file)
        assert os.path.isfile(self.opt_map_file)
        assert os.path.isfile(self.model_summary_file)
        assert os.path.isfile(self.equations_python_module_file)

        assert os.path.isfile(self.database_file)
        assert os.path.isfile(self.io_table_file)
        assert os.path.isfile(self.parameters_file)

        assert os.path.isfile(self.productivity_file)
        assert os.path.isfile(self.population_file)

        sys.path.append(self.sym_directory)
        equations_module = importlib.import_module(self.sym_output_filename_prefix)
        assert equations_module is not None
        assert getattr(equations_module, "Equations") is not None

        assert self.base_year <= self.first_projection_year

        assert self.first_projection_year < self.last_projection_year
        
        if self.stable_manifold_tolerance > 0.0001:
            raise Exception("The convergence tolerance when searching for the stable manifold must be less than 1e-4.")

        if self.stable_manifold_maximum_iterations < 100:
            raise Exception("You must allow for at least 100 iterations in converging to the stable manifold")
        

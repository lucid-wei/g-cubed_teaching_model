# ------------------------------------------------------------------
# Purpose: This class defines the state of the model, at all
# points from data loading to simulation analysis.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
"""
Contains the Model class, used to load the model details.
"""
import importlib
import logging
from gcubed.baseline.energy_usage_efficiency import EnergyUsageEfficiency
from gcubed.model_configuration import ModelConfiguration
from gcubed.baseline.effective_labour_productivity import EffectiveLabourProductivity
from gcubed.sym_data import SymData
from gcubed.data.database import Database
from gcubed.model_parameters.parameters import Parameters
from gcubed.base import Base

class Model(Base):
    """
    Encapsulates all of the information about a Model,
    sufficient to generate baseline projections.
    """

    def __init__(self, configuration: ModelConfiguration) -> None:
        """

        ### Constructor

        Cause the model to load based on the information in its configuration.

        ### Arguments

        configuration (ModelConfiguration): the configuration details
        for the model being created.
        
        """
        self._configuration = configuration

        logging.info(f"Setting up model {self.configuration.version} {self.configuration._build}.")

        self._sym_data = SymData(configuration=self.configuration)

        self._database = Database(sym_data=self.sym_data)

        # Use the parameters class associated with the model version and number being run
        version: str = self.configuration.version
        build: int = self.configuration.build
        module = importlib.import_module(f"gcubed.model_parameters.{version}.parameters_{version}_{build}")
        parameters_class: Parameters = getattr(module, f"Parameters{version}{build}")
        self._parameters = parameters_class(database=self.database, base_year=self.configuration.calibration_year)

        self._effective_productivity = EffectiveLabourProductivity(parameters=self.parameters)

        self._energy_usage_efficiency = EnergyUsageEfficiency(sym_data=self.sym_data)

        self.__validate()

    def __validate(self):
        """
        Raise an exception if the model is invalid.
        Confirm a successful instantiation otherwise.
        """
        logging.info(f"Model {self.configuration.version} {self.configuration._build} has successfully loaded.")


    @property
    def configuration(self) -> ModelConfiguration:
        """
        The model configuration.
        """
        return self._configuration

    @property
    def sym_data(self) -> SymData:
        """
        The data provided by SYM about variables and parameters.
        """
        return self._sym_data

    @property
    def database(self) -> Database:
        """
        The model database.
        """
        return self._database

    @property
    def parameters(self) -> Parameters:
        """
        The model parameter values, set by the user and calibrated
        from the model database and IO tables.
        """
        return self._parameters

    @property
    def effective_labour_productivity(self) -> EffectiveLabourProductivity:
        """
        The effective labour productivity growth projections underpinning 
        levels projections that reflect long-run growth prospects.
        """
        return self._effective_productivity

    @property
    def energy_usage_efficiency(self) -> EnergyUsageEfficiency:
        """
        The energy usage efficiency improvement rate projections for each sector in each
        region. These impact projections for energy requirements by region and sector.
        """
        return self._energy_usage_efficiency


# ------------------------------------------------------------------
# Purpose: Set up and provided access to productivity shocks.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
import logging
import pandas as pd
import numpy as np
from gcubed.base import Base
from gcubed.model_parameters.parameters import Parameters
from gcubed.baseline.productivity import Productivity
from gcubed.baseline.population import Population
import decimal

# Ensure pdoc generated API documentation includes the following methods.
__pdoc__ = {}
__pdoc__['EffectiveLabourProductivity._configure_ROGY'] = True


class EffectiveLabourProductivity(Base):
    """
    Sets up effective labour productivity projections 
    (effective laboiur is A times L where A is productivity and L is labour).
    for all regions and all sectors within each region including sector Y and sector Z.
    """

    def __init__(self, parameters: Parameters) -> None:
        assert parameters is not None
        self._parameters = parameters

        self._productivity = Productivity(sym_data=self.sym_data)

        self._population = Population(sym_data=self.sym_data)

        self.__configure_us_longrun_effective_labour_productivity_index()

        self.__configure_effective_labour_productivity()

        self._configure_ROGY()

        self.__validate()

    def __validate(self):
        """
        TODO: Check that productivity shocks etc. meet expectations
        """
        pass

    @property
    def parameters(self):
        return self._parameters

    @property
    def calibration_database(self):
        return self.parameters.calibration_database

    @property
    def sym_data(self):
        return self.parameters.sym_data

    @property
    def configuration(self):
        return self.parameters.sym_data.configuration

    @property
    def productivity(self) -> Productivity:
        return self._productivity

    @property
    def population(self) -> Population:
        return self._population

    @property
    def rogy(self) -> pd.DataFrame:
        return self._rogy

    @property
    def us_longrun_effective_labour_index(self) -> pd.DataFrame:
        return self._us_longrun_effective_labour_index

    @property
    def effective_productivity_growth_rates(self, region: str) -> pd.DataFrame:
        return self._effective_productivity_growth_rates

    def effective_productivity_deviations(self, region: str) -> pd.DataFrame:
        """
        The data in these data frames should match the Ox-generated product.csv data 
        for SHL, SHLY and SHLZ for each region.

        A dictionary of sectors for various variables, keyed by region
        
        For region PP, the rows are the projections for:
        SHL(PP,a01)
        SHL(PP,a02)
        SHL(PP,a03)
        SHL(PP,a04)
        SHL(PP,a05)
        SHL(PP,a06)
        SHL(PP,a07)
        SHL(PP,a08)
        SHL(PP,a09)
        SHL(PP,a10)
        SHL(PP,a11)
        SHL(PP,a12)
        SHL(PP,a13)
        SHL(PP,a14)
        SHL(PP,a15)
        SHL(PP,a16)
        SHL(PP,a17)
        SHL(PP,a18)
        SHL(PP,a19)
        SHL(PP,a20)
        SHLY(PP)
        SHLZ(PP)
        """
        if not region in self._effective_productivity_deviations:
            raise Exception(f"Region {region} is does not have effective productivity deviation data.")
        return self._effective_productivity_deviations[region]

    @property
    def weights(self) -> pd.DataFrame:
        """
        The OUP weights across sectors (rows) for each region (columns).
        """
        return self._weights

    def __configure_us_longrun_effective_labour_productivity_index(self):
        """
        Get the US long run effective labour growth rate from the model parameters
        and project that rate forward to the end of the projection years to 
        create an index that has a simple growth rate that is equal to the value 
        of the labgrow parameter for the US.
        """
        us_long_run_growth_rate: float = float(
            self.parameters.parameter(parameter_name="labgrow").loc[:, self.sym_data.us_region].values[0])
        us_long_run_effective_labour_index: pd.DataFrame = self.productivity._us_productivity_growth_rates.iloc[[0],
                                                           :].copy()

        us_long_run_effective_labour_index.iloc[:, 0] = 1.0
        for year_index in range(1, len(us_long_run_effective_labour_index.columns)):
            us_long_run_effective_labour_index.iloc[:, year_index] = float(
                us_long_run_effective_labour_index.iloc[:, (year_index - 1)].values[0]) * (1 + us_long_run_growth_rate)
        self._us_longrun_effective_labour_index = us_long_run_effective_labour_index

    def __configure_effective_labour_productivity(self):
        """
        Populate a dictionary of regional dataframes of
        effective labour productivity deviations 
        from the US long run.
        """
        self._effective_productivity_deviations: dict[str, pd.DataFrame] = dict()
        for region in self.sym_data.regions_members:

            # Add productivity growth and population growth
            # logging.debug(f"{region} pop growth\n{self.population.population_growth_rates.loc[region,:]}")
            effective_productivity_growth_rates: pd.DataFrame = \
                self.productivity.productivity_growth_rates(region).copy() + \
                self.population.population_growth_rates.loc[region, :].copy()

            effective_productivity_indices: pd.DataFrame = effective_productivity_growth_rates.copy()
            effective_productivity_deviations: pd.DataFrame = effective_productivity_growth_rates.copy()

            # Convert the aggregate growth rates to indices.
            effective_productivity_indices.iloc[:, 0] = 1
            effective_productivity_deviations.iloc[:, 0] = 0
            for year_index in range(1, len(effective_productivity_indices.columns)):
                effective_productivity_indices.iloc[:, year_index] = \
                    effective_productivity_indices.iloc[:, (year_index - 1)] * \
                    (1 + effective_productivity_growth_rates.iloc[:, year_index])

                effective_productivity_deviations.iloc[:, year_index] = 100 * \
                                                                        (effective_productivity_indices.iloc[:,
                                                                         year_index] / \
                                                                         float(
                                                                             self.us_longrun_effective_labour_index.iloc[
                                                                             :, year_index].values[0]) - 1)

            # logging.debug(f"{region} deviations\n{effective_productivity_deviations}")

            effective_productivity_deviations_in_first_projection_year: np.ndarray = effective_productivity_deviations.loc[
                                                                                     :, [
                                                                                            str(self.configuration.first_projection_year)]].copy().to_numpy()
            effective_productivity_deviations.iloc[:,
            :] = effective_productivity_deviations.to_numpy() - effective_productivity_deviations_in_first_projection_year
            self._effective_productivity_deviations[region] = effective_productivity_deviations

    def _configure_ROGY(self):
        """
        **This function is intended for gcubed module internal use. It is exposed only for documentation purposes.**

        Get OUP by region/sector for 2003 for model J and model R and 2017 for model G.).
        Get total OUP for each sector (row) and region (column).
        Convert to national weights by dividing each OUP value by the total of OUP for the corresponding region.
        Expose this dataframe as "weights" for comparison to the weights.csv file from Ox.
        
        Create the ROGY data by implementing following OX code:
        decl prodg = zeros(countopt,columns(product));
    	k=2;
	    for(i=1;i<=countopt;++i)
	    {
            // prodg for region i over the projection years from start to end is equal to ...
            prodg[i][8:columns(product)] = 
            
            // the weighted average (using weights from OUP) of the data in product
            (weights[][i]')*(product[k:k+numsect-2-1][8:columns(product)]- product[k:k+numsect-2-1][7:columns(product)-1]);
		    k=k+numsect;
	    }

        In lay-terms, get the start year to end year data for the US sectors (excluding Y and Z) for SHL which
        is available from the productivity_shocks.effective_productivity_deviations["UU"] throwing away the last 2 rows of that dataframe.
        Then take the t minus t-1 difference of that dataframe, using zeros for t-1 for the start year.
        weight the change in the values for each year, from the previous year, using the weights computed from OUP for the region we are calculating data for.
        """
        self._rogy: pd.DataFrame = pd.DataFrame(0, index=self.sym_data.regions_members,
                                                columns=self.configuration.projection_years_column_labels)

        # Get the OUP data for each region/sector combination to create the weights dataframe
        weights: pd.DataFrame = pd.DataFrame(0, index=self.sym_data.sectors_members,
                                             columns=self.sym_data.regions_members)

        decimal.getcontext().prec = 10
        for region in self.sym_data.regions_members:
            oup: pd.DataFrame = self.calibration_database.get_data(name_regular_expression=f"^OUP\(.*{region}.*$",
                                                                   years=self.configuration.first_projection_year)
            region_weights = oup / oup.sum(axis=0)
            w = region_weights.to_numpy().reshape(1, self.sym_data.sectors_count)
            weights.loc[:, [region]] = np.transpose(w)

            # Get the US SHL data - rows are sectors and columns are years from start year to end year.
            region_SHL = self.effective_productivity_deviations(region=region).copy()

            # Obsolete code: see https://bitbucket.org/msgpl/gcubedcode/issues/140/prodmat-file-for-20r-is-missing-some
            # # Remove the two capital sectors Y and Z.
            # region_SHL = region_SHL.drop(self.sym_data.capital_sectors_members, axis=0)

            # Calculate the first difference in the US SHL data.
            lagged_region_SHL = region_SHL.copy().drop(str(self.configuration.last_projection_year), axis=1)
            lagged_region_SHL.insert(loc=0, column=str(self.configuration.first_projection_year - 1), value=0)
            lagged_region_SHL.columns = region_SHL.columns
            region_SHL_first_difference = (region_SHL - lagged_region_SHL).to_numpy()
            self._rogy.loc[[region], :] = w @ region_SHL_first_difference

        self._weights = weights

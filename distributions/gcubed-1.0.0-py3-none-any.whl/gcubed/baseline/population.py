# ------------------------------------------------------------------
# Purpose: Set up and provided access to population projections.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
import logging
import os
import os.path
import pandas as pd
from gcubed.base import Base
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData

# Ensure pdoc generated API documentation includes the following methods.
__pdoc__ = {}
__pdoc__['Population._load_population_growth_rates'] = True


class Population(Base):
    """
    Loads population growth rates for all sectors within each region.
    """

    def __init__(self, sym_data: SymData) -> None:
        assert sym_data is not None
        assert sym_data.configuration is not None
        self._configuration: ModelConfiguration = sym_data.configuration
        self._sym_data: SymData = sym_data

        self._load_population_growth_rates()

        self.__validate()

    def __validate(self):
        """
        TODO: Check that growth rate projections extend to the right last year for projections.
        """

        assert self._population_growth_rates is not None

        # The productivity information must extend to the end year for the simulations
        if not self.configuration.last_projection_year == int(self._population_growth_rates.columns[-1]):
            logging.warning(f"The end year for population projections, {self.configuration.last_projection_year}, does not match the final year, {self._population_growth_rates.columns[-1]}, of the productivity data in {self._filename}")

        # Make sure the productivity data starts early enough to include the years specified in the model configuration.
        assert str(self.configuration.first_projection_year) in self._data_column_names

    @property
    def configuration(self):
        return self._configuration

    @property
    def sym_data(self):
        return self._sym_data

    @property
    def population_growth_rates(self) -> pd.DataFrame:
        return self._population_growth_rates

    def _load_population_growth_rates(self):
        """
        **This function is intended for gcubed module internal use. It is exposed only for documentation purposes.**

        Parse the CSV file into its the dataframe of population 
        growth rates expressed as decimal values so 1% growth rate is 0.01.
        """

        # Load the data into a dataframe
        self._filename: str = self.configuration.population_file
        if not os.path.isfile(self._filename):
            raise Exception(f"The productivity parameters file {self._filename} does not exist. Check the model configuration.")
        population_growth_rates: pd.DataFrame = pd.read_csv(self._filename)
        population_growth_rates.index = population_growth_rates.iloc[:,0]
        self._data_column_names = self.get_year_labels(labels=population_growth_rates.columns)
        population_growth_rates = population_growth_rates.loc[:, self._data_column_names] / 100
        population_growth_rates = population_growth_rates.loc[:,self.configuration.projection_years_column_labels]
        self._population_growth_rates = population_growth_rates
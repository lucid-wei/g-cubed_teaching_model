# ------------------------------------------------------------------
# Purpose: Set up and provide access to productivity projections.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
import logging
import os
import os.path
import pandas as pd
from gcubed.base import Base
from gcubed.model_configuration import ModelConfiguration
from gcubed.constants import Constants
from gcubed.sym_data import SymData

# Ensure pdoc generated API documentation includes the following methods.
__pdoc__ = {}
__pdoc__['Productivity._create_productivity_projections', 'Productivity._load_productivity_parameters'] = True


class Productivity(Base):
    """
    Loads productivity parameters and converts them to productivity projections 
    for all regions and all sectors within each region.
    """

    # These labels are used to parse the productivity input CSV file into its constituent parts.
    label_productivity_growth: str = "productivity growth"
    label_us_sector_convergence_rates: str = "convergence rate across US sectors"
    label_regional_sector_ratio_to_us: str = "sector ratio to the USA leader"
    label_regional_sector_catchup_to_us_rates: str = "catchup rate"

    def __init__(self, sym_data: SymData) -> None:
        assert sym_data is not None
        self._sym_data: SymData = sym_data
        self._load_productivity_parameters()
        self.__validate()
        self._create_productivity_projections()

    def __validate(self):
        """
        TODO: Check that productivity projections extend to the right last year for projections.
        What sanity checks should be applied in terms 
        of convergence across regions/sectors?
        """

        assert self._region_catchup_rates is not None
        assert self._us_productivity_growth_rates is not None
        # Obsolete code: see https://bitbucket.org/msgpl/gcubedcode/issues/140/prodmat-file-for-20r-is-missing-some
        # assert self._us_sector_convergence_rates is not None
        assert self.label_regional_sector_ratio_to_us is not None

        # The productivity information must extend to the end year for the simulations
        if not self.configuration.last_projection_year == int(self._us_productivity_growth_rates.columns[-1]):
            logging.warn(f"The end year for productivity projections, {self.configuration.last_projection_year}, does not match the final year, {self._us_productivity_growth_rates.columns[-1]}, of the productivity data in {self._filename}")

        # Make sure the productivity data starts early enough to include the years specified in the model configuration.
        assert str(self.configuration.original_first_projection_year) in self._data_column_names

    @property
    def configuration(self):
        return self.sym_data.configuration

    @property
    def sym_data(self):
        return self._sym_data

    def _us_productivity_growth_rates(self) -> pd.DataFrame:
        """
        Return the dataframe containing US productivity growth rate projections
        for all sectors.
        """
        return self._us_productivity_growth_rates

    def productivity_indices(self, region: str) -> pd.DataFrame:
        if not region in self._region_productivity_indices:
            raise Exception(f"Region {region} does not have productivity index data.")
        return self._region_productivity_indices[region]

    def productivity_growth_rates(self, region:str) -> pd.DataFrame:
        if not region in self._region_productivity_growth_rates:
            raise Exception(f"Region {region} does not have productivity growth rate data.")
        return self._region_productivity_growth_rates[region]

    def __get_index_of(self, label:str) -> int:
        if self._input is None:
            raise Exception("The productivity growth parameters have not been read from the CSV file.")
        matching_indexes: list[int] = self._input[self._input.region == label].index.to_list()
        match len(matching_indexes):
            case 0:
                raise Exception(f"There are no rows matching {label} in column 1 of the productivity parameters file.")
            case 1:
                return matching_indexes[0]
            case _:
                raise Exception(f"There is more than one row matching {label} in column 1 of the productivity parameters file.")



    def _load_productivity_parameters(self):
        """
        **This function is intended for gcubed module internal use. It is exposed only for documentation purposes.**

        Parse the CSV file into its various components and store them as properties.
        """

        regions_members: list[str] = self.sym_data.regions_members

        # The list of sectors defined in the SYM file (not sectors Y and Z that are common to all models and not explicit in the SYM file.)
        sectors_members: list[str] = self.sym_data.sectors_members

        # Load the data into a dataframe
        self._filename: str = self.configuration.productivity_file
        if not os.path.isfile(self._filename):
            raise Exception(f"The productivity parameters file {self._filename} does not exist. Check the model configuration.")
        self._input: pd.DataFrame = pd.read_csv(self._filename)
        self._input.reset_index()

        # Get the data column names. (YYYY format column labels)
        self._data_column_names = self.get_year_labels(labels=self._input.columns)

        # Get years range
        table_columns: list = range(2, 2+len(self._data_column_names))
        list_column: list = [2]

        # US productivity growth rates (Percentages so we divide by 100 before storing)
        label_row:int = self.__get_index_of(__class__.label_productivity_growth) + 2
        us_productivity_rows: list[int] = range(label_row, label_row + self.sym_data.sectors_count)
        if len(us_productivity_rows) < self.sym_data.sectors_count:
            raise Exception(f"The US sector productivity data is available for {us_productivity_rows} sectors but the model has {self.sym_data.sectors_count} sectors.")
        self._us_productivity_growth_rates = self._input.iloc[us_productivity_rows, table_columns].copy()
        self._us_productivity_growth_rates = self._us_productivity_growth_rates.head(self.sym_data.sectors_count)
        self._us_productivity_growth_rates = self._us_productivity_growth_rates.loc[:, self.configuration.projection_years_column_labels]
        self._us_productivity_growth_rates = self._us_productivity_growth_rates / 100
        self._us_productivity_growth_rates.index = sectors_members

        # Ratio to US productivity for each region, by sector. (1 means the productivity is the same)
        label_row: int = self.__get_index_of(__class__.label_regional_sector_ratio_to_us) + 2
        self._region_productivity_ratios:dict[str,pd.DataFrame] = dict()
        for region_index, region in enumerate(regions_members[1:]):
            first_row = label_row + region_index*(self.sym_data.sectors_count+1)
            region_productivity_ratio_rows: list[int] = range(first_row, first_row + self.sym_data.sectors_count)
            if len(region_productivity_ratio_rows) != self.sym_data.sectors_count:
                raise Exception(f"The {region} region productivity ratios data is available for {region_productivity_ratio_rows} sectors but the model has {self.sym_data.sectors_count} sectors.")
            region_productivity_ratios = self._input.iloc[region_productivity_ratio_rows, list_column].copy()
            region_productivity_ratios = region_productivity_ratios.head(self.sym_data.sectors_count)
            region_productivity_ratios.columns = ["ratio"]
            region_productivity_ratios.index = sectors_members
            self._region_productivity_ratios[region] = region_productivity_ratios

        # The regional catchup rates by sector (decimal)
        label_row: int = self.__get_index_of(
            label=__class__.label_regional_sector_catchup_to_us_rates) + 2
        self._region_catchup_rates: dict[str, pd.DataFrame] = dict()
        for region_index, region in enumerate(regions_members[1:]):
            first_row = label_row + region_index*(self.sym_data.sectors_count+1)
            region_catchup_rates_rows: list[int] = range(first_row, first_row + self.sym_data.sectors_count)
            if len(region_catchup_rates_rows) != self.sym_data.sectors_count:
                raise Exception(f"The {region} region catchup rate data is available for {region_catchup_rates_rows} sectors but the model has {self.sym_data.sectors_count} sectors.")
            region_catchup_rates = self._input.iloc[region_catchup_rates_rows, table_columns].copy()
            region_catchup_rates = region_catchup_rates.head(self.sym_data.sectors_count)
            region_catchup_rates.columns = self._data_column_names
            region_catchup_rates.index = sectors_members
            self._region_catchup_rates[region] = region_catchup_rates

    def _create_productivity_projections(self):
        """
        **This function is intended for gcubed module internal use. It is exposed only for documentation purposes.**

        Generate productivity growth and index projections from the start year to the end year 
        of the projection period for all regions and sectors.
        """
        
        # Set up the region and sector columns if we store all productivity level projections in the one dataframe.
        # Note that this is not being done yet - it is unlikely to be helpful in Python.
        ## region_column:list[str] = [x for x in self.sym_data.regions_members for i in range(self.sym_data.sectors_count)]
        ## sector_column:list[str] = self.sym_data.sectors_members * self.sym_data.regions_count
        ## assert len(region_column) == len(sector_column)

        # Initialise dictionary to store productivity levels for each region
        self._region_productivity_indices: dict[str, pd.DataFrame] = dict()

        # Project levels for the US, setting the level to 1 for each sector in the base year.
        us_productivity_indices = self._us_productivity_growth_rates.loc[:,self.configuration.projection_years_column_labels]
        us_productivity_indices.loc[:, str(self.configuration.first_projection_year)] = 1
        for year in self.configuration.projection_years[1:]:
            us_productivity_indices.loc[:, str(year)] = (us_productivity_indices.loc[:, str(year)] + 1) * us_productivity_indices.loc[:, str(year - 1)]
        self._region_productivity_indices[self.sym_data.us_region] = us_productivity_indices
        
        # Iterate the other regions, apply the catchup rates.
        for region in self.sym_data.regions_members:
            if region == Constants().USA_REGION_CODE:
                continue
            region_productivity_indices = self._region_catchup_rates[region].loc[:,self.configuration.projection_years_column_labels]
            region_productivity_indices.loc[:, str(self.configuration.first_projection_year)] = us_productivity_indices.loc[:, str(self.configuration.first_projection_year)] * self._region_productivity_ratios[region].loc[:, "ratio"]
            for year in self.configuration.projection_years[1:]:
                # The productivity index in year is determined as US index in the same 
                # # year percentage gap in previous year adjusted for 
                # a year of catch-up based on the catch-up rate over the previous year.
                region_productivity_indices.loc[:, str(year)] = us_productivity_indices.loc[:, str(year)] * \
                    (1 + (1-self._region_catchup_rates[region].loc[:, str(year-1)]) * \
                        (region_productivity_indices.loc[:, str(year - 1)] / us_productivity_indices.loc[:, str(year - 1)]-1))
            self._region_productivity_indices[region] = region_productivity_indices

        # Generate the dictionary of regional productivity growth rates by sector.
        self._region_productivity_growth_rates: dict[str, pd.DataFrame] = dict()
        self._region_productivity_growth_rates[self.sym_data.regions_members[0]] = self._us_productivity_growth_rates
        for region in self.sym_data.regions_members[1:]:
            region_productivity_growth_rates = self._region_productivity_indices[region]
            for year in self.configuration.projection_years[:-1]: # For all but the last year...
                region_productivity_growth_rates.loc[:,str(year)] = region_productivity_growth_rates.loc[:, str(year+1)] / region_productivity_growth_rates.loc[:, str(year)] - 1

            # Handle the final year by assuming continuation of the most recently available growth and catchup.
            final_year_region_productivity_indices = self._region_productivity_indices[region].loc[:, str(self.configuration.last_projection_year)]
            final_year_region_catchup_rates = self._region_catchup_rates[region].loc[:, str(self.configuration.last_projection_year)]
            final_year_us_productivity_indices = us_productivity_indices.loc[:, str(self.configuration.last_projection_year)]
            next_us_productivity_indices: float = final_year_us_productivity_indices * (1 + self._us_productivity_growth_rates.loc[:, str(self.configuration.last_projection_year)])
            next_region_productivity_indices = next_us_productivity_indices * \
                (1 + (1-final_year_region_catchup_rates) * \
                    (final_year_region_productivity_indices / final_year_us_productivity_indices - 1) )
            region_productivity_growth_rates.loc[:, str(self.configuration.last_projection_year)] = next_region_productivity_indices / final_year_region_productivity_indices - 1

            self._region_productivity_growth_rates[region] = region_productivity_growth_rates

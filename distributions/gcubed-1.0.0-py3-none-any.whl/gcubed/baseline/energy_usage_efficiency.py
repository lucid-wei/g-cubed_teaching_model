# ------------------------------------------------------------------
# Purpose: Set up and provided access to aeei data.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
import logging
import os
import os.path
import pandas as pd
from gcubed.base import Base
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData

# Ensure pdoc generated API documentation includes the following methods.
__pdoc__ = {}
__pdoc__['EnergyUsageEfficiency._load_energy_usage_efficiency_data'] = True

class EnergyUsageEfficiency(Base):
    """
    Loads energy usage efficiency (AEEI) data.
    """

    def __init__(self, sym_data: SymData) -> None:
        assert sym_data is not None
        assert sym_data.configuration is not None
        self._sym_data: SymData = sym_data
        self._load_energy_usage_efficiency_data()

        self.__validate()

    def __validate(self):
        """
        Ensure energy usage efficiency data meet expectations.
        """
        pass

    @property
    def sym_data(self) -> SymData:
        return self._sym_data

    @property
    def configuration(self) -> ModelConfiguration:
        return self.sym_data.configuration

    def sector_energy_usage_efficiency_gains(self, region:str) -> pd.DataFrame:
        """
        Dictionary of dataframes, one for each region, indexed by the region code.
        """
        if not region in self._sector_aeei:
            raise Exception(f"Energy usage efficiency (AEEI) by sector is not avaiable for region {region}")
        return self._sector_aeei[region]

    def sector_cumulative_energy_usage_efficiency_gains(self, region: str) -> pd.DataFrame:
        """
        Dictionary of cumulative energy usage efficiency dataframes, one for each region, indexed by the region code.
        Each dataframe has a row for each sector.
        This corresponds to the SHL rows and the SHLY row and SHLZ row for each region of product.csv.
        """
        if not region in self._sector_cumulative_aeei:
            raise Exception(f"Cumulative energy usage efficiency by sector is not avaiable for region {region}")
        return self._sector_cumulative_aeei[region]

    @property
    def consumption_energy_usage_efficiency_gains(self) -> pd.DataFrame:
        """
        Dataframe for consumption energy usage efficiency with a row for each region
        """
        return self._consumption_energy_usage_efficiency

    @property
    def consumption_cumulative_energy_usage_efficiency_gains(self) -> pd.DataFrame:
        """
        Dataframe for cumulative consumption energy usage efficiency with a row for each region.
        This corresponds to the SHEFC rows of product.csv.
        """
        return self._consumption_cumulative_aeei


    def _load_energy_usage_efficiency_data(self):
        """
        **This function is intended for gcubed module internal use. It is exposed only for documentation purposes.**

        Parse the CSV file into its the dataframe of energy usage efficiency data.
        """

        # Load the data into a dataframe
        self._filename: str = self.configuration.aeei_file
        if not os.path.isfile(self._filename):
            raise Exception(f"The energy usage efficiency (AEEI) file, {self._filename}, does not exist. Check the model configuration.")
        input: pd.DataFrame = pd.read_csv(self._filename)
        input.index = input.iloc[:,0]
        input = input.loc[:, self.configuration.projection_years_column_labels]

        # Get the consumption energy usage efficiency first.
        self._consumption_energy_usage_efficiency = input.tail(self.sym_data.regions_count)
        self._consumption_energy_usage_efficiency.index = self.sym_data.regions_members
        self._consumption_cumulative_aeei = self._consumption_energy_usage_efficiency.copy()
        self._consumption_cumulative_aeei.iloc[:, 0] = 0
        self._consumption_cumulative_aeei = self._consumption_cumulative_aeei.cumsum(axis=1)
        # logging.debug(self._consumption_cumulative_aeei)

        # Split the remaining data by region
        sectors_input = input.head(len(input.index) - self.sym_data.regions_count)
        self._sector_aeei = dict()
        self._sector_cumulative_aeei = dict()
        for region in self.sym_data.regions_members:
            region_aeei = sectors_input.loc[sectors_input.index.str.endswith(region, na=False), self.configuration.projection_years_column_labels].copy()
            region_aeei.index = self.sym_data.sectors_members

            # logging.debug(f"{region} aeei index\n{region_aeei}")

            region_cumulative_aeei = region_aeei.copy()
            region_cumulative_aeei.iloc[:, 0] = 0
            region_cumulative_aeei = region_cumulative_aeei.cumsum(axis=1)

            # logging.debug(f"{region} region_cumulative_aeei\n{region_cumulative_aeei}")

            self._sector_cumulative_aeei[region] = region_cumulative_aeei
            self._sector_aeei[region] = region_aeei

# ------------------------------------------------------------------
# Purpose: Manage loading and provision of IO table information.
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
"""
Contains the IOTables class for input/output table management.
"""
import logging
import os
import pandas as pd
from gcubed.base import Base
from gcubed.sym_data import SymData

# Ensure pdoc generated API documentation includes the following methods.
__pdoc__ = {}
__pdoc__['IOData._load_io_tables'] = True


class IOData(Base):
    """
    ### Overview

    Encapsulates all of the information about the input/output tables for each region.
    """

    def __init__(self, sym_data: SymData) -> None:
        """
       ### Arguments

        `sym_data`: The information about the SYM model definition.

        """
        assert sym_data is not None
        assert isinstance(sym_data, SymData)
        self._sym_data = sym_data
        self._load_io_tables()
        self.__validate()

    @property
    def sym_data(self):
        """
        The SYM details of the model.
        """
        return self._sym_data

    def _load_io_tables(self):
        """
        **This function is intended for gcubed module internal use. It is exposed only for documentation purposes.**

        Loads the IO tables into a dictionary of dataframes.
        The keys are the region identifier.
        Each dataframe contains the IO table for the associated region.
        The dataframes have row and column names that correspond to the
        sectors.
        """
        filename: str = self.sym_data.configuration.io_table_file
        if not os.path.isfile(filename):
            raise Exception("Could not load IO tables from " +
                            filename + " because the file does not exist.")

        # Load the raw IO tables data into a single dataframe ready to parse into 
        # separate tables for the various regions.
        data: pd.DataFrame = pd.read_csv(filename, header=None)

        # Label the columns of the raw IO table dataframe
        columns = self.io_table_uses
        columns.insert(0,"row_labels")
        data.columns = columns

        # Get the table names - one for each region
        regions: list[str] = self.sym_data.regions_members
        table_rows = len(self.io_table_inputs)
        table_columns = len(self.io_table_uses)

        # Load the table for each region into the dictionary of IO tables.
        self._io_tables = dict()
        for region in regions:

            # Make sure the data source has an IO table for the region
            if not region in data.row_labels.values:
                raise Exception(f"Region {region} does not have IO table data in {filename}")

            # Get the data for the table
            io_table_heading_row: int = int(data.index[data.row_labels == region].to_list()[0])
            io_table: pd.DataFrame = data.iloc[(io_table_heading_row + 1):(io_table_heading_row+1+table_rows), 1:(table_columns+1)].copy()
            io_table = io_table.astype(float)
            io_table.index = self.io_table_inputs
            io_table.columns=self.io_table_uses

            # Store the table in the dictionary of IO tables, one for each region
            self._io_tables[region] = io_table

    def io_table(self, region: str) -> pd.DataFrame:
        """
        
        ### Overview
        Use this function to retrieve the IO table content for a single region.
        That IO table can then be analysed using the input (row) index and the output
        (column) label for the rows and columns of the dataframe that is the
        IO table.

       ### Arguments

        region: the identifier for the region of interest.
        
       ### Returns

        the dataframe containing the input/output table for the specified region.

        """
        if region in self._io_tables:
            return self._io_tables[region]
        raise Exception("There is no IO table defined for " + region)

    def has_io_table(self, region: str) -> bool:
        """
        
       ### Arguments

        region: The region of interest.
        
       ### Returns

        True if there is an IO table for the specified region.
        
        """
        return region in self._io_tables

    @property
    def io_table_inputs(self):
        """
        The row names (one per input) in the IO tables. All regions have the same rows in
        their IO tables.
        """
        input_names = self.sym_data.goods_members
        input_names.extend(
            [self.io_table_labour, self.io_table_capital, self.io_table_tax])
        return input_names

    @property
    def io_table_tax(self) -> str:
        """
        Returns the tax row label.
        """
        return "TAX"

    @property
    def io_table_labour(self) -> str:
        """
        The labour row label.
        """
        return "L"

    @property
    def io_table_capital(self) -> str:
        """
        The capital row label.
        """
        return "K"

    @property
    def io_table_consumption(self) -> str:
        """
        The consumption column label.
        """
        return "C"

    @property
    def io_table_investment(self) -> str:
        """
        The investment column label.
        """
        return "I"

    @property
    def io_table_government(self) -> str:
        """
        The government spending column label.
        """
        return "G"

    @property
    def io_table_exports(self) -> str:
        """
        The exports column label.
        """
        return "X"

    @property
    def io_table_imports(self) -> str:
        """
        The imports column label.
        """
        return "M"

    @property
    def io_table_uses(self):
        """
        The column names, one column for each output in the IO tables. The IO table
        has the same columns for each region.
        """
        use_names = self.sym_data.sectors_members
        # TODO: Figure out how to interpret the first column.
        use_names.extend([self.io_table_consumption, self.io_table_investment,
                         self.io_table_government, self.io_table_exports, self.io_table_imports])
        return use_names

    def __validate(self):
        """
        Raise an exception if the IO data is invalid
        """
        logging.info(f"Loaded input/ouput tables for each region from {self.sym_data.configuration.io_table_file}")

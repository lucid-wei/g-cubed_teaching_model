"""
Model version 20C parameter subclasses.
"""
"""
This package contains the Parameter calibration system for G-Cubed.

The Parameters class implements most of the standard parameter loading and
calibration.

Subclass that Parameters class by adding a module in the appropriate model version
and model build module:

`gcubed.parameters.<VERSION>parameters_<VERSION>_<BUILD>`
"""
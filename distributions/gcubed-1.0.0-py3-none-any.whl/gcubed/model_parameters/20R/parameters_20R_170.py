# ------------------------------------------------------------------
# Purpose: Model parameter handling
# Author: Geoff Shuetrim
# ------------------------------------------------------------------
import logging
import pandas as pd
import numpy as np
from gcubed.model_parameters.parameters import Parameters
from gcubed.data.database import Database


class Parameters20R170(Parameters):
    """
    ### Overview
    Customised parameter calibration for model 20R 170.
    """

    def __init__(self, database: Database, base_year: int) -> None:
        """
        ### Arguments

        database: The database used to calibrate the parameters.

        base_year: The base year that the database needs to be rebased to before
        calibration of the parameters.
        
        """
        super().__init__(database=database, base_year=base_year)
        
        self.__set_delta_ed()

        self.__set_delta_eG()

        self.__set_imq_zero()

        self.__adjust_carcoef()

        self.__adjust_btucoef()

        # Required statements in all final subclasses of the parameter class.
        self._parameter_values.index = self._parameter_full_names
        self.validate()

    def validate(self):
        super().validate()
        logging.info(f"Calibrated the model parameters using a database with base year {self.calibration_database.base_year}.")

    def __set_delta_ed(self):
        """
        delta_ed (note the transpose before storing and vectorising )
        """

        delta_ed: pd.DataFrame = self.zeros(rows=self.sym_data.electricity_generation_goods_count, cols=self.sym_data.regions_count)
        delta_ed.index = self.sym_data.electricity_generation_goods_members
        delta_ed.columns = self.sym_data.regions_members

        for region in self.sym_data.regions_members:

            io_table: pd.DataFrame = self._io_data.io_table(region)
            if io_table is None:
                raise Exception(f"There is no IO table for region {region}")

            # delta_ed
            if self.sym_data.electricity_generation_goods_count > 0:
                delta_ed_intermediate: pd.DataFrame = io_table.loc[self.sym_data.electricity_generation_goods_members, (self.sym_data.sectors_members[0])]
                delta_ed_intermediate = delta_ed_intermediate / delta_ed_intermediate.sum()
                delta_ed.loc[:, region] = delta_ed_intermediate.to_numpy()
            else:
                pass  # delta_ed has been initialised to zeros so we are done.

        # Store delta_ed - after transposing it.
        delta_ed = delta_ed.transpose()
        self._all_parameters["delta_ed"] = delta_ed
        self.insert_parameter(parameter_name="delta_ed", parameter_value_vector=delta_ed.to_numpy().flatten())


    def __set_delta_eG(self):
        """
        Override the setting of delta_eG in the gcubed.parameters module.

        delta_eG - G: government column of IO table - energy sectors

        The original Ox calculation was:
        delta_eG[][i] = xx[1:numener][numsect+3] / sumc(xx[1:numener][numsect+3]);

        The new Ox calculation is:
        if (sumc(xx[1:numener][numsect+3])>0) { 
            delta_eG[][i] = xx[1:numener][numsect+3] / sumc(xx[1:numener][numsect+3]); 
        } else { 
            delta_eG[][i] = 0; 
        }

        """

        delta_eG: pd.DataFrame = pd.DataFrame(index=self.sym_data.energy_goods_members, columns=self.sym_data.regions_members)
        delta_eG.loc[:,:] = 0

        for region in self.sym_data.regions_members:
            io_table: pd.DataFrame = self._io_data.io_table(region)
            energy_goods_govt_io: pd.DataFrame = io_table.loc[self.sym_data.energy_goods_members, "G"]
            energy_goods_govt_io_total: float = float(energy_goods_govt_io.sum())
            if (energy_goods_govt_io_total > 0):
                energy_goods_govt_io /= energy_goods_govt_io_total
            delta_eG.loc[:, region] = energy_goods_govt_io.to_numpy()

        self._all_parameters["delta_eG"] = delta_eG
        self.insert_parameter("delta_eG", delta_eG.to_numpy().flatten())

    def __set_imq_zero(self):
        """
        IMQ can be zero for some sectors in some regions.

        Set this parameter to 1 for region/sector pairs that have 
        very little or zero values for IMQ in the base calibration year.
        Otherwise set the value to 0.
        """
        # Get the relevant IMQ data
        imq: np.ndarray = self.calibration_database.get_data('^IMQ\(', self.calibration_year)

        # Form the matrix of parameter values
        imq_zero: pd.DataFrame = pd.DataFrame(imq.to_numpy().reshape((self.sym_data.non_electricity_generation_goods_count, self.sym_data.regions_count)) <= 0.00001)
        imq_zero.index = self.sym_data.non_electricity_generation_goods_members
        imq_zero.columns = self.sym_data.regions_members

        # Save the parameter for later use
        self._all_parameters["imq_zero"] = imq_zero
        self.insert_parameter("imq_zero", imq_zero.to_numpy().flatten())

    def __adjust_carcoef(self):
        """
        Multiply by 10 to reflect the change in units of measurement.
        """
        carcoef: pd.DataFrame = self.parameter(parameter_name = "carcoef")
        carcoef *= 10
        self._all_parameters["carcoef"] = carcoef
        self.insert_parameter("carcoef", carcoef.to_numpy().flatten())

    def __adjust_btucoef(self):
        """
        Multiply by 10 to reflect the change in units of measurement.
        """
        btucoef: pd.DataFrame = self.parameter(parameter_name = "btucoef")
        btucoef *= 10
        self._all_parameters["btucoef"] = btucoef
        self.insert_parameter("btucoef", btucoef.to_numpy().flatten())

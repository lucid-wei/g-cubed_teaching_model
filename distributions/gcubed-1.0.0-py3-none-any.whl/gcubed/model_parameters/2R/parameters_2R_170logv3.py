# ------------------------------------------------------------------
# Purpose: Custom model parameter calibration
# Author: Geoff
# ------------------------------------------------------------------
import logging
from gcubed.model_parameters.parameters import Parameters
from gcubed.data.database import Database


class Parameters2R170logv3(Parameters):
    """
    Customised parameter calibration for model 2R 170.
    """

    def __init__(self, database: Database, base_year: int) -> None:
        """
        ### Arguments

        database: The database used to calibrate the parameters.

        base_year: The base year that the database needs to be rebased to before
        calibration of the parameters.
        
        """        
        super().__init__(database=database, base_year=base_year)

        # No custom parameter calibrations are required.

        # Required statements in all final subclasses of the parameter class.
        self._parameter_values.index = self._parameter_full_names
        self.validate()

    def validate(self):
        super().validate()
        logging.info(f"Calibrated the model parameters using a database with base year {self.calibration_database.base_year}.")
